# DATABASE_SCHEMA dict migrated verbatim from notebook
DATABASE_SCHEMA = {
    "cat_fpl_prevspostalloc": {
        "description": "Main FPL fact table  -  cost/plan/forecast/LY actuals in Local, EURAOP, NY_EURAOP currencies",
        "columns": [
            "FiscalPeriodID", "CC_PK_IPL", "CoCodePK", "FuncAreaPK", "MAG_PK", "Acct_PK", "FSI_Func_ID",
            "PostActuals_Local", "PostAOP_Local", "PostJunFC_Local", "PostActualsLY_Local",
            "PreActuals_Local", "PreAOP_Local", "PreJunFC_Local", "PreActualsLY_Local",
            "PostActuals_EURAOP", "PostAOP_EURAOP", "PostJunFC_EURAOP", "PostActualsLY_EURAOP",
            "PreActuals_EURAOP", "PreAOP_EURAOP", "PreJunFC_EURAOP", "PreActualsLY_EURAOP",
            "PostActuals_NY_EURAOP", "PostAOP_NY_EURAOP", "PostJunFC_NY_EURAOP", "PostActualsLY_NY_EURAOP",
            "PreActuals_NY_EURAOP", "PreAOP_NY_EURAOP", "PreJunFC_NY_EURAOP", "PreActualsLY_NY_EURAOP",
        ],
        "key_measures": {
            "PostActuals_Local": "Current Year Actuals (Local currency)",
            "PostAOP_Local": "Annual Operating Plan (Local currency)",
            "PostJunFC_Local": "June Forecast (Local currency)",
            "PostActualsLY_Local": "Last Year Actuals (Local currency)",
            "PostActuals_EURAOP": "Current Year Actuals (EUR at AOP rate)",
            "PostAOP_EURAOP": "Annual Operating Plan (EUR at AOP rate)",
            "PostJunFC_EURAOP": "June Forecast (EUR at AOP rate)",
            "PostActualsLY_EURAOP": "Last Year Actuals (EUR at AOP rate)",
        },
        "aliases": ["fpl"],
    },
    "cat_blueprint_prevspostalloc": {
        "description": "Blueprint/Headcount fact table  -  HC and FTE allocations (Pre/Post, Actuals/AOP/FC/LY)",
        "columns": [
            "FiscalPeriodID", "CC_PK_IPL", "CoCodePK", "FuncAreaPK", "MAG_PK", "Acct_PK",
            "SO_ID", "EmployeeMaskPK",
            "PostActuals_Alloc_HC", "PostActualsLY_Alloc_HC", "PostAOP_Alloc_HC", "PostJunFC_Alloc_HC",
            "PostActuals_Alloc_FTE", "PostActualsLY_Alloc_FTE", "PostAOP_Alloc_FTE", "PostJunFC_Alloc_FTE",
            "PreActuals_Alloc_HC", "PreActualsLY_Alloc_HC", "PreAOP_Alloc_HC", "PreJunFC_Alloc_HC",
            "PreActuals_Alloc_FTE", "PreActualsLY_Alloc_FTE", "PreAOP_Alloc_FTE", "PreJunFC_Alloc_FTE",
        ],
        "key_measures": {
            "PostActuals_Alloc_FTE": "Current Year FTE",
            "PostAOP_Alloc_FTE": "AOP FTE",
            "PostJunFC_Alloc_FTE": "June Forecast FTE",
            "PostActualsLY_Alloc_FTE": "Last Year FTE",
            "PostActuals_Alloc_HC": "Current Year Head Count",
            "PostAOP_Alloc_HC": "AOP Head Count",
        },
        "aliases": ["bp", "blueprint"],
    },
    "pps": {
        "description": "PPS Reconciliation fact table  -  payroll posting details with wage types and descriptions",
        "columns": [
            "Acct_PK", "CC_PK_IPL", "CoCodePK",
            "PPS_Recon_AllocationAssignment", "PPS_Recon_OldCostCenter", "PPS_Recon_Currency",
            "PPS_Recon_Credit", "PPS_Recon_Debit", "PPS_Recon_PersonnelNumber",
            "PPS_Recon_ProfitCenter", "PPS_Recon_Description", "PPS_Recon_RunNumber",
            "PPS_Recon_WageType", "PPS_Recon_WBSElement",
            "PPS_Recon_Local", "PPS_Recon_EURAOP",
            "PPS_Recon_SNo", "PPS_Recon_FiscalPeriodID", "PPS_Recon_File_Reg",
        ],
        "key_measures": {
            "PPS_Recon_Local": "PPS Reconciliation Amount (Local currency)",
            "PPS_Recon_EURAOP": "PPS Reconciliation Amount (EUR at AOP rate)",
        },
        "aliases": ["pps"],
    },
    "pps_sap": {
        "description": "SAP Reconciliation fact table  -  SAP document-level reconciliation with payroll categories",
        "columns": [
            "Acct_PK", "CC_PK_IPL", "CoCodePK", "MAG_PK",
            "SAP_Recon_Year", "SAP_Recon_DocumentNumber", "SAP_Recon_DocType",
            "SAP_Recon_PayPeriod", "SAP_Recon_BUDAT", "SAP_Recon_Documentreference",
            "SAP_Recon_Text", "SAP_Recon_DebitCreditInd", "SAP_Recon_Currency",
            "SAP_Recon_PayrollCategory", "SAP_Recon_SNo",
            "SAP_Recon_Local", "SAP_Recon_EURAOP",
            "SAP_Recon_FiscalPeriodID", "SAP_Recon_File_Reg",
        ],
        "key_measures": {
            "SAP_Recon_Local": "SAP Reconciliation Amount (Local currency)",
            "SAP_Recon_EURAOP": "SAP Reconciliation Amount (EUR at AOP rate)",
        },
        "aliases": ["pps_sap", "sap"],
    },
    "adap_act": {
        "description": "ADAP Actuals fact table  -  position-level cost data with ORU and BU identifiers",
        "columns": [
            "Acct_PK", "CC_PK_IPL", "CoCodePK", "MAG_PK", "FuncAreaPK",
            "ADAP_FiscalPeriodID", "ADAP_ORUID", "ADAP_BUID",
            "ADAP_Version", "ADAP_Position_Status",
            "ADAP_Local", "ADAP_EUR", "ADAP_EURAOP",
        ],
        "key_measures": {
            "ADAP_Local": "ADAP Amount (Local currency)",
            "ADAP_EUR": "ADAP Amount (EUR)",
            "ADAP_EURAOP": "ADAP Amount (EUR at AOP rate)",
        },
        "aliases": ["adap"],
    },
    "dim_cat_account_fpl": {
        "description": "Account dimension  -  GL accounts with FSItem mapping and Cost Agility hierarchy (L1-L9)",
        "columns": [
            "Acct_PK", "AccountID", "PreCycleAcct_Ind", "Account_Description",
            "FSItemID", "FSItem_Description", "ControlledvsManaged", "PrimaryvsSecondary",
            "CostAgility_L1", "CostAgility_L2", "CostAgility_L3", "CostAgility_L4",
            "CostAgility_L5", "CostAgility_L6", "CostAgility_L7", "CostAgility_L8", "CostAgility_L9",
            "EF_Guardrail_Cost", "Overtime", "Regional_KPI_Indicator",
        ],
        "aliases": ["acct", "account"],
    },
    "dim_cat_mru": {
        "description": "MRU dimension  -  Management Reporting Unit hierarchy with BU/MAG levels (L1-L11)",
        "columns": [
            "MAG_PK", "MAG", "MAG_Description", "BU_Description", "BUID", "BUGroup",
            "MRU_L1", "MRU_L2", "MRU_L3", "MRU_L4", "MRU_L5",
            "MRU_L6", "MRU_L7", "MRU_L8", "MRU_L9", "MRU_L10", "MRU_L11",
            "BusinessModel", "DeliveryModel", "GBI",
        ],
        "aliases": ["mru"],
    },
    "dim_cat_market": {
        "description": "Market dimension  -  ORU/Company codes with BMC and INT hierarchies (L1-L8)",
        "columns": [
            "CountryCode", "ORU", "ORU_Description", "CompanyCode_Description",
            "CoCode", "CoCodePK", "CurrencyCode",
            "ORU_BMC_L1", "ORU_BMC_L2", "ORU_BMC_L3", "ORU_BMC_L4",
            "ORU_BMC_L5", "ORU_BMC_L6", "ORU_BMC_L7", "ORU_BMC_L8",
            "ORU_INT_L1", "ORU_INT_L2", "ORU_INT_L3", "ORU_INT_L4",
            "ORU_INT_L5", "ORU_INT_L6", "ORU_INT_L7", "ORU_INT_L8",
        ],
        "aliases": ["market", "mkt"],
    },
    "dim_cat_costcenter": {
        "description": "Cost Center dimension  -  50 columns including owner info, HTHR hierarchy, ET hierarchy, dedication flags",
        "columns": [
            "CC_PK_IPL", "CostCenter", "CostCenter_Description", "CoCode", "ORU_Description",
            "SourceID_CC", "PreCycle_CC", "CostCenter_OwnerName", "CostCenter_OwnerEmail",
            "FunctionalArea_CC", "HTHR_Node", "MAG_CC", "CountryCode_CC",
            "HTHR_L1", "HTHR_L2", "HTHR_L3", "HTHR_L4", "HTHR_L5",
            "ET_BP_Partner_Name", "ET_Name", "ET_Org",
            "ET-1_Name", "ET-1_Org", "ET-2_Name", "ET-2_Org",
            "ET-3_Name", "ET-3_Org",
            "ET_Custom1", "ET_Custom2", "ET_Custom3", "ET_Custom4", "ET_Custom5",
            "NAM_ET_BP_Partner_Name", "NAM_ET_Name", "NAM_ET_Org",
            "NAM_ET-1_Name", "NAM_ET-1_Org", "NAM_ET-2_Name", "NAM_ET-2_Org",
            "NAM_ET-3_Name", "NAM_ET-3_Org",
            "NAM_ET_Custom1", "NAM_ET_Custom2", "NAM_ET_Custom3", "NAM_ET_Custom4", "NAM_ET_Custom5",
            "Cluster_Dedicated_Shared", "BG_Dedicated_Shared",
            "BU_Dedicated_Shared", "Consolidated_Dedicated_Shared",
        ],
        "aliases": ["cc", "costcenter"],
    },
    "dim_cat_functional_area": {
        "description": "Functional Area dimension  -  functional area codes, descriptions, NMC flag",
        "columns": ["FuncAreaPK", "FunctionalArea", "FunctionalArea_Description", "NMC_Flag"],
        "aliases": ["fa"],
    },
    "dim_cat_date_fiscalperiod": {
        "description": "Date/Fiscal Period dimension  -  fiscal period to year/month mapping",
        "columns": ["FiscalPeriodID", "Year", "Month", "EndDate_Month"],
        "aliases": ["date", "fp"],
    },
    "dim_cat_security_oru": {
        "description": "Row Level Security dimension  -  email-to-CoCodePK mapping for data access control",
        "columns": ["Email", "CoCodePK_Security"],
        "aliases": ["sec", "security"],
    },
    "dim_cat_efr_hierarchy": {
        "description": "EFR Hierarchy dimension  -  FSItem + FunctionalArea composite hierarchy (8 levels)",
        "columns": [
            "EFR_FSItemID_FuncAreaID",
            "EFR_Level1ID", "EFR_Level1", "EFR_Level2ID", "EFR_Level2",
            "EFR_Level3ID", "EFR_Level3", "EFR_Level4ID", "EFR_Level4",
            "EFR_Level5ID", "EFR_Level5", "EFR_Level6ID", "EFR_Level6",
            "EFR_Level7ID", "EFR_Level7", "EFR_Level8ID", "EFR_Level8",
            "EFR_FSItemID", "EFR_FunctionalAreaID", "EFR_FSItemDescription", "EFR_Flag",
        ],
        "aliases": ["efr"],
    },
    "dim_cat_employee_master": {
        "description": "Employee Master dimension  -  masked employee attributes for blueprint joins",
        "columns": [
            "EmployeeMaskPK", "Compensation_Grade", "PayGroup_CountryCode",
            "JobFamily_Group", "AI_SI_Category", "Job_Category",
        ],
        "aliases": ["emp"],
    },
    "dim_cat_supervisory_org": {
        "description": "Supervisory Org dimension  -  SO hierarchy with Actuals/AOP/RoFo snapshots (L1-L5)",
        "columns": [
            "SO_ID",
            "SO_L1_Actuals", "SO_L1_AOP", "SO_L1_MarRoFo", "SO_L1_JunRoFo", "SO_L1_SepRoFo",
            "SO_L2_Actuals", "SO_L2_AOP", "SO_L2_MarRoFo", "SO_L2_JunRoFo", "SO_L2_SepRoFo",
            "SO_L3_Actuals", "SO_L3_AOP", "SO_L3_MarRoFo", "SO_L3_JunRoFo", "SO_L3_SepRoFo",
            "SO_L4_Actuals", "SO_L4_AOP", "SO_L4_MarRoFo", "SO_L4_JunRoFo", "SO_L4_SepRoFo",
            "SO_L5_Actuals", "SO_L5_AOP", "SO_L5_MarRoFo", "SO_L5_JunRoFo", "SO_L5_SepRoFo",
        ],
        "aliases": ["so"],
    },
    "dim_pflt_cc_mapping": {
        "description": "PFLT Cost Center mapping  -  maps user emails to cost centers via supervisory org",
        "columns": ["PFLT_SO", "PFLT_Email", "PFLT_CostCenter", "cc_pk_ipl"],
        "aliases": ["pflt", "map"],
    },
}

total_cols = sum(len(t["columns"]) for t in DATABASE_SCHEMA.values())
print(f"DATABASE_SCHEMA loaded: {len(DATABASE_SCHEMA)} tables, {total_cols} total columns")
print()
for name, info in DATABASE_SCHEMA.items():
    print(f"  {name:40s} {len(info['columns']):3d} cols  |  {info['description'][:60]}")