
class Handoff:
    @staticmethod
    def planner_to_sql(analysis, plan, is_multi_step, few_shot_text):
        return {
            "analysis": analysis,
            "execution_plan": plan,
            "is_multi_step": is_multi_step,
            "few_shot_context": few_shot_text,
        }

    @staticmethod
    def sql_to_validation(sql, analysis_text, few_shot_text):
        return {
            "generated_sql": sql,
            "analysis_text": analysis_text,
            "few_shot_context": few_shot_text,
        }

    @staticmethod
    def validation_to_supervisor(val_result, confidence, approved):
        return {
            "validation_result": val_result,
            "confidence_score": confidence,
            "sql_approved": approved,
        }
