from app.cost_genie_api.state.supervisor_state import SupervisorState
from app.cost_genie_api.config.agent_registry import get_agent_config
from app.cost_genie_api.state.trace import tc
from langchain_core.messages import HumanMessage,SystemMessage
from app.cost_genie_api.state.handoff import Handoff
import json
import re
import pandas as pd


def _match_column_hint(df: pd.DataFrame, hint: str) -> list:
    """
    Fuzzy-match a column hint from the user to actual DataFrame column names.
    
    E.g., "text" might match "Text", "text_description", "Document_Text"
    """
    hint_lower = hint.lower().replace(" ", "_")
    matches = []
    for col in df.columns:
        col_lower = col.lower()
        # Exact match
        if col_lower == hint_lower:
            return [col]
        # Substring match
        if hint_lower in col_lower or col_lower in hint_lower:
            matches.append(col)
    
    # If no substring match, try word overlap
    if not matches:
        hint_words = set(hint_lower.replace("_", " ").split())
        for col in df.columns:
            col_words = set(col.lower().replace("_", " ").split())
            if hint_words & col_words:
                matches.append(col)
    
    return matches


def apply_inline_translation(df: pd.DataFrame, instructions: list, verbose: bool = True) -> pd.DataFrame:
    """
    Apply inline translation instructions to a DataFrame.
    
    Handles:
      - translate_column: Translate specific column(s) from source to target language
      - translate_all: Translate all string columns to target language
    
    Returns: DataFrame with translated values (original df is not modified).
    """
    if df is None or df.empty or not instructions:
        return df
    
    translated_df = df.copy()
    pp_cfg = get_agent_config("postprocessor")
    
    for instr in instructions:
        if not isinstance(instr, dict):
            # Convert InlineInstruction to dict if needed
            instr = {"instruction_type": instr.instruction_type, "params": instr.params, "raw_text": instr.raw_text}
        
        itype = instr.get("instruction_type", "")
        params = instr.get("params", {})
        
        if itype == "translate_column":
            col_hint = params.get("column_hint", "")
            src_lang = params.get("source_lang", "auto")
            tgt_lang = params.get("target_lang", "English")
            
            matched_cols = _match_column_hint(translated_df, col_hint)
            if not matched_cols:
                if verbose:
                    print(f"    [!] Could not match column hint '{col_hint}' to any column")
                    print(f"    Available columns: {list(translated_df.columns)}")
                continue
            
            for col in matched_cols:
                if translated_df[col].dtype == 'object':
                    # Get unique non-null string values for efficient translation
                    unique_vals = translated_df[col].dropna().unique().tolist()
                    if not unique_vals:
                        continue
                    
                    sample_text = "\n".join(f"  {i+1}. {v}" for i, v in enumerate(unique_vals[:100]))
                    prompt = f"""Translate the following values from {src_lang} to {tgt_lang}.
Return ONLY a JSON object mapping original values to translated values.
Preserve any codes, numbers, or IDs exactly as-is. Only translate actual text.

Values:
{sample_text}

Return format: {{"original_value": "translated_value", ...}}"""
                    
                    try:
                        response = pp_cfg["llm"].invoke([
                            SystemMessage(content=pp_cfg["system_prompt"]),
                            HumanMessage(content=prompt),
                        ])
                        # Parse translation map
                        json_match = re.search(r'\{[\s\S]*\}', response.content)
                        if json_match:
                            translation_map = json.loads(json_match.group())
                            translated_df[col] = translated_df[col].map(
                                lambda x: translation_map.get(str(x), x) if pd.notna(x) else x
                            )
                            if verbose:
                                print(f"    [OK] Translated column '{col}' ({len(translation_map)} values)")
                    except Exception as e:
                        if verbose:
                            print(f"    [FAIL] Translation error for '{col}': {str(e)[:100]}")
        
        elif itype == "translate_all":
            tgt_lang = params.get("target_lang", "English")
            str_cols = translated_df.select_dtypes(include=["object"]).columns.tolist()
            
            if not str_cols:
                if verbose:
                    print("    All columns are numeric  -  no text to translate.")
                continue
            
            for col in str_cols:
                unique_vals = translated_df[col].dropna().unique().tolist()
                if not unique_vals:
                    continue
                
                sample_text = "\n".join(f"  {i+1}. {v}" for i, v in enumerate(unique_vals[:100]))
                prompt = f"""Translate the following values to {tgt_lang}.
Return ONLY a JSON object mapping original values to translated values.
If a value is already in {tgt_lang} or is a code/number, keep it unchanged.

Values:
{sample_text}

Return format: {{"original_value": "translated_value", ...}}"""
                
                try:
                    response = pp_cfg["llm"].invoke([
                        SystemMessage(content=pp_cfg["system_prompt"]),
                        HumanMessage(content=prompt),
                    ])
                    json_match = re.search(r'\{[\s\S]*\}', response.content)
                    if json_match:
                        translation_map = json.loads(json_match.group())
                        translated_df[col] = translated_df[col].map(
                            lambda x: translation_map.get(str(x), x) if pd.notna(x) else x
                        )
                        if verbose:
                            print(f"    [OK] Translated column '{col}' ({len(translation_map)} values)")
                except Exception as e:
                    if verbose:
                        print(f"    [FAIL] Translation error for '{col}': {str(e)[:100]}")
    
    return translated_df
def inline_translate_agent(state: SupervisorState) -> dict:
    """
    Inline Translation Agent  -  Graph node between Executor and Insight.
    
    If inline_instructions contain translation requests AND execution was successful,
    applies translation to the result DataFrame before passing to Insight Agent.
    """
    trace = list(state.get("trace", []))
    v = state.get("verbose", True)
    agent = "postprocessor"
    
    instructions = state.get("inline_instructions", [])
    exec_result = state.get("execution_result", {})
    result_df = exec_result.get("df", pd.DataFrame())
    
    # Check if we have translation instructions and data to translate
    translate_instructions = [
        i for i in instructions
        if (isinstance(i, dict) and i.get("instruction_type", "").startswith("translate"))
        or (hasattr(i, 'instruction_type') and i.instruction_type.startswith("translate"))
    ]
    
    if not translate_instructions or result_df is None or (isinstance(result_df, pd.DataFrame) and result_df.empty):
        # No translation needed  -  pass through
        trace = tc.event(trace, "TRANSLATE_SKIP", "No inline translation needed", agent)
        return {"trace": trace}
    
    if v:
        print(f"\n{'-' * 50}")
        print(f"  POSTPROCESSOR  -  Applying inline translation")
        print(f"{'-' * 50}")
        for instr in translate_instructions:
            raw = instr.get("raw_text", str(instr)) if isinstance(instr, dict) else instr.raw_text
            print(f"    > {raw}")
    
    trace = tc.event(trace, "TRANSLATE_START",
        f"Applying {len(translate_instructions)} translation instruction(s)", agent)
    
    translated_df = apply_inline_translation(result_df, translate_instructions, verbose=v)
    
    # Update the execution result with translated DataFrame
    updated_exec = dict(exec_result)
    updated_exec["df"] = translated_df
    updated_exec["data_summary"] = translated_df.head(5).to_string(index=False) if not translated_df.empty else ""
    
    trace = tc.event(trace, "TRANSLATE_DONE",
        f"Translation applied to {len(translated_df)} rows", agent)
    
    if v:
        print(f"  [OK] Translation applied to {len(translated_df)} rows")
    
    return {"execution_result": updated_exec, "trace": trace}


