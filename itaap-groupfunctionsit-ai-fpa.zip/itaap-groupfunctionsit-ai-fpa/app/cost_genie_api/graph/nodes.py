# === Retry / Recovery nodes ===
from app.cost_genie_api.state.supervisor_state import SupervisorState,ErrorCategory
from app.cost_genie_api.config.agent_registry import AgentRole,MAX_SQL_RETRIES,MAX_EXEC_RETRIES
from app.cost_genie_api.state.trace import tc

def sql_retry_node(state: SupervisorState) -> dict:
    """Increment SQL retry counter."""
    trace = list(state.get("trace", []))
    new_count = state.get("sql_retry_count", 0) + 1
    issues = state.get("validation_result", {}).get("issues", [])
    trace = tc.event(trace, "SUPERVISOR_SQL_RETRY",
        f"SQL retry {new_count}/{MAX_SQL_RETRIES}",
        AgentRole.SUPERVISOR.value, {"issues_to_fix": issues})
    if state.get("verbose", True):
        print(f"\n  (retry) SUPERVISOR: SQL retry {new_count}/{MAX_SQL_RETRIES}")
    return {"sql_retry_count": new_count, "trace": trace}


def exec_retry_node(state: SupervisorState) -> dict:
    """Increment execution retry counter with error classification context."""
    trace = list(state.get("trace", []))
    exec_result = state.get("execution_result", {})
    retries = exec_result.get("retries", 0) + 1
    error = exec_result.get("error", "")
    error_cat = exec_result.get("error_category", ErrorCategory.SYNTAX_ERROR)
    strategy = exec_result.get("error_strategy", "")

    error_history = list(state.get("error_history", []))
    error_history.append({
        "error_category": error_cat.value if hasattr(error_cat, 'value') else str(error_cat),
        "error_msg": error[:200],
        "attempt": retries,
        "strategy": strategy[:200],
    })

    recovery_mode = "normal"
    if len(error_history) >= 2:
        recovery_mode = "simplified"

    cat_str = error_cat.value if hasattr(error_cat, 'value') else str(error_cat)
    trace = tc.event(trace, "SUPERVISOR_EXEC_RETRY",
        f"Exec retry {retries}/{MAX_EXEC_RETRIES} [{cat_str}]",
        AgentRole.SUPERVISOR.value, {
            "error": error[:200], "strategy": strategy[:200], "recovery_mode": recovery_mode})

    if state.get("verbose", True):
        print(f"\n  (retry) SUPERVISOR: Exec retry {retries}/{MAX_EXEC_RETRIES} -> mode={recovery_mode}")

    return {
        "execution_result": {**exec_result, "retries": retries},
        "sql_retry_count": 0,
        "sql_approved": False,
        "validation_result": {"is_valid": False,
                              "issues": [f"EXECUTION ERROR [{cat_str}]: {error[:200]}"]},
        "error_history": error_history,
        "recovery_mode": recovery_mode,
        "trace": trace,
    }


def empty_recovery_node(state: SupervisorState) -> dict:
    """Handle empty/suspicious result recovery with progressive fallback."""
    trace = list(state.get("trace", []))
    exec_result = state.get("execution_result", {})
    quality = exec_result.get("quality_check", {})
    error_cat = exec_result.get("error_category", ErrorCategory.EMPTY_RESULT)

    error_history = list(state.get("error_history", []))
    error_history.append({
        "error_category": error_cat.value if hasattr(error_cat, 'value') else str(error_cat),
        "error_msg": "; ".join(quality.get("issues", []))[:200],
        "attempt": len(error_history) + 1,
        "strategy": "empty_recovery",
    })

    empty_count = sum(1 for eh in error_history
                     if eh.get("error_category") in (
                         ErrorCategory.EMPTY_RESULT.value,
                         ErrorCategory.SUSPICIOUS_DATA.value,
                     ))

    recovery_mode = "broadened" if empty_count <= 1 else "simplified"

    cat_str = error_cat.value if hasattr(error_cat, 'value') else str(error_cat)
    trace = tc.event(trace, "SUPERVISOR_EMPTY_RECOVERY",
        f"Empty/suspicious recovery [{cat_str}] -> mode={recovery_mode}",
        AgentRole.SUPERVISOR.value, {
            "quality_issues": quality.get("issues", []),
            "recovery_mode": recovery_mode,
            "attempt": empty_count,
        })

    if state.get("verbose", True):
        print(f"\n  (retry) SUPERVISOR: Empty recovery [{cat_str}] -> mode={recovery_mode}")
        for iss in quality.get("issues", [])[:2]:
            print(f"    - {iss[:120]}")

    return {
        "sql_retry_count": 0,
        "sql_approved": False,
        "validation_result": {"is_valid": False,
                              "issues": [f"DATA QUALITY [{cat_str}]: {iss}" for iss in quality.get("issues", [])[:3]]},
        "error_history": error_history,
        "recovery_mode": recovery_mode,
        "trace": trace,
    }


def next_step_node(state: SupervisorState) -> dict:
    """Advance to next step in multi-step plan."""
    trace = list(state.get("trace", []))
    plan = state.get("execution_plan", [])
    step_idx = state.get("current_step_idx", 0)
    step_results = dict(state.get("step_results", {}))

    exec_result = state.get("execution_result", {})
    step_id = step_idx + 1
    step_results[step_id] = {
        "sql": state.get("generated_sql", ""),
        "data_summary": exec_result.get("data_summary", "No data"),
    }

    new_idx = step_idx + 1
    next_desc = plan[new_idx].get("description", "") if new_idx < len(plan) else ""

    trace = tc.event(trace, "SUPERVISOR_NEXT_STEP",
        f"Step {step_id} -> Step {new_idx + 1}: {next_desc}",
        AgentRole.SUPERVISOR.value)

    if state.get("verbose", True):
        print(f"\n  -> SUPERVISOR: Step {step_id} done -> Step {new_idx + 1}: {next_desc}")

    return {
        "current_step_idx": new_idx,
        "step_results": step_results,
        "sql_retry_count": 0,
        "sql_approved": False,
        "validation_result": {},
        "confidence_score": {},
        "generated_sql": "",
        "recovery_mode": "normal",
        "trace": trace,
    }
