from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache
from typing import Optional
import os

class Settings(BaseSettings):
    AZURE_OPENAI_API_VERSION: Optional[str] = Field(default=None)
    AZURE_OPENAI_DEPLOYMENT: Optional[str] = Field(default=None)
    AZURE_OPENAI_DEPLOYMENT_MINI: Optional[str] = Field(default=None)
    FPA_PROD_SPN_CLIENTID: Optional[str] = Field(default=None)
    FPA_PROD_SPN_SECRET: Optional[str] = Field(default=None)
    FPA_PROD_SPN_TENANT_ID: Optional[str] = Field(default=None)
    FPA_AZURE_OPENAI_SCOPE: Optional[str] = Field(default=None)
    DATABRICKS_HOST: Optional[str] = Field(default=None)
    FPA_AZURE_OPENAI_BASE_URL: Optional[str] = Field(default=None)
    # ---databricks ------------------------------------------------------------
    DATABRICKS_SERVER_HOSTNAME: Optional[str] = Field(default=None)
    DATABRICKS_SCOPE :Optional[str]= Field(default=None)
    DATABRICKS_WAREHOUSEID : Optional[str]=Field(default=None)


    # Pydantic model_config replaces the inner Config class in Pydantic v2+
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",  # 'allow' would load any env var, 'ignore' only defined fields
    }

@lru_cache
def get_settings() -> Settings:
    return Settings()

settings: Settings = get_settings()

# Build endpoints
AZURE_ENDPOINT = f"{settings.FPA_AZURE_OPENAI_BASE_URL}/{settings.AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version={settings.AZURE_OPENAI_API_VERSION}"
AZURE_ENDPOINT_MINI = f"{settings.FPA_AZURE_OPENAI_BASE_URL}/{settings.AZURE_OPENAI_DEPLOYMENT_MINI}/chat/completions?api-version={settings.AZURE_OPENAI_API_VERSION}"

# Disable LangSmith/LangChain tracing at import time
os.environ["LANGCHAIN_TRACING_V2"] = "false"
os.environ["LANGCHAIN_TRACING"] = "false"
os.environ["LANGCHAIN_ENDPOINT"] = ""
os.environ["LANGSMITH_TRACING"] = "false"
os.environ.pop("LANGCHAIN_API_KEY", None)
os.environ.pop("LANGSMITH_API_KEY", None)
os.environ.pop("LANGCHAIN_PROJECT", None)
os.environ.pop("LANGSMITH_PROJECT", None)
