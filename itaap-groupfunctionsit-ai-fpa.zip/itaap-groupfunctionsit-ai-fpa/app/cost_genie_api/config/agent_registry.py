from enum import Enum
from app.cost_genie_api.llm.client import llm,llm_creative,llm_mini

from app.cost_genie_api.prompts.sql_prompt import SQL_SYSTEM_PROMPT,PLANNER_SYSTEM_PROMPT
from app.cost_genie_api.prompts.validation_prompt import VALIDATION_SYSTEM_PROMPT
from app.cost_genie_api.prompts.insight_prompt import INSIGHT_SYSTEM_PROMPT



class AgentRole(Enum):
    SUPERVISOR = "supervisor"
    PLANNER = "planner"
    SQL = "sql"
    VALIDATION = "validation"
    EXECUTOR = "executor"
    INSIGHT = "insight"
    POSTPROCESSOR = "postprocessor"  

AGENT_CONFIG = {
    "planner": {
        "name": "Planner Agent",
        "role": AgentRole.PLANNER,
        "llm": llm_mini,
        "system_prompt": PLANNER_SYSTEM_PROMPT,
    },
    "sql": {
        "name": "SQL Generator Agent",
        "role": AgentRole.SQL,
        "llm": llm,
        "system_prompt": SQL_SYSTEM_PROMPT,
    },
    "validation": {
        "name": "Validation Agent",
        "role": AgentRole.VALIDATION,
        "llm": llm_mini,
        "system_prompt": VALIDATION_SYSTEM_PROMPT,
        "confidence_threshold": 6,
    },
    "executor": {
        "name": "Executor Agent",
        "role": AgentRole.EXECUTOR,
        "llm": None,
        "system_prompt": "",
    },
    "insight": {
        "name": "Insight Agent",
        "role": AgentRole.INSIGHT,
        "llm": llm_creative,
        "system_prompt": INSIGHT_SYSTEM_PROMPT,
    },
    "postprocessor": {
        "name": "PostProcessor Agent",
        "role": AgentRole.POSTPROCESSOR,
        "llm": llm_mini,
        "system_prompt": """You are a PostProcessor Agent for Philips FinanceBI.
Your tasks include:
1. COLUMN TRANSLATION: When given specific columns of a DataFrame containing non-English text,
   translate ONLY the specified columns to English. Preserve all numbers, codes, IDs, and column headers.
   Return the full data as a clean markdown table with translations applied inline.
2. FULL TRANSLATION: When given an entire DataFrame, translate all non-English text columns to English.
3. EXPLANATION: Explain Philips finance terminology clearly and concisely.

CRITICAL: When translating, you must return a COMPLETE table with ALL original rows.
Only change the text values that need translation. Keep everything else exactly as-is.
Always respond in English. Be concise and professional.""",
    },
    "supervisor": {
        "name": "Supervisor",
        "role": AgentRole.SUPERVISOR,
        "llm": None,
        "system_prompt": "",
        "max_sql_retries": 2,
        "max_exec_retries": 2,
        "max_empty_retries": 2,
    },
}


# Helper functions

def get_agent_config(name):
    return AGENT_CONFIG[name]

def get_agent_system_prompt(name):
    return AGENT_CONFIG[name]["system_prompt"]

def get_agent_llm(name):
    return AGENT_CONFIG[name]["llm"]

print("Agent Registry initialized (v6.2  -  with PostProcessor role + InlineInstruction):")
for name, cfg in AGENT_CONFIG.items():
    llm_name = cfg["llm"].__class__.__name__ if cfg["llm"] else "None"
    sp_len = len(cfg["system_prompt"])
    print(f"  {cfg['name']:.<30} LLM={llm_name:<20} prompt={sp_len:>5} chars")

MAX_SQL_RETRIES = AGENT_CONFIG["supervisor"]["max_sql_retries"]
MAX_EXEC_RETRIES = AGENT_CONFIG["supervisor"]["max_exec_retries"]
MAX_EMPTY_RETRIES = AGENT_CONFIG["supervisor"]["max_empty_retries"]