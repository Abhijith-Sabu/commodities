import pandas as pd
from langchain_core.messages import SystemMessage, HumanMessage
from app.cost_genie_api.config.agent_registry import get_agent_config


def translate_dataframe(df: pd.DataFrame, user_query: str = "") -> str:
    """Translate non-English text in a DataFrame to English using LLM (standalone mode)."""
    if df is None or df.empty:
        return "No data available to translate."
    
    str_cols = df.select_dtypes(include=["object"]).columns.tolist()
    if not str_cols:
        return "All columns are numeric  -  no text to translate."
    
    sample = df.head(50)
    sample_text = sample[str_cols].to_string(index=False)
    
    prompt = f"""The following table data was returned from a Philips FinanceBI SQL query.
Some text values may be in non-English languages (German, Dutch, Chinese, etc.).

Please:
1. Identify any non-English text in the data
2. Translate ALL non-English text to English
3. Return the complete table in clean markdown format with translations applied
4. Preserve all numbers, codes (like cost center IDs), and column headers exactly as-is
5. If all text is already in English, just confirm that and return the table as-is

User context: {user_query}

Data:
{sample_text}
"""
    
    pp_cfg = get_agent_config("postprocessor")
    response = pp_cfg["llm"].invoke([
        SystemMessage(content=pp_cfg["system_prompt"]),
        HumanMessage(content=prompt),
    ])
    return response.content

