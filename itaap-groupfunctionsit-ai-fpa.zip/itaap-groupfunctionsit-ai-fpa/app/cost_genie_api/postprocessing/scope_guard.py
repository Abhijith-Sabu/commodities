# handle_out_of_scope migrated verbatim from notebook

def handle_out_of_scope(query: str) -> str:
    """Handle non-finance questions with a polite scope-limited response."""
    return (
        "I appreciate the question, but I'm currently focused on Philips FinanceBI cost data analysis. "
        "I can help you with:\n\n"
        "  - **Cost & Variance Analysis**  -  CY vs AOP, Forecast, Last Year comparisons\n"
        "  - **FTE & Headcount**  -  Full-time equivalent data across business units\n"
        "  - **Drill-Down Analysis**  -  Find root causes of variances by MRU, ORU, Cost Center\n"
        "  - **SAP/PPS Reconciliation**  -  Query payroll and SAP recon data\n"
        "  - **Multi-Period Comparisons**  -  YTD, QTD, month-over-month analysis\n"
        "  - **Finance Terminology**  -  Explain abbreviations like AOP, EURAOP, S&W, etc.\n\n"
        "Try asking something like:\n"
        '  "Summarize Travel variance between CY & AOP for 2025011 YTD by MRU L5"\n'
        '  "What is the total FTE for BUGroup IGT for 2026001?"\n'
        '  "What is AOP?"'
    )
