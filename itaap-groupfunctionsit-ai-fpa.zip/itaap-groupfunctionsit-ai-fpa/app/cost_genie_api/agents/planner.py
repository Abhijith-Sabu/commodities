from app.cost_genie_api.state.supervisor_state import SupervisorState
from app.cost_genie_api.config.agent_registry import get_agent_config,get_agent_system_prompt
from app.cost_genie_api.state.trace import tc
from app.cost_genie_api.retrieval.hybrid_retriever import select_relevant_examples
from langchain_core.messages import HumanMessage,SystemMessage
from app.cost_genie_api.state.handoff import Handoff
from app.cost_genie_api.preprocessing.intent_classifier import extract_email_from_query,identify_fact_table,expand_abbreviations,detect_query_pattern
import json
import re

def planner_agent(state: SupervisorState) -> dict:
    """Planner Agent: Analyzes query, detects pattern, produces execution plan."""
    cfg = get_agent_config("planner")
    trace = list(state.get("trace", []))
    v = state.get("verbose", True)
    agent = cfg["role"].value

    if v:
        print(f"\n{'-' * 50}")
        print(f"  PLANNER AGENT  -  Analyzing query")
        print(f"{'-' * 50}")

    trace = tc.event(trace, "PLAN_START", "Analyzing user query", agent)

    user_query = state["user_query"]
    expanded = expand_abbreviations(user_query)
    pattern = detect_query_pattern(user_query)
    email = extract_email_from_query(user_query)
    fact_table = identify_fact_table(expanded)

    relevant_examples = select_relevant_examples(expanded, top_k=3)
    few_shot_text = ""
    if relevant_examples:
        parts = []
        for i, ex in enumerate(relevant_examples, 1):
            parts.append(f"Example {i}: {ex['input'][:100]}...")
        few_shot_text = "\n".join(parts)

    prompt = f"""Analyze this query and produce a structured execution plan.

User Query: {user_query}
Expanded: {expanded}
Detected Pattern: {pattern}
Suggested Fact Table: {fact_table}
{f'RLS Email: {email}' if email else 'No RLS required'}

{f'Similar examples found:\n{few_shot_text}' if few_shot_text else ''}

Return your analysis as JSON."""

    planner_sys = get_agent_system_prompt("planner")
    response = cfg["llm"].invoke([
        SystemMessage(content=planner_sys),
        HumanMessage(content=prompt),
    ])

    try:
        text = response.content
        json_match = re.search(r'\{[\s\S]*\}', text)
        if json_match:
            analysis = json.loads(json_match.group())
        else:
            analysis = {"fact_table": fact_table, "pattern": pattern}
    except (json.JSONDecodeError, AttributeError):
        analysis = {"fact_table": fact_table, "pattern": pattern}

    is_multi_step = analysis.get("is_multi_step", pattern == "D")
    plan = analysis.get("steps", [{"step": 1, "description": user_query, "depends_on": None}])

    trace = tc.event(trace, "PLAN_DONE",
        f"Pattern={pattern}, fact={analysis.get('fact_table', fact_table)}, multi_step={is_multi_step}",
        agent, {"pattern": pattern, "fact_table": fact_table})

    if v:
        print(f"  Pattern: {pattern}")
        print(f"  Fact table: {analysis.get('fact_table', fact_table)}")
        print(f"  Multi-step: {is_multi_step}")
        if email:
            print(f"  RLS email: {email}")

    handoff = Handoff.planner_to_sql(analysis, plan, is_multi_step, few_shot_text)
    trace = tc.handoff(trace, "planner", "sql", list(handoff.keys()))
    return {**handoff, "trace": trace}


print("Planner Agent defined (pattern detection, abbreviation expansion, fact table identification).")
