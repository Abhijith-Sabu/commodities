# insight_agent migrated verbatim from notebook
from app.cost_genie_api.state.supervisor_state import SupervisorState
from app.cost_genie_api.config.agent_registry import get_agent_config,get_agent_system_prompt
from app.cost_genie_api.state.trace import tc
from app.cost_genie_api.prompts.insight_prompt import INSIGHTS_PROMPT
from langchain_core.messages import HumanMessage,SystemMessage
import pandas as pd



def insight_agent(state: SupervisorState) -> dict:
    """Insight Agent: Executive-level business analysis with dedicated system prompt."""
    cfg = get_agent_config("insight")
    trace = list(state.get("trace", []))
    v = state.get("verbose", True)
    agent = cfg["role"].value

    if v:
        print(f"\n{'-' * 60}")
        print(f"  {cfg['name']}  -  Generating business insights")
        print(f"{'-' * 60}")

    trace = tc.event(trace, "INSIGHT_START", "Generating insights", agent)

    exec_result = state.get("execution_result", {})
    result_df = exec_result.get("df", pd.DataFrame())

    if result_df is None or (isinstance(result_df, pd.DataFrame) and result_df.empty):
        insights = "No data returned. Consider broadening filters or verifying dimension values."
        trace = tc.event(trace, "INSIGHT_NO_DATA", "No data for analysis", agent)
    else:
        results_text = result_df.to_string(index=False, max_rows=50)
        
        # Add translation context to insight prompt if translations were applied
        inline_instructions = state.get("inline_instructions", [])
        translation_note = ""
        if any(
            (isinstance(i, dict) and i.get("instruction_type", "").startswith("translate"))
            or (hasattr(i, 'instruction_type') and i.instruction_type.startswith("translate"))
            for i in inline_instructions
        ):
            translation_note = "\n\nNote: Some columns have been translated from their original language to English."
        
        user_msg = INSIGHTS_PROMPT.format(
            user_query=state["user_query"], results_text=results_text
        ) + translation_note
        
        insight_sys = get_agent_system_prompt("insight")
        response = cfg["llm"].invoke([
            SystemMessage(content=insight_sys),
            HumanMessage(content=user_msg),
        ])
        insights = response.content
        trace = tc.event(trace, "INSIGHT_DONE", f"Insights: {len(insights)} chars", agent)

    if v:
        print(f"  Generated {len(insights)} chars of analysis")

    return {"insights": insights, "trace": trace}