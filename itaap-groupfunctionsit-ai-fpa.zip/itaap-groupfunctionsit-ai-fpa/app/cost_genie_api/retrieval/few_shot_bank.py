FEW_SHOT_EXAMPLES = [
    {
        "input": """UserQuery: 
What is the total cost for fiscal period 2025008 by Functional Area?""",
        "analysis": """You want to see the total cost for fiscal period 2025008 broken down by each Functional Area.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_functional_area
Calculated an answer based on these steps
Filter the data for fiscal period 2025008.
Group the data by Functional Area.
Sum the PostActuals_Local cost values for each Functional Area, treating nulls as zero.
Convert the summed costs to thousands and round them to whole numbers.
Order the results by total cost in descending order to show the highest costs first.""",
        "output": """SELECT
  fa.FunctionalArea AS FunctionalArea,
  ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_Local, 0)), 1000)) AS TotalCost_k
FROM
  qa_wb.financebi.cat_fpl_prevspostalloc fpl
    INNER JOIN qa_wb.financebi.dim_cat_functional_area fa
      ON fpl.FuncAreaPK = fa.FuncAreaPK
WHERE
  fpl.FiscalPeriodID = '2025008'
  AND fa.FunctionalArea IS NOT NULL
GROUP BY
  fa.FunctionalArea
ORDER BY
  TotalCost_k DESC""",
    },
    {
        "input": """What is the total cost for fiscal period 2025008 by MAG (Business Area)?""",
        "analysis": """You want to see the total cost for the fiscal period 2025008 broken down by business area, using the MAG description to represent each business area. The costs are summed up, converted to thousands, and rounded to whole numbers. The results are ordered from the highest to the lowest total cost by business area.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
Calculated an answer based on these steps
Filter the data for the fiscal period 2025008.
Group the data by the business area description (MAG_Description).
Sum the local post actual costs for each business area, treating any missing values as zero.
Convert the summed costs to thousands and round to the nearest whole number.
Order the results by total cost in descending order to show the business areas with the highest costs first.""",
        "output": """SELECT
  mru.MAG_Description AS Business_Area,
  ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_Local, 0)), 1000)) AS Total_Cost_k
FROM
  qa_wb.financebi.cat_fpl_prevspostalloc fpl
    INNER JOIN qa_wb.financebi.dim_cat_mru mru
      ON fpl.MAG_PK = mru.MAG_PK
WHERE
  fpl.FiscalPeriodID = '2025008'
  AND mru.MAG_Description IS NOT NULL
GROUP BY
  mru.MAG_Description
ORDER BY
  Total_Cost_k DESC""",
    },
    {
        "input": """Summarize & Provide Sales to Thirds variance between CY & AOP for 2026001 YTD in EURAOP by ORU BMC L5 for MRU L4 D&T. Include totals at bottom of each column""",
        "analysis": """You want to see a summary of the variance between current year actual sales to third parties and the annual operating plan for the fiscal period 2026001 year-to-date, broken down by the ORU BMC Level 5 market segment for the MRU Level 4 segment D&T. The results include the current year actuals, the plan values, and the variance, all formatted in thousands of EUR and with totals at the bottom.
Understanding the question
Sales to Thirds  -  The term 'Sales to Thirds' is assumed to refer to the Cost Agility Level 4 category containing this phrase. However, it could alternatively refer to a different account classification or metric related to sales to third parties.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_market
dim_cat_mru
Calculated an answer based on these steps
Filter data for fiscal period 2026001 in year 2026 and MRU Level 4 containing 'D&T'.
Focus on accounts related to 'Sales to Thirds' in the Cost Agility Level 4 category.
Aggregate the current year actuals and AOP plan values by ORU BMC Level 5 market segment.
Calculate the variance between current year actuals and AOP plan values.
Format the results in thousands of EUR and include a total row at the bottom for all columns.""",
        "output": """WITH base AS (
  SELECT
    `market`.`ORU_BMC_L5` AS `ORU_BMC_L5`,
    SUM(
      CASE
        WHEN
          `acct`.`CostAgility_L4` ILIKE '%Sales to Thirds%'
        THEN
          COALESCE(`fpl`.`PostActuals_Local`, 0)
        ELSE 0
      END
    ) AS `CY_Sales_to_Thirds`,
    SUM(
      CASE
        WHEN
          `acct`.`CostAgility_L4` ILIKE '%Sales to Thirds%'
        THEN
          COALESCE(`fpl`.`PostAOP_Local`, 0)
        ELSE 0
      END
    ) AS `AOP_Sales_to_Thirds`
  FROM
    `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` `fpl`
      JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` `acct`
        ON `fpl`.`Acct_PK` = `acct`.`Acct_PK`
      JOIN `qa_wb`.`financebi`.`dim_cat_market` `market`
        ON `fpl`.`CoCodePK` = `market`.`CoCodePK`
      JOIN `qa_wb`.`financebi`.`dim_cat_mru` `mru`
        ON `fpl`.`MAG_PK` = `mru`.`MAG_PK`
      JOIN `qa_wb`.`financebi`.`dim_cat_date_fiscalperiod` `date`
        ON `fpl`.`FiscalPeriodID` = `date`.`FiscalPeriodID`
  WHERE
    `date`.`Year` = '2026'
    AND `fpl`.`FiscalPeriodID` = '2026001'
    AND `mru`.`MRU_L4` ILIKE '%D&T%'
    AND `market`.`ORU_BMC_L5` IS NOT NULL
  GROUP BY
    `market`.`ORU_BMC_L5`
)
SELECT
  `ORU_BMC_L5`,
  FORMAT_NUMBER(ROUND(try_divide(`CY_Sales_to_Thirds`, 1000)), '#,###') AS `CY_Sales_to_Thirds_k`,
  FORMAT_NUMBER(ROUND(try_divide(`AOP_Sales_to_Thirds`, 1000)), '#,###') AS `AOP_Sales_to_Thirds_k`,
  FORMAT_NUMBER(
    ROUND(try_divide(`CY_Sales_to_Thirds` - `AOP_Sales_to_Thirds`, 1000)),
    '#,###'
  ) AS `Variance_k`
FROM
  base
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(ROUND(try_divide(SUM(`CY_Sales_to_Thirds`), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(`AOP_Sales_to_Thirds`), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(`CY_Sales_to_Thirds` - `AOP_Sales_to_Thirds`), 1000)), '#,###')
FROM
  base""",
    },
    {
        "input": """Summarize & Provide variance between CY & AOP for 2025011 for ORU BMC L5 North America Region by MRU L5. From the result find the MRU L5 with Highest variance and Find the CostCenter causing this deviation.""",
        "analysis": """You want to see the variance between current year actuals and plan (AOP) for fiscal period 2025011 in the North America Region, broken down by MRU L5 business segment. Then, from this result, you want to identify the MRU L5 segment with the highest variance and find the cost centers within that segment causing the largest deviations.
Understanding the question
Variance definition  -  The query calculates variance as the difference between PostActuals (actual costs) and PostAOP (plan costs) for the same fiscal period. Alternative variance definitions could include percentage variance or variance over different time periods.
North America Region filter  -  The filter uses ILIKE '%North America Region%' on the ORU_BMC_L5 field, assuming this matches the intended region. Alternative interpretations could use different levels of the ORU BMC hierarchy or different region names.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_market
Calculated an answer based on these steps
Calculate total actual costs and planned costs for fiscal period 2025011 in 2025 for each MRU L5 segment within the North America Region.
Compute the variance between actual costs and planned costs for each MRU L5 segment, scaling values to thousands and rounding.
Identify the MRU L5 segment with the highest variance.
Within that top MRU L5 segment, calculate actual costs, planned costs, and variance for each cost center, again scaling and rounding values.
Order the cost centers by variance to highlight those causing the largest deviations.""",
        "output": """WITH mru_l5_variance AS (
  SELECT
    mru.MRU_L5 AS MRU_L5,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_Local, 0)), 1000)) AS CY_Local_k,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_Local, 0)), 1000)) AS AOP_Local_k,
    ROUND(
      try_divide(SUM(COALESCE(fpl.PostActuals_Local, 0) - COALESCE(fpl.PostAOP_Local, 0)), 1000)
    ) AS Variance_k
  FROM
    `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` fpl
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` acct
        ON fpl.Acct_PK = acct.Acct_PK
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_market` market
        ON fpl.CoCodePK = market.CoCodePK
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_date_fiscalperiod` date
        ON fpl.FiscalPeriodID = date.FiscalPeriodID
  WHERE
    date.Year = '2025'
    AND fpl.FiscalPeriodID = '2025011'
    AND market.ORU_BMC_L5 ILIKE '%North America Region%'
    AND mru.MRU_L5 IS NOT NULL
  GROUP BY
    mru.MRU_L5
),
top_mru_l5 AS (
  SELECT
    MRU_L5,
    Variance_k
  FROM
    mru_l5_variance
  WHERE
    Variance_k = (
      SELECT
        MAX(Variance_k)
      FROM
        mru_l5_variance
    )
  LIMIT 1
)
SELECT
  mru.MRU_L5 AS MRU_L5,
  cc.CostCenter AS CostCenter,
  ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_Local, 0)), 1000)) AS CY_Local_k,
  ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_Local, 0)), 1000)) AS AOP_Local_k,
  ROUND(
    try_divide(SUM(COALESCE(fpl.PostActuals_Local, 0) - COALESCE(fpl.PostAOP_Local, 0)), 1000)
  ) AS Variance_k
FROM
  `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` fpl
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` acct
      ON fpl.Acct_PK = acct.Acct_PK
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
      ON fpl.MAG_PK = mru.MAG_PK
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_market` market
      ON fpl.CoCodePK = market.CoCodePK
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_date_fiscalperiod` date
      ON fpl.FiscalPeriodID = date.FiscalPeriodID
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_costcenter` cc
      ON fpl.CC_PK_IPL = cc.CC_PK_IPL
    INNER JOIN top_mru_l5 t
      ON mru.MRU_L5 = t.MRU_L5
WHERE
  date.Year = '2025'
  AND fpl.FiscalPeriodID = '2025011'
  AND market.ORU_BMC_L5 ILIKE '%North America Region%'
  AND mru.MRU_L5 IS NOT NULL
  AND cc.CostCenter IS NOT NULL
GROUP BY
  mru.MRU_L5,
  cc.CostCenter
ORDER BY
  Variance_k DESC""",
    },
    {
        "input": """Summarize & Provide FTE and Salaries and Wages variance between CY & AOP for 2026001 ITM by MAG for BUGroup Finance. Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP""",
        "analysis": """You want to see the variance between current year and plan for FTE and Salaries & Wages costs for the first fiscal period of 2026, broken down by MAG within the Finance business group, with amounts formatted in thousands and a total row included.
Understanding the question
FTE and Salaries & Wages definitions  -  The query assumes FTE and Salaries & Wages are identified by the CostAgility_L4 field using ILIKE '%FTE%' and ILIKE '%Salaries & Wages%'. Alternative definitions or categorizations could exist.
Variance calculation method  -  Variance is calculated as the absolute difference between current year actuals and plan (AOP) values, not as a percentage or relative difference. The user might have intended a different variance calculation.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_date_fiscalperiod
Referenced trusted example
Summarize & Provide variance between CY & AOP for 2025011 for ORU BMC L5 North America Region by MRU L5. From the result find the MRU L5 with Highest variance and Find the CostCenter causing this deviation.
Calculated an answer based on these steps
Filter data for fiscal period 2026001 and year 2026.
Limit results to the Finance business group and non-null MAG descriptions.
Calculate total FTE and Salaries & Wages costs for current year (CY) and plan (AOP) by MAG.
Compute the variance between CY and AOP for both FTE and Salaries & Wages.
Format all amounts in thousands with thousand separators and no decimals, and add a total row summing all MAGs.""",
        "output": """WITH base AS (
  SELECT
    mru.MAG_Description AS MAG,
    SUM(
      CASE
        WHEN acct.CostAgility_L4 ILIKE '%Salaries & Wages%' THEN COALESCE(fpl.PostActuals_Local, 0)
        ELSE 0
      END
    ) AS CY_Salaries_Wages,
    SUM(
      CASE
        WHEN acct.CostAgility_L4 ILIKE '%Salaries & Wages%' THEN COALESCE(fpl.PostAOP_Local, 0)
        ELSE 0
      END
    ) AS AOP_Salaries_Wages,
    SUM(
      CASE
        WHEN acct.CostAgility_L4 ILIKE '%FTE%' THEN COALESCE(fpl.PostActuals_Local, 0)
        ELSE 0
      END
    ) AS CY_FTE,
    SUM(
      CASE
        WHEN acct.CostAgility_L4 ILIKE '%FTE%' THEN COALESCE(fpl.PostAOP_Local, 0)
        ELSE 0
      END
    ) AS AOP_FTE
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_PK
      JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      JOIN qa_wb.financebi.dim_cat_date_fiscalperiod date
        ON fpl.FiscalPeriodID = date.FiscalPeriodID
  WHERE
    date.Year = '2026'
    AND fpl.FiscalPeriodID = '2026001'
    AND mru.BUGroup ILIKE '%Finance%'
    AND mru.MAG_Description IS NOT NULL
  GROUP BY
    mru.MAG_Description
)
SELECT
  MAG,
  FORMAT_NUMBER(ROUND(try_divide(CY_FTE, 1000)), '#,###') AS CY_FTE_k,
  FORMAT_NUMBER(ROUND(try_divide(AOP_FTE, 1000)), '#,###') AS AOP_FTE_k,
  FORMAT_NUMBER(ROUND(try_divide(CY_FTE - AOP_FTE, 1000)), '#,###') AS FTE_Variance_k,
  FORMAT_NUMBER(ROUND(try_divide(CY_Salaries_Wages, 1000)), '#,###') AS CY_Salaries_Wages_k,
  FORMAT_NUMBER(ROUND(try_divide(AOP_Salaries_Wages, 1000)), '#,###') AS AOP_Salaries_Wages_k,
  FORMAT_NUMBER(
    ROUND(try_divide(CY_Salaries_Wages - AOP_Salaries_Wages, 1000)),
    '#,###'
  ) AS Salaries_Wages_Variance_k
FROM
  base
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(ROUND(try_divide(SUM(CY_FTE), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(AOP_FTE), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(CY_FTE - AOP_FTE), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(CY_Salaries_Wages), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(AOP_Salaries_Wages), 1000)), '#,###'),
  FORMAT_NUMBER(ROUND(try_divide(SUM(CY_Salaries_Wages - AOP_Salaries_Wages), 1000)), '#,###')
FROM
  base""",
    },
    {
        "input": """Summarize & Provide Travel variance between CY & AOP for 2025011 YTD by MRU L5 for ORU BMC L5 North America Region.""",
        "analysis": """You want to see a summary of the Travel cost variance between current year (CY) actuals and AOP for fiscal year 2025 year-to-date up to period 2025011, broken down by MRU L5 within the ORU BMC L5 North America Region.
Understanding the question
Travel definition  -  The query assumes Travel costs are identified using the CostAgility_L4 field with ILIKE '%Travel%'. If Travel is categorized differently (for example under a different cost hierarchy level), the results could vary.
YTD 2025011  -  Interpreted as fiscal periods from 2025001 through 2025011 within calendar year 2025.
Variance calculation  -  Variance is calculated as CY (PostActuals_Local) minus AOP (PostAOP_Local), aggregated over the YTD range.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_market
dim_cat_date_fiscalperiod
Calculated an answer based on these steps
Filter data for Calendar Year 2025 and fiscal periods between 2025001 and 2025011 to reflect YTD 2025011.
Restrict results to accounts where CostAgility_L4 contains 'Travel'.
Limit the market to ORU BMC L5 matching 'North America Region'.
Exclude null MRU L5 values.
Aggregate PostActuals_Local (CY) and PostAOP_Local (AOP) amounts by MRU L5, treating null values as zero.
Convert all monetary values to thousands and round to whole numbers.
Compute variance as the difference between CY and AOP in thousands.
Exclude insignificant variances between -1k and +1k using a HAVING clause.
Order the results by variance in descending order to highlight the largest deviations first.""",
        "output": """SELECT
  `mru`.`MRU_L5` AS `MRU_L5`,
  ROUND(try_divide(SUM(COALESCE(`fpl`.`PostActuals_Local`, 0)), 1000)) AS `CY_Local_k`,
  ROUND(try_divide(SUM(COALESCE(`fpl`.`PostAOP_Local`, 0)), 1000)) AS `AOP_Local_k`,
  ROUND(
    try_divide(
      (SUM(COALESCE(`fpl`.`PostActuals_Local`, 0)) - SUM(COALESCE(`fpl`.`PostAOP_Local`, 0))), 1000
    )
  ) AS `Variance_k`
FROM
  `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` `fpl`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` `acct`
      ON `fpl`.`Acct_PK` = `acct`.`Acct_PK`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` `mru`
      ON `fpl`.`MAG_PK` = `mru`.`MAG_PK`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_market` `market`
      ON `fpl`.`CoCodePK` = `market`.`CoCodePK`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_date_fiscalperiod` `date`
      ON `fpl`.`FiscalPeriodID` = `date`.`FiscalPeriodID`
WHERE
  `acct`.`CostAgility_L4` ILIKE '%Travel%'
  AND `market`.`ORU_BMC_L5` ILIKE '%North America Region%'
  AND `date`.`Year` = '2025'
  AND `fpl`.`FiscalPeriodID` >= '2025001'
  AND `fpl`.`FiscalPeriodID` <= '2025011'
  AND `mru`.`MRU_L5` IS NOT NULL
GROUP BY
  `mru`.`MRU_L5`
HAVING
  try_divide(
    ABS(SUM(COALESCE(`fpl`.`PostActuals_Local`, 0)) - SUM(COALESCE(`fpl`.`PostAOP_Local`, 0))), 1000
  ) NOT BETWEEN 0 AND 1
ORDER BY
  `Variance_k` DESC""",
    },
    {
        "input": """Summarize & Provide [FTE] and [Salaries and Wages] variance between [CY & FC] for [2025011 ITM] by [MAG] for [BUGroup Finance]. Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_blueprint_prevspostalloc
dim_cat_mru
dim_cat_security_oru
cat_fpl_prevspostalloc
dim_cat_account_fpl
Calculated an answer based on these steps
Aggregate FTE values for the fiscal period 2025011 for current year and forecast, grouped by MAG within the Finance business group.
Aggregate Salaries & Wages amounts for the same period and grouping, filtered by Cost Agility category and user email for row-level security.
Calculate the variance between current year and forecast for both FTE and Salaries & Wages.
Format all numeric results with thousand separators and no decimals.
Add a total row summing all MAG values for each metric.""",
        "output": """WITH fte AS (
  SELECT
    mru.MAG,
    ROUND(
      COALESCE(
        SUM(
          CASE
            WHEN bp.FiscalPeriodID = '2025011' THEN bp.PostActuals_Alloc_FTE
          END
        ),
        0
      )
    ) AS FTE_CY,
    ROUND(
      COALESCE(
        SUM(
          CASE
            WHEN bp.FiscalPeriodID = '2025011' THEN bp.PostJunFC_Alloc_FTE
          END
        ),
        0
      )
    ) AS FTE_FC
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    mru.BUGroup ILIKE '%Finance%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MAG
),
sw AS (
  SELECT
    mru.MAG,
    ROUND(
      COALESCE(
        SUM(
          CASE
            WHEN fpl.FiscalPeriodID = '2025011' THEN try_divide(fpl.PostActuals_EURAOP, 1000)
          END
        ),
        0
      )
    ) AS SW_CY,
    ROUND(
      COALESCE(
        SUM(
          CASE
            WHEN fpl.FiscalPeriodID = '2025011' THEN try_divide(fpl.PostJunFC_EURAOP, 1000)
          END
        ),
        0
      )
    ) AS SW_FC
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    mru.BUGroup ILIKE '%Finance%'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MAG
)
SELECT
  COALESCE(fte.MAG, sw.MAG) AS MAG,
  FORMAT_NUMBER(COALESCE(FTE_CY, 0), '#,###') AS FTE_CY,
  FORMAT_NUMBER(COALESCE(FTE_FC, 0), '#,###') AS FTE_FC,
  FORMAT_NUMBER(COALESCE(FTE_CY, 0) - COALESCE(FTE_FC, 0), '#,###') AS FTE_Variance,
  FORMAT_NUMBER(COALESCE(SW_CY, 0), '#,###') AS S_W_CY,
  FORMAT_NUMBER(COALESCE(SW_FC, 0), '#,###') AS S_W_FC,
  FORMAT_NUMBER(COALESCE(SW_CY, 0) - COALESCE(SW_FC, 0), '#,###') AS S_W_Variance
FROM
  fte
    FULL OUTER JOIN sw
      ON fte.MAG = sw.MAG
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(SUM(COALESCE(FTE_CY, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(FTE_FC, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(FTE_CY, 0) - COALESCE(FTE_FC, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(SW_CY, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(SW_FC, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(SW_CY, 0) - COALESCE(SW_FC, 0)), '#,###')
FROM
  fte
    FULL OUTER JOIN sw
      ON fte.MAG = sw.MAG""",
    },
    {
        "input": """Summarize Actuals & FTE for S&W for Current Year by Cost Center for Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_costcenter
dim_pflt_cc_mapping
dim_cat_account_fpl
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Identify Cost Centers linked to the email Ravishankar.Ramakrishnan@philips.com.
Calculate the total salaries and wages actuals in thousands of euros for each identified Cost Center for the year 2026.
Calculate the total full-time equivalent (FTE) count for each identified Cost Center for the year 2026.
Combine the salaries and wages actuals and FTE counts by Cost Center for the final summary.""",
        "output": """WITH sw_actuals AS (
  SELECT
    cc.CostCenter AS Cost_Center,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS S_W_Actuals_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON fpl.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_pflt_cc_mapping map
        ON cc.CostCenter = map.PFLT_CostCenter
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_PK
  WHERE
    map.PFLT_Email ILIKE 'Ravishankar.Ramakrishnan@philips.com'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID LIKE '2026%'
  GROUP BY
    cc.CostCenter
),
fte_actuals AS (
  SELECT
    cc.CostCenter AS Cost_Center,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON bp.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_pflt_cc_mapping map
        ON cc.CostCenter = map.PFLT_CostCenter
  WHERE
    map.PFLT_Email ILIKE 'Ravishankar.Ramakrishnan@philips.com'
    AND bp.FiscalPeriodID LIKE '2026%'
  GROUP BY
    cc.CostCenter
)
SELECT
  a.Cost_Center,
  a.S_W_Actuals_kEUR,
  f.FTE
FROM
  sw_actuals a
    LEFT JOIN fte_actuals f
      ON a.Cost_Center = f.Cost_Center""",
    },
    {
        "input": """Top 10 MRU L7 with the biggest change in S&W and the variance of the FTE between CY and AOP for 2026001 in EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Interpretation of CY and AOP for fiscal period 2026001  -  CY is interpreted as PostActuals for fiscal period 2026001 and AOP as PostAOP for the same period, but CY could alternatively mean calendar year or other actuals, and AOP could mean different planning cycles.
Definition of 'biggest change' in Salaries & Wages  -  The query ranks MRU L7 groups by the absolute difference between current year actuals and AOP plan in Salaries & Wages, but 'biggest change' could alternatively mean relative percentage change or only increases/decreases.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_security_oru
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Calculate total Salaries & Wages actuals in EURAOP for each MRU L7 group for fiscal period 2026001.
Calculate total Salaries & Wages AOP plan in EURAOP for each MRU L7 group for the same period.
Calculate total FTE actuals for each MRU L7 group for fiscal period 2026001.
Calculate total FTE AOP plan for each MRU L7 group for the same period.
Compare the differences in Salaries & Wages and FTE between current year actuals and AOP plan, then list the top 10 MRU L7 groups with the biggest changes, applying row-level security filter by email.""",
        "output": """WITH sw_cy AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_S_W_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID = '2026001'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
),
sw_aop AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_S_W_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID = '2026001'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
),
fte_cy AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS CY_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID = '2026001'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
),
fte_aop AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(SUM(COALESCE(bp.PostAOP_Alloc_FTE, 0))) AS AOP_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID = '2026001'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
)
SELECT
  sw_cy.MRU_L7,
  sw_cy.CY_S_W_kEUR,
  sw_aop.AOP_S_W_kEUR,
  (sw_cy.CY_S_W_kEUR - sw_aop.AOP_S_W_kEUR) AS S_W_Change_kEUR,
  fte_cy.CY_FTE,
  fte_aop.AOP_FTE,
  (fte_cy.CY_FTE - fte_aop.AOP_FTE) AS FTE_Variance
FROM
  sw_cy
    LEFT JOIN sw_aop
      ON sw_cy.MRU_L7 = sw_aop.MRU_L7
    LEFT JOIN fte_cy
      ON sw_cy.MRU_L7 = fte_cy.MRU_L7
    LEFT JOIN fte_aop
      ON sw_cy.MRU_L7 = fte_aop.MRU_L7
ORDER BY
  ABS(sw_cy.CY_S_W_kEUR - sw_aop.AOP_S_W_kEUR) DESC
LIMIT 10""",
    },
    {
        "input": """Summarize & Provide [Sales to Thirds] variance between [CY & AOP] for [2026001 YTD] in [EURAOP] by [ORU BMC L5] for [MRU L4 CC]. Include totals at bottom of each column""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
dim_cat_market
dim_cat_account_fpl
Calculated an answer based on these steps
Filter data for MRU Level 4 matching 'CC' and ORU BMC Level 5 not null.
Filter accounts where Cost Agility Level 3 matches 'Sales to Thirds'.
Aggregate the sum of current year actuals and AOP values in EURAOP currency up to fiscal period 2026001.
Calculate variance as AOP minus current year actuals, scale values to thousands, and round off.
Provide results broken down by ORU BMC Level 5 with a total row at the bottom.""",
        "output": """WITH base AS (
  SELECT
    mkt.ORU_BMC_L5 AS ORU_BMC_L5,
    COALESCE(
      SUM(
        CASE
          WHEN fpl.PostActuals_EURAOP IS NULL THEN 0
          ELSE fpl.PostActuals_EURAOP
        END
      ),
      0
    ) AS CY_EURAOP,
    COALESCE(
      SUM(
        CASE
          WHEN fpl.PostAOP_EURAOP IS NULL THEN 0
          ELSE fpl.PostAOP_EURAOP
        END
      ),
      0
    ) AS AOP_EURAOP
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      JOIN qa_wb.financebi.dim_cat_market mkt
        ON fpl.CoCodePK = mkt.CoCodePK
      JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
  WHERE
    mru.MRU_L4 ILIKE '%CC%'
    AND mkt.ORU_BMC_L5 IS NOT NULL
    AND fpl.FiscalPeriodID <= '2026001'
    AND acct.CostAgility_L3 ILIKE '%Sales to Thirds%'
    AND SUBSTRING(fpl.FiscalPeriodID, 1, 4) = '2026'
  GROUP BY
    mkt.ORU_BMC_L5
)
SELECT
  ORU_BMC_L5,
  ROUND(try_divide(CY_EURAOP, 1000)) AS CY_EURAOP_k,
  ROUND(try_divide(AOP_EURAOP, 1000)) AS AOP_EURAOP_k,
  ROUND(try_divide((AOP_EURAOP - CY_EURAOP), 1000)) AS Variance_k
FROM
  base
UNION ALL
SELECT
  'Total',
  ROUND(try_divide(SUM(CY_EURAOP), 1000)),
  ROUND(try_divide(SUM(AOP_EURAOP), 1000)),
  ROUND(try_divide(SUM(AOP_EURAOP - CY_EURAOP), 1000))
FROM
  base""",
    },
    {
        "input": """Summarize [sap recon amount] for [IT90] company code, fiscal period(s) [2025011, 2025012 and 2026001] for [GL Account 6101000]. Have [document reference] in first column, [text] in second column, then values for respective fiscal period. Give total in the last row. Show numbers rounded off to zero decimals in accounting format. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
pps_sap
dim_cat_account_fpl
dim_cat_security_oru
dim_cat_market
Referenced trusted example
Summarize Actuals & FTE for S&W for Current Year by Cost Center for my Costcenter
Calculated an answer based on these steps
Filter data for GL Account 6101000 and company code IT90.
Limit data to fiscal periods 2025011, 2025012, and 2026001.
Summarize SAP reconciliation amounts for each fiscal period, grouped by document reference and text.
Include a total row with overall sums.
Round amounts to zero decimals and apply row-level security filter by email.""",
        "output": """SELECT
  `pps`.`SAP_Recon_Documentreference` AS `Document_Reference`,
  `pps`.`SAP_Recon_Text` AS `Text`,
  SUM(
    CASE
      WHEN `pps`.`SAP_Recon_FiscalPeriodID` = '2025011' THEN ROUND(`pps`.`SAP_Recon_EURAOP`, 0)
      ELSE 0
    END
  ) AS `2025011`,
  SUM(
    CASE
      WHEN `pps`.`SAP_Recon_FiscalPeriodID` = '2025012' THEN ROUND(`pps`.`SAP_Recon_EURAOP`, 0)
      ELSE 0
    END
  ) AS `2025012`,
  SUM(
    CASE
      WHEN `pps`.`SAP_Recon_FiscalPeriodID` = '2026001' THEN ROUND(`pps`.`SAP_Recon_EURAOP`, 0)
      ELSE 0
    END
  ) AS `2026001`
FROM
  `qa_wb`.`financebi`.`pps_sap` `pps`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` `acct`
      ON `pps`.`Acct_PK` = `acct`.`Acct_PK`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` `sec`
      ON `pps`.`CoCodePK` = `sec`.`CoCodePK_Security`
WHERE
  `acct`.`AccountID` = '6101000'
  AND `pps`.`SAP_Recon_FiscalPeriodID` IN ('2025011', '2025012', '2026001')
  AND `pps`.`SAP_Recon_Documentreference` IS NOT NULL
  AND `pps`.`SAP_Recon_Text` IS NOT NULL
  AND `sec`.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND `pps`.`CoCodePK` IN (
    SELECT
      `CoCodePK`
    FROM
      `qa_wb`.`financebi`.`dim_cat_market`
    WHERE
      `CoCode` ILIKE '%IT90%'
  )
GROUP BY
  GROUPING SETS ((`pps`.`SAP_Recon_Documentreference`, `pps`.`SAP_Recon_Text`), ())
ORDER BY
  CASE
    WHEN `Document_Reference` IS NULL THEN 1
    ELSE 0
  END,
  `Document_Reference`,
  `Text`""",
    },
    {
        "input": """Summarize [sap recon amount] for [IT90] company code, fiscal period(s) [2025011, 2025012 and 2026001] for [GL Account 6101900]. Have [document reference] in first column, [text] in second column, then values for respective fiscal period. Give total in the last row. Show numbers rounded off to zero decimals in accounting format. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
SAP reconciliation amount  -  The query assumes 'sap recon amount' refers to the SAP_Recon_EURAOP column, which is the EUR AOP amount for SAP reconciliation. Alternative interpretations could be other amount columns like local currency or debit/credit amounts.
Found relevant data
pps_sap
dim_cat_account_fpl
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for company code IT90, GL Account 6101900, and fiscal periods 2025011, 2025012, and 2026001.
Apply row-level security by filtering records based on the user's email Ravishankar.Ramakrishnan@philips.com.
Summarize the SAP reconciliation amounts for each document reference and text, broken down by the specified fiscal periods.
Round the amounts to zero decimals and present them in accounting format.
Add a total row that sums the amounts for all document references across the specified fiscal periods.""",
        "output": """WITH filtered_data AS (
  SELECT
    pps_sap.SAP_Recon_Documentreference AS Document_Reference,
    pps_sap.SAP_Recon_Text AS Text,
    pps_sap.SAP_Recon_FiscalPeriodID,
    ROUND(COALESCE(pps_sap.SAP_Recon_EURAOP, 0), 0) AS SAP_Recon_Amount
  FROM
    qa_wb.financebi.pps_sap pps_sap
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON pps_sap.Acct_PK = acct.Acct_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON pps_sap.CoCodePK = market.CoCodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON pps_sap.CoCodePK = sec.CoCodePK_Security
  WHERE
    market.CoCode ILIKE '%IT90%'
    AND pps_sap.SAP_Recon_FiscalPeriodID IN ('2025011', '2025012', '2026001')
    AND acct.AccountID = '6101900'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
)
SELECT
  Document_Reference,
  Text,
  SUM(
    CASE
      WHEN SAP_Recon_FiscalPeriodID = '2025011' THEN SAP_Recon_Amount
      ELSE 0
    END
  ) AS `2025011`,
  SUM(
    CASE
      WHEN SAP_Recon_FiscalPeriodID = '2025012' THEN SAP_Recon_Amount
      ELSE 0
    END
  ) AS `2025012`,
  SUM(
    CASE
      WHEN SAP_Recon_FiscalPeriodID = '2026001' THEN SAP_Recon_Amount
      ELSE 0
    END
  ) AS `2026001`,
  1 AS sort_order
FROM
  filtered_data
GROUP BY
  Document_Reference,
  Text
UNION ALL
SELECT
  'Total',
  '',
  SUM(
    CASE
      WHEN SAP_Recon_FiscalPeriodID = '2025011' THEN SAP_Recon_Amount
      ELSE 0
    END
  ),
  SUM(
    CASE
      WHEN SAP_Recon_FiscalPeriodID = '2025012' THEN SAP_Recon_Amount
      ELSE 0
    END
  ),
  SUM(
    CASE
      WHEN SAP_Recon_FiscalPeriodID = '2026001' THEN SAP_Recon_Amount
      ELSE 0
    END
  ),
  2 AS sort_order
FROM
  filtered_data
ORDER BY
  sort_order,
  Document_Reference""",
    },
    {
        "input": """what is the company code for ORU 380121. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter the market data to find the entry with ORU equal to 380121.
Apply row-level security by filtering the security table for the email Ravishankar.Ramakrishnan@philips.com.
Join the market and security data on the company code key to enforce the security filter.
Retrieve the company code for the matching ORU and email combination, excluding any null values.""",
        "output": """SELECT
  m.CoCode AS Company_Code
FROM
  qa_wb.financebi.dim_cat_market m
    INNER JOIN qa_wb.financebi.dim_cat_security_oru s
      ON m.CoCodePK = s.CoCodePK_Security
WHERE
  m.ORU = '380121'
  AND s.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND m.CoCode IS NOT NULL""",
    },
    {
        "input": """Summarize & Provide R&D functional area 5000 [FTE] and [Salaries and Wages] variance between [CY & AOP] for [2026001 ITM] by [MRU L9: IS PACS BU0971 & Radiology Infor. BU9308] for [BUGroup Finance]. Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
dim_cat_security_oru
dim_cat_mru
cat_blueprint_prevspostalloc
cat_fpl_prevspostalloc
dim_cat_account_fpl
Calculated an answer based on these steps
Filter data for the fiscal period 2026001 and functional area 5000.
Filter MRU data to include only MRU L9 groups 'IS PACS' with BU0971 and 'Radiology Infor.' with BU9308 within the Finance business group.
Apply row-level security by filtering company codes based on the user's email in the security table.
Calculate total FTE for current year and AOP by MAG description.
Calculate total Salaries & Wages for current year and AOP by MAG description, filtering accounts for Salaries & Wages.
Calculate variance between current year and AOP for both FTE and Salaries & Wages.
Format numbers with thousand separators and no decimals, and add a total row at the bottom.""",
        "output": """WITH security_filtered_cocodes AS (
  SELECT DISTINCT
    CoCodePK_Security
  FROM
    qa_wb.financebi.dim_cat_security_oru
  WHERE
    Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
),
filtered_mru AS (
  SELECT
    MAG_PK,
    MAG_Description
  FROM
    qa_wb.financebi.dim_cat_mru
  WHERE
    BUGroup ILIKE '%Finance%'
    AND (
      (
        MRU_L9 ILIKE '%IS PACS%'
        AND BUID ILIKE '%BU0971%'
      )
      OR (
        MRU_L9 ILIKE '%Radiology Infor.%'
        AND BUID ILIKE '%BU9308%'
      )
    )
),
te_fte AS (
  SELECT
    mru.MAG_Description,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS FTE_CY,
    ROUND(SUM(COALESCE(bp.PostAOP_Alloc_FTE, 0))) AS FTE_AOP
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN filtered_mru mru
        ON bp.MAG_PK = mru.MAG_PK
  WHERE
    bp.FiscalPeriodID = '2026001'
    AND bp.FuncAreaPK = 5000
    AND bp.CoCodePK IN (
      SELECT
        CoCodePK_Security
      FROM
        security_filtered_cocodes
    )
  GROUP BY
    mru.MAG_Description
),
te_sw AS (
  SELECT
    mru.MAG_Description,
    ROUND(TRY_DIVIDE(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS S_W_CY_kEUR,
    ROUND(TRY_DIVIDE(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS S_W_AOP_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN filtered_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_PK
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND fpl.FuncAreaPK = 5000
    AND fpl.CoCodePK IN (
      SELECT
        CoCodePK_Security
      FROM
        security_filtered_cocodes
    )
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
  GROUP BY
    mru.MAG_Description
)
SELECT
  te_fte.MAG_Description,
  FORMAT_NUMBER(COALESCE(te_fte.FTE_CY, 0), '#,###') AS FTE_CY,
  FORMAT_NUMBER(COALESCE(te_fte.FTE_AOP, 0), '#,###') AS FTE_AOP,
  FORMAT_NUMBER(COALESCE(te_fte.FTE_CY, 0) - COALESCE(te_fte.FTE_AOP, 0), '#,###') AS FTE_Variance,
  FORMAT_NUMBER(COALESCE(te_sw.S_W_CY_kEUR, 0), '#,###') AS S_W_CY_kEUR,
  FORMAT_NUMBER(COALESCE(te_sw.S_W_AOP_kEUR, 0), '#,###') AS S_W_AOP_kEUR,
  FORMAT_NUMBER(
    COALESCE(te_sw.S_W_CY_kEUR, 0) - COALESCE(te_sw.S_W_AOP_kEUR, 0),
    '#,###'
  ) AS S_W_Variance_kEUR
FROM
  te_fte
    LEFT JOIN te_sw
      ON te_fte.MAG_Description = te_sw.MAG_Description
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(SUM(COALESCE(te_fte.FTE_CY, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(te_fte.FTE_AOP, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(te_fte.FTE_CY, 0)) - SUM(COALESCE(te_fte.FTE_AOP, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(te_sw.S_W_CY_kEUR, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(te_sw.S_W_AOP_kEUR, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(te_sw.S_W_CY_kEUR, 0)) - SUM(COALESCE(te_sw.S_W_AOP_kEUR, 0)), '#,###')
FROM
  te_fte
    LEFT JOIN te_sw
      ON te_fte.MAG_Description = te_sw.MAG_Description""",
    },
    {
        "input": """Summarize & Provide [FTE] and [Salaries and Wages] variance between [CY & AOP] for [2026001 ITM] for R&D 5000 function area [BU0971 & BU9308 Finance]. Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_functional_area
dim_cat_security_oru
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Filter data for fiscal period 2026001 and functional area 5000 (R&D).
Filter for business units BU0971 and BU9308 with Finance in their description.
Filter Salaries and Wages data from the financial planning table and aggregate in thousands of EURAOP.
Filter FTE data from the blueprint allocation table and aggregate counts.
Calculate variance between current year and AOP for both Salaries and Wages and FTE.
Apply row-level security by filtering data accessible to the user email Ravishankar.Ramakrishnan@philips.com.
Format numbers with thousand separators and no decimals, and add a total row at the bottom.""",
        "output": """WITH sw AS (
  SELECT
    mru.BUID,
    mru.BU_Description,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_S_W,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_S_W
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_PK
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_functional_area fa
        ON fpl.FuncAreaPK = fa.FuncAreaPK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND fa.FunctionalArea = '5000'
    AND (
      mru.BUID ILIKE '%BU0971%'
      OR mru.BUID ILIKE '%BU9308%'
    )
    AND mru.BU_Description ILIKE '%Finance%'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.BUID,
    mru.BU_Description
),
fte AS (
  SELECT
    mru.BUID,
    mru.BU_Description,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS CY_FTE,
    ROUND(SUM(COALESCE(bp.PostAOP_Alloc_FTE, 0))) AS AOP_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_functional_area fa
        ON bp.FuncAreaPK = fa.FuncAreaPK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID = '2026001'
    AND fa.FunctionalArea = '5000'
    AND (
      mru.BUID ILIKE '%BU0971%'
      OR mru.BUID ILIKE '%BU9308%'
    )
    AND mru.BU_Description ILIKE '%Finance%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.BUID,
    mru.BU_Description
)
SELECT
  sw.BUID AS BU_ID,
  sw.BU_Description AS BU_Description,
  FORMAT_NUMBER(sw.CY_S_W, '#,###') AS CY_S_W_kEUR,
  FORMAT_NUMBER(sw.AOP_S_W, '#,###') AS AOP_S_W_kEUR,
  FORMAT_NUMBER(sw.CY_S_W - sw.AOP_S_W, '#,###') AS S_W_Variance_kEUR,
  FORMAT_NUMBER(fte.CY_FTE, '#,###') AS CY_FTE,
  FORMAT_NUMBER(fte.AOP_FTE, '#,###') AS AOP_FTE,
  FORMAT_NUMBER(fte.CY_FTE - fte.AOP_FTE, '#,###') AS FTE_Variance
FROM
  sw
    LEFT JOIN fte
      ON sw.BUID = fte.BUID
      AND sw.BU_Description = fte.BU_Description
UNION ALL
SELECT
  'Total',
  '',
  FORMAT_NUMBER(SUM(sw.CY_S_W), '#,###'),
  FORMAT_NUMBER(SUM(sw.AOP_S_W), '#,###'),
  FORMAT_NUMBER(SUM(sw.CY_S_W - sw.AOP_S_W), '#,###'),
  FORMAT_NUMBER(SUM(fte.CY_FTE), '#,###'),
  FORMAT_NUMBER(SUM(fte.AOP_FTE), '#,###'),
  FORMAT_NUMBER(SUM(fte.CY_FTE - fte.AOP_FTE), '#,###')
FROM
  sw
    LEFT JOIN fte
      ON sw.BUID = fte.BUID
      AND sw.BU_Description = fte.BU_Description""",
    },
    {
        "input": """Summarize & Provide [FA 5000] variance between [CY & AOP] for [2026001 YTD] in [EURAOP] by [Cost agility L4] for Enterprise Info. Include totals at bottom of each column. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Fiscal period range  -  The query assumes '2026001 YTD' means all fiscal periods in 2026 up to and including 2026001, but it could alternatively mean only the single period 2026001 or a different range within 2026.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
dim_cat_account_fpl
dim_cat_security_oru
dim_cat_functional_area
Referenced trusted example
Summarize Actuals & FTE for S&W for Current Year by Cost Center for my Costcenter
Calculated an answer based on these steps
Filter data for functional area 5000 and business segment Enterprise Info at MRU Level 7.
Filter data for fiscal periods in 2026 up to 2026001 and for the specified email for row-level security.
Aggregate the sum of current year actuals and AOP amounts in EURAOP by Cost Agility Level 4.
Calculate the variance as the difference between current year actuals and AOP for each Cost Agility Level 4 category.
Include a total row summing all Cost Agility Level 4 categories for current year actuals, AOP, and variance.""",
        "output": """WITH main AS (
  SELECT
    acct.CostAgility_L4 AS CostAgility_L4,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_Actuals_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
      INNER JOIN qa_wb.financebi.dim_cat_functional_area fa
        ON fpl.FuncAreaPK = fa.FuncAreaPK
  WHERE
    fa.FunctionalArea = '5000'
    AND mru.MRU_L7 ILIKE '%Enterprise Info%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND fpl.FiscalPeriodID <= '2026001'
    AND fpl.FiscalPeriodID LIKE '2026%'
    AND acct.CostAgility_L4 IS NOT NULL
  GROUP BY
    acct.CostAgility_L4
),
main_with_var AS (
  SELECT
    CostAgility_L4,
    CY_Actuals_kEUR,
    AOP_kEUR,
    (CY_Actuals_kEUR - AOP_kEUR) AS Variance_kEUR
  FROM
    main
)
SELECT
  *
FROM
  main_with_var
UNION ALL
SELECT
  'TOTAL',
  SUM(CY_Actuals_kEUR),
  SUM(AOP_kEUR),
  SUM(Variance_kEUR)
FROM
  main_with_var""",
    },
    {
        "input": """Summarize & Provide [FTE] and [Salaries and Wages] for [202512 ITM and 2026001 ITM] by [ORU] for [I and D MRU L5]. Show ORU with description in first row, then 'salaries and wages' [CY] and then [FTE] for 2025012, then 'salaries and wages' [CY] and then [FTE] for 2026001, Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP. Sort ORU ID with description in a way that highest salaries wages costs come at top. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Fiscal Period Codes  -  The fiscal period codes '2025012' and '2026001' are assumed to represent specific time periods, but their exact meaning (e.g., month, quarter) is not explicitly defined in the question.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
dim_cat_market
dim_cat_account_fpl
dim_cat_security_oru
cat_blueprint_prevspostalloc
Referenced trusted example
Summarize Actuals & FTE for S&W for Current Year by Cost Center for my Costcenter
Calculated an answer based on these steps
Filter data for fiscal periods 2025012 and 2026001 and for MRU L5 containing 'I and D'.
Filter salaries and wages costs using the CostAgility_L4 attribute and apply row-level security by filtering on the user's email in the security table.
Aggregate salaries and wages costs (in K EURAOP) and FTE counts by ORU description for each fiscal period separately.
Combine the results for both periods and both metrics into a single table, format numbers with thousand separators and no decimals, and add a total row at the bottom.
Sort the results by the salaries and wages cost for the 2026001 period in descending order, with the total row at the bottom.""",
        "output": """WITH sw_2025012 AS (
  SELECT
    market.ORU_Description AS ORU,
    ROUND(TRY_DIVIDE(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS S_W_2025012_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON fpl.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2025012'
    AND mru.MRU_L5 ILIKE '%I and D%'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND market.ORU_Description IS NOT NULL
  GROUP BY
    market.ORU_Description
),
sw_2026001 AS (
  SELECT
    market.ORU_Description AS ORU,
    ROUND(TRY_DIVIDE(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS S_W_2026001_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON fpl.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND mru.MRU_L5 ILIKE '%I and D%'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND market.ORU_Description IS NOT NULL
  GROUP BY
    market.ORU_Description
),
fte_2025012 AS (
  SELECT
    market.ORU_Description AS ORU,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS FTE_2025012
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON bp.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID = '2025012'
    AND mru.MRU_L5 ILIKE '%I and D%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND market.ORU_Description IS NOT NULL
  GROUP BY
    market.ORU_Description
),
fte_2026001 AS (
  SELECT
    market.ORU_Description AS ORU,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS FTE_2026001
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON bp.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID = '2026001'
    AND mru.MRU_L5 ILIKE '%I and D%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND market.ORU_Description IS NOT NULL
  GROUP BY
    market.ORU_Description
),
combined AS (
  SELECT
    COALESCE(sw_2026001.ORU, sw_2025012.ORU, fte_2026001.ORU, fte_2025012.ORU) AS ORU,
    to_char(COALESCE(sw_2025012.S_W_2025012_kEUR, 0), '999,999,999') AS S_W_2025012_kEUR,
    to_char(COALESCE(fte_2025012.FTE_2025012, 0), '999,999,999') AS FTE_2025012,
    to_char(COALESCE(sw_2026001.S_W_2026001_kEUR, 0), '999,999,999') AS S_W_2026001_kEUR,
    to_char(COALESCE(fte_2026001.FTE_2026001, 0), '999,999,999') AS FTE_2026001,
    1 AS sort_order,
    COALESCE(sw_2026001.S_W_2026001_kEUR, 0) AS sort_val
  FROM
    sw_2026001
      FULL OUTER JOIN sw_2025012
        ON sw_2026001.ORU = sw_2025012.ORU
      FULL OUTER JOIN fte_2026001
        ON COALESCE(sw_2026001.ORU, sw_2025012.ORU) = fte_2026001.ORU
      FULL OUTER JOIN fte_2025012
        ON COALESCE(sw_2026001.ORU, sw_2025012.ORU) = fte_2025012.ORU
  UNION ALL
  SELECT
    'Total',
    to_char(SUM(COALESCE(sw_2025012.S_W_2025012_kEUR, 0)), '999,999,999'),
    to_char(SUM(COALESCE(fte_2025012.FTE_2025012, 0)), '999,999,999'),
    to_char(SUM(COALESCE(sw_2026001.S_W_2026001_kEUR, 0)), '999,999,999'),
    to_char(SUM(COALESCE(fte_2026001.FTE_2026001, 0)), '999,999,999'),
    2 AS sort_order,
    0 AS sort_val
  FROM
    sw_2026001
      FULL OUTER JOIN sw_2025012
        ON sw_2026001.ORU = sw_2025012.ORU
      FULL OUTER JOIN fte_2026001
        ON COALESCE(sw_2026001.ORU, sw_2025012.ORU) = fte_2026001.ORU
      FULL OUTER JOIN fte_2025012
        ON COALESCE(sw_2026001.ORU, sw_2025012.ORU) = fte_2025012.ORU
)
SELECT
  ORU,
  S_W_2025012_kEUR,
  FTE_2025012,
  S_W_2026001_kEUR,
  FTE_2026001
FROM
  combined
ORDER BY
  sort_order,
  sort_val DESC""",
    },
    {
        "input": """Summarize & Provide [FTE] and [Salaries and Wages] variance between [CY & AOP] for [2026001 ITM] by [Region] for [S&RC]. Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
dim_cat_mru
dim_cat_market
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_security_oru
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Identify the region for each record by checking multiple market region levels in order and mapping them to the MAG key.
Filter data for the S&RC business area and Salaries & Wages accounts for the first fiscal period of 2026, applying row-level security by filtering on the user's email in the security table.
Calculate the sum of Salaries & Wages actuals and AOP amounts in thousands of EURAOP, grouped by region.
Calculate the sum of FTE actuals and AOP counts, grouped by region, from the blueprint allocation table.
Combine the Salaries & Wages and FTE results by region, calculate the variance between current year and AOP for both metrics, format the numbers with thousand separators and no decimals, and add a total row at the bottom.""",
        "output": """WITH region_map AS (
  SELECT
    mru.MAG_PK,
    COALESCE(
      mkt.ORU_BMC_L1,
      mkt.ORU_BMC_L2,
      mkt.ORU_BMC_L3,
      mkt.ORU_BMC_L4,
      mkt.ORU_BMC_L5,
      mkt.ORU_BMC_L6,
      mkt.ORU_BMC_L7,
      mkt.ORU_BMC_L8,
      mkt.ORU,
      mkt.CoCode
    ) AS Region
  FROM
    `qa_wb`.`financebi`.`dim_cat_mru` mru
      LEFT JOIN `qa_wb`.`financebi`.`dim_cat_market` mkt
        ON mru.BUID = mkt.ORU
),
sw_actuals AS (
  SELECT
    r.Region,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS S_W_CY_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS S_W_AOP_kEUR
  FROM
    `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` fpl
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN region_map r
        ON fpl.MAG_PK = r.MAG_PK
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    mru.MRU_L5 ILIKE '%S&RC%'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID = '2026001'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND r.Region IS NOT NULL
  GROUP BY
    r.Region
),
fte_actuals AS (
  SELECT
    r.Region,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS FTE_CY,
    ROUND(SUM(COALESCE(bp.PostAOP_Alloc_FTE, 0))) AS FTE_AOP
  FROM
    `qa_wb`.`financebi`.`cat_blueprint_prevspostalloc` bp
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN region_map r
        ON bp.MAG_PK = r.MAG_PK
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    mru.MRU_L5 ILIKE '%S&RC%'
    AND bp.FiscalPeriodID = '2026001'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND r.Region IS NOT NULL
  GROUP BY
    r.Region
)
SELECT
  sw.Region,
  FORMAT_NUMBER(COALESCE(fte.FTE_CY, 0), '#,###') AS FTE_CY,
  FORMAT_NUMBER(COALESCE(fte.FTE_AOP, 0), '#,###') AS FTE_AOP,
  FORMAT_NUMBER(COALESCE(fte.FTE_CY, 0) - COALESCE(fte.FTE_AOP, 0), '#,###') AS FTE_Variance,
  FORMAT_NUMBER(COALESCE(sw.S_W_CY_kEUR, 0), '#,###') AS S_W_CY_kEUR,
  FORMAT_NUMBER(COALESCE(sw.S_W_AOP_kEUR, 0), '#,###') AS S_W_AOP_kEUR,
  FORMAT_NUMBER(
    COALESCE(sw.S_W_CY_kEUR, 0) - COALESCE(sw.S_W_AOP_kEUR, 0),
    '#,###'
  ) AS S_W_Variance_kEUR
FROM
  sw_actuals sw
    LEFT JOIN fte_actuals fte
      ON sw.Region = fte.Region
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(SUM(COALESCE(fte.FTE_CY, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(fte.FTE_AOP, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(fte.FTE_CY, 0) - COALESCE(fte.FTE_AOP, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(sw.S_W_CY_kEUR, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(sw.S_W_AOP_kEUR, 0)), '#,###'),
  FORMAT_NUMBER(SUM(COALESCE(sw.S_W_CY_kEUR, 0) - COALESCE(sw.S_W_AOP_kEUR, 0)), '#,###')
FROM
  sw_actuals sw
    LEFT JOIN fte_actuals fte
      ON sw.Region = fte.Region""",
    },
    {
        "input": """Summarize &amp; Provide [Sales Rel Costs] variance between [CY &amp; AOP] for [2026001 YTD] in [EURAOP] by [Cost Agility L5] and by [FS item] for [ORU 130320]. Then list the top 10 Cost Center reporting highest variance. Include totals at bottom of each column. Format with thousand separator and no decimals. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Variance calculation method  -  The variance is calculated as actuals minus AOP (plan). An alternative interpretation could be AOP minus actuals, which would reverse the sign of the variance and change the interpretation of over- or under-spending.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_costcenter
dim_cat_security_oru
dim_cat_market
Referenced trusted example
Top 10 MRU L7 with the biggest change in S&W and the variance of the FTE between AOP and LY for 2026 year in EURAOP
Calculated an answer based on these steps
Filter data for Sales Related Costs accounts and fiscal periods up to 2026001 for ORU 130320.
Apply row-level security by filtering on the user's email in the security table.
Aggregate actuals and AOP values in EURAOP currency by Cost Agility Level 5, FS item, and Cost Center.
Calculate the variance as actuals minus AOP for each group.
Select the top 10 cost centers with the highest variance and include a total summary row with formatted numbers.""",
        "output": """WITH filtered_data AS (
  SELECT
    acct.CostAgility_L5 AS CostAgility_L5,
    acct.FSItemID AS FS_Item,
    cc.CostCenter AS Cost_Center,
    SUM(COALESCE(fpl.PostActuals_EURAOP, 0)) AS Actuals_EURAOP,
    SUM(COALESCE(fpl.PostAOP_EURAOP, 0)) AS AOP_EURAOP
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON fpl.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
      INNER JOIN qa_wb.financebi.dim_cat_market mkt
        ON cc.CoCode = mkt.CoCode
  WHERE
    acct.CostAgility_L4 ILIKE '%Sales Rel Costs%'
    AND fpl.FiscalPeriodID <= '2026001'
    AND mkt.ORU = '130320'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    acct.CostAgility_L5,
    acct.FSItemID,
    cc.CostCenter
),
variance_data AS (
  SELECT
    CostAgility_L5,
    FS_Item,
    Cost_Center,
    Actuals_EURAOP,
    AOP_EURAOP,
    (Actuals_EURAOP - AOP_EURAOP) AS Variance_EURAOP
  FROM
    filtered_data
),
top10_cc AS (
  SELECT
    CostAgility_L5,
    FS_Item,
    Cost_Center,
    Actuals_EURAOP,
    AOP_EURAOP,
    Variance_EURAOP
  FROM
    variance_data
  ORDER BY
    Variance_EURAOP DESC
  LIMIT 10
),
totals AS (
  SELECT
    'TOTAL' AS CostAgility_L5,
    'TOTAL' AS FS_Item,
    'TOTAL' AS Cost_Center,
    SUM(Actuals_EURAOP) AS Actuals_EURAOP,
    SUM(AOP_EURAOP) AS AOP_EURAOP,
    SUM(Variance_EURAOP) AS Variance_EURAOP
  FROM
    variance_data
)
SELECT
  CostAgility_L5,
  FS_Item,
  Cost_Center,
  FORMAT_NUMBER(Actuals_EURAOP, '#,###') AS Actuals_EURAOP,
  FORMAT_NUMBER(AOP_EURAOP, '#,###') AS AOP_EURAOP,
  FORMAT_NUMBER(Variance_EURAOP, '#,###') AS Variance_EURAOP
FROM
  top10_cc
UNION ALL
SELECT
  CostAgility_L5,
  FS_Item,
  Cost_Center,
  FORMAT_NUMBER(Actuals_EURAOP, '#,###'),
  FORMAT_NUMBER(AOP_EURAOP, '#,###'),
  FORMAT_NUMBER(Variance_EURAOP, '#,###')
FROM
  totals""",
    },
    {
        "input": """Summarize & Provide [sales rel costs] variance between [CY & AOP] for [2026001 ITM] in [EUR AOP] by [Cost Center] for [ORU BMC L5 North America Region] for [PH MRU L5]. Include totals at bottom of each column. Sort in a way that shows cost centers contributing to the variance most on top. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_costcenter
dim_cat_mru
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for fiscal period 2026001 and sales-related costs in EUR AOP.
Limit data to North America region at ORU_BMC_L5 level and PH segment at MRU_L5 level.
Apply row-level security filter using the provided email address.
Aggregate actual and plan values by cost center, rounding and scaling to thousands.
Calculate variance as the difference between actuals and plan.
Include a total row summing all cost centers.
Sort results by absolute variance descending, with totals at the bottom.""",
        "output": """WITH filtered_data AS (
  SELECT
    cc.CostCenter AS Cost_Center,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON fpl.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON fpl.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND acct.CostAgility_L4 ILIKE '%Sales rel costs%'
    AND market.ORU_BMC_L5 ILIKE '%North America Region%'
    AND mru.MRU_L5 ILIKE '%PH%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND cc.CostCenter IS NOT NULL
  GROUP BY
    cc.CostCenter
)
SELECT
  Cost_Center,
  CY_kEUR,
  AOP_kEUR,
  (CY_kEUR - AOP_kEUR) AS Variance_kEUR,
  0 AS sort_key
FROM
  filtered_data
UNION ALL
SELECT
  'TOTAL',
  SUM(CY_kEUR),
  SUM(AOP_kEUR),
  SUM(CY_kEUR - AOP_kEUR),
  1
FROM
  filtered_data
ORDER BY
  sort_key,
  ABS(CY_kEUR - AOP_kEUR) DESC""",
    },
    {
        "input": """Summarize & Provide [sales rel costs] variance between [CY & AOP] for [2026001 ITM] in [EUR AOP] for [US18102 Cost Center] for [ORU BMC L5 North America Region] for [PH MRU L5] by [GL Account with description]. Include totals at bottom of each column. Sort in a way that shows [GL Account with description] contributing to the variance most on top.
 . Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_costcenter
dim_cat_mru
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for fiscal period 2026001, sales-related costs, North America Region, PH MRU L5, and US18102 Cost Center.
Apply row-level security by filtering on the provided email address in the security table.
Summarize current year actuals and AOP plan values in thousands of EUR by GL Account and description.
Calculate variance as the difference between current year actuals and AOP plan values.
Include a total row summing all values and sort results by the absolute variance descending, with totals at the bottom.""",
        "output": """WITH filtered_data AS (
  SELECT
    acct.AccountID AS GL_Account,
    acct.Account_Description AS GL_Account_Description,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON fpl.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON fpl.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND acct.CostAgility_L4 ILIKE '%Sales rel costs%'
    AND market.ORU_BMC_L5 ILIKE '%North America Region%'
    AND mru.MRU_L5 ILIKE '%PH%'
    AND cc.CostCenter ILIKE '%US18102%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND acct.AccountID IS NOT NULL
  GROUP BY
    acct.AccountID,
    acct.Account_Description
)
SELECT
  GL_Account,
  GL_Account_Description,
  CY_kEUR,
  AOP_kEUR,
  (CY_kEUR - AOP_kEUR) AS Variance_kEUR,
  0 AS sort_key
FROM
  filtered_data
UNION ALL
SELECT
  'TOTAL',
  'TOTAL',
  SUM(CY_kEUR),
  SUM(AOP_kEUR),
  SUM(CY_kEUR - AOP_kEUR),
  1
FROM
  filtered_data
ORDER BY
  sort_key,
  ABS(CY_kEUR - AOP_kEUR) DESC""",
    },
    {
        "input": """Summarize Actuals & FTE for S&W for Current Year by Cost Center for my Costcenter. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
dim_pflt_cc_mapping
dim_cat_costcenter
cat_fpl_prevspostalloc
dim_cat_account_fpl
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Identify the cost centers associated with the user based on their email in the security mapping table.
Calculate the total actual salaries and wages costs for the current year for these cost centers, converting the amounts to thousands of euros.
Calculate the total full-time equivalent (FTE) counts for the current year for these cost centers.
Combine the salaries and wages costs and FTE counts by cost center, showing zero where data is missing.
Sort the results by the total actual salaries and wages costs in descending order.""",
        "output": """WITH user_cc AS (
  SELECT DISTINCT
    PFLT_CostCenter
  FROM
    qa_wb.financebi.dim_pflt_cc_mapping
  WHERE
    PFLT_Email ILIKE 'Ravishankar.Ramakrishnan@philips.com'
),
cc_pk AS (
  SELECT
    CC_PK_IPL,
    CostCenter
  FROM
    qa_wb.financebi.dim_cat_costcenter
  WHERE
    CostCenter IN (
      SELECT
        PFLT_CostCenter
      FROM
        user_cc
    )
),
actuals AS (
  SELECT
    c.CostCenter,
    ROUND(try_divide(SUM(COALESCE(f.PostActuals_EURAOP, 0)), 1000)) AS Actuals_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc f
      INNER JOIN cc_pk c
        ON f.CC_PK_IPL = c.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl a
        ON f.Acct_PK = a.Acct_pk
  WHERE
    a.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND f.FiscalPeriodID LIKE '2026%'
  GROUP BY
    c.CostCenter
),
fte AS (
  SELECT
    c.CostCenter,
    ROUND(SUM(COALESCE(b.PostActuals_Alloc_FTE, 0))) AS FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc b
      INNER JOIN cc_pk c
        ON b.CC_PK_IPL = c.CC_PK_IPL
  WHERE
    b.FiscalPeriodID LIKE '2026%'
  GROUP BY
    c.CostCenter
)
SELECT
  a.CostCenter,
  COALESCE(a.Actuals_kEUR, 0) AS Actuals_kEUR,
  COALESCE(f.FTE, 0) AS FTE
FROM
  actuals a
    LEFT JOIN fte f
      ON a.CostCenter = f.CostCenter
ORDER BY
  Actuals_kEUR DESC""",
    },
    {
        "input": """Summarize[PPS recon amount] for [PL90] company code and GL Account 6100100, fiscal period(s) [2025011, 2025012 and 2026001] with [description] in first column, [wage type] in second column and [PPS recon amount] in third column. Add total in the last row. Do not add sub total for wage code. Add total in the last row only. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
pps
dim_cat_security_oru
dim_cat_account_fpl
dim_cat_costcenter
Calculated an answer based on these steps
Calculate the total planned Salaries & Wages costs (AOP) for each MRU Level 7 category in 2026, converting the amounts to thousands of euros.
Calculate the total Salaries & Wages costs from last year (LY) for each MRU Level 7 category in 2026, also in thousands of euros.
Calculate the total planned FTE counts for each MRU Level 7 category in 2026.
Calculate the total FTE counts from last year for each MRU Level 7 category in 2025.
Combine these results to show, for each MRU Level 7 category, the planned and last year Salaries & Wages costs, their difference, the planned and last year FTE counts, and their difference.
Rank the MRU Level 7 categories by the absolute change in Salaries & Wages costs and return the top 10.""",
        "output": """WITH filtered_pps AS (
  SELECT
    pps.PPS_Recon_Description AS Description,
    pps.PPS_Recon_WageType AS WageType,
    COALESCE(SUM(pps.PPS_Recon_Local), 0) AS PPS_Recon_Amount
  FROM
    qa_wb.financebi.pps AS pps
      INNER JOIN qa_wb.financebi.dim_cat_security_oru AS sec
        ON pps.CoCodePK = sec.CoCodePK_Security
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl AS acct
        ON pps.Acct_PK = acct.Acct_PK
      INNER JOIN qa_wb.financebi.dim_cat_costcenter AS cc
        ON pps.CC_PK_IPL = cc.CC_PK_IPL
  WHERE
    sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND cc.CoCode ILIKE '%PL90%'
    AND acct.AccountID ILIKE '%6100100%'
    AND pps.PPS_Recon_FiscalPeriodID IN ('2025011', '2025012', '2026001')
    AND pps.PPS_Recon_Description IS NOT NULL
    AND pps.PPS_Recon_WageType IS NOT NULL
  GROUP BY
    pps.PPS_Recon_Description,
    pps.PPS_Recon_WageType
)
SELECT
  Description,
  WageType,
  PPS_Recon_Amount
FROM
  filtered_pps
UNION ALL
SELECT
  'Total',
  NULL,
  SUM(PPS_Recon_Amount)
FROM
  filtered_pps""",
    },
    {
        "input": """on which cost FSI the cost are posted ?. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_costcenter
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for cost center US90.03423 and fiscal year 2025.
Apply row-level security by filtering on the user's email in the security table.
Select distinct FSI functional IDs where the posted actual costs in EURAOP are not zero.""",
        "output": """SELECT DISTINCT
  fpl.FSI_Func_ID AS FSI_Functional_ID
FROM
  qa_wb.financebi.cat_fpl_prevspostalloc fpl
    INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
      ON fpl.CC_PK_IPL = cc.CC_PK_IPL
    INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
      ON fpl.CoCodePK = sec.CoCodePK_Security
WHERE
  cc.CostCenter ILIKE '%US90.03423%'
  AND fpl.FiscalPeriodID LIKE '2025%'
  AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND COALESCE(fpl.PostActuals_EURAOP, 0) != 0""",
    },
    {
        "input": """give me the cost agility hierarchy. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_costcenter
dim_cat_account_fpl
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for cost center US90.03423 and fiscal year 2025.
Apply row-level security by filtering on the email Ravishankar.Ramakrishnan@philips.com.
Join cost center, account, and security tables to get cost agility hierarchy levels.
Select distinct cost agility hierarchy levels from level 1 to level 9.
Include only records where the actual posted costs in EURAOP are not zero.""",
        "output": """SELECT DISTINCT
  acct.CostAgility_L1 AS CostAgility_L1,
  acct.CostAgility_L2 AS CostAgility_L2,
  acct.CostAgility_L3 AS CostAgility_L3,
  acct.CostAgility_L4 AS CostAgility_L4,
  acct.CostAgility_L5 AS CostAgility_L5,
  acct.CostAgility_L6 AS CostAgility_L6,
  acct.CostAgility_L7 AS CostAgility_L7,
  acct.CostAgility_L8 AS CostAgility_L8,
  acct.CostAgility_L9 AS CostAgility_L9
FROM
  qa_wb.financebi.cat_fpl_prevspostalloc fpl
    INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
      ON fpl.CC_PK_IPL = cc.CC_PK_IPL
    INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
      ON fpl.Acct_PK = acct.Acct_pk
    INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
      ON fpl.CoCodePK = sec.CoCodePK_Security
WHERE
  cc.CostCenter ILIKE '%US90.03423%'
  AND fpl.FiscalPeriodID LIKE '2025%'
  AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND COALESCE(fpl.PostActuals_EURAOP, 0) != 0""",
    },
    {
        "input": """please list all [Customer] for [AG BG2]
 . Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Customer definition  -  The query interprets 'Customer' as the distinct CompanyCode_Description from the market dimension table. However, 'Customer' could alternatively mean customer number or another customer-related attribute, which would change the results.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
dim_cat_market
dim_cat_security_oru
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Retrieve distinct customer names from the market data linked to financial facts for MAG BG2.
Apply row-level security by filtering data based on the provided email in the security table.
Combine results from two different fact tables to ensure completeness.
Exclude any null customer names from the results.""",
        "output": """SELECT DISTINCT
  market.CompanyCode_Description AS Customer
FROM
  qa_wb.financebi.cat_fpl_prevspostalloc fact
    INNER JOIN qa_wb.financebi.dim_cat_mru mru
      ON fact.MAG_PK = mru.MAG_PK
    INNER JOIN qa_wb.financebi.dim_cat_market market
      ON fact.CoCodePK = market.CoCodePK
    INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
      ON fact.CoCodePK = sec.CoCodePK_Security
WHERE
  mru.MAG ILIKE '%BG2%'
  AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND market.CompanyCode_Description IS NOT NULL
UNION
SELECT DISTINCT
  market.CompanyCode_Description AS Customer
FROM
  qa_wb.financebi.cat_blueprint_prevspostalloc fact
    INNER JOIN qa_wb.financebi.dim_cat_mru mru
      ON fact.MAG_PK = mru.MAG_PK
    INNER JOIN qa_wb.financebi.dim_cat_market market
      ON fact.CoCodePK = market.CoCodePK
    INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
      ON fact.CoCodePK = sec.CoCodePK_Security
WHERE
  mru.MAG ILIKE '%BG2%'
  AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND market.CompanyCode_Description IS NOT NULL""",
    },
    {
        "input": """can you provide a summary of NMC costs Itm 2026001 actual vs AOP for total MR business per BU. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
dim_cat_functional_area
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for fiscal period 2026001 and MR business segment at MRU_L3 level.
Filter functional areas flagged as NMC and apply row-level security by filtering on the specified email in the security table.
Aggregate actual and AOP NMC costs in EURAOP by business unit (BUGroup).
Calculate the variance between actual and AOP NMC costs and format all amounts in thousands with thousand separators.
Provide a total row summing all business units for actual, AOP, and variance values.""",
        "output": """WITH nmc AS (
  SELECT
    mru.BUGroup AS BU,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_NMC_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_NMC_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_functional_area fa
        ON fpl.FuncAreaPK = fa.FuncAreaPK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND mru.MRU_L3 ILIKE '%MR%'
    AND fa.NMC_Flag ILIKE '%Y%'
    AND mru.BUGroup IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.BUGroup
)
SELECT
  nmc.BU AS `BU`,
  FORMAT_NUMBER(nmc.CY_NMC_kEUR, '#,###') AS `CY NMC (kEUR)`,
  FORMAT_NUMBER(nmc.AOP_NMC_kEUR, '#,###') AS `AOP NMC (kEUR)`,
  FORMAT_NUMBER(nmc.CY_NMC_kEUR - nmc.AOP_NMC_kEUR, '#,###') AS `NMC Variance (kEUR)`
FROM
  nmc
UNION ALL
SELECT
  'Total' AS `BU`,
  FORMAT_NUMBER(SUM(nmc.CY_NMC_kEUR), '#,###') AS `CY NMC (kEUR)`,
  FORMAT_NUMBER(SUM(nmc.AOP_NMC_kEUR), '#,###') AS `AOP NMC (kEUR)`,
  FORMAT_NUMBER(SUM(nmc.CY_NMC_kEUR) - SUM(nmc.AOP_NMC_kEUR), '#,###') AS `NMC Variance (kEUR)`
FROM
  nmc""",
    },
    {
        "input": """What are the FSIs and FSI description posted in Actuals for I and D. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Actuals definition  -  The query assumes 'Actuals' means the 'PostActuals_EURAOP' column, which represents actual posted values in EUR AOP. Alternative interpretations could consider other actuals columns or currencies.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_security_oru
Calculated an answer based on these steps
Filter data to include only records where the business segment MRU Level 6 contains 'I and D'.
Apply row-level security by filtering records to those associated with the email Ravishankar.Ramakrishnan@philips.com.
Select distinct FSItem IDs and their descriptions where the actual posted values in EUR AOP are not zero.
Order the results by FSItem ID for clarity.""",
        "output": """SELECT DISTINCT
  `acct`.`FSItemID` AS FSI,
  `acct`.`FSItem_Description` AS FSI_Description
FROM
  `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` AS fpl
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` AS acct
      ON fpl.`Acct_PK` = acct.`Acct_pk`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` AS mru
      ON fpl.`MAG_PK` = mru.`MAG_PK`
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` AS sec
      ON fpl.`CoCodePK` = sec.`CoCodePK_Security`
WHERE
  mru.`MRU_L6` ILIKE '%I and D%'
  AND sec.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND COALESCE(fpl.`PostActuals_EURAOP`, 0) != 0
ORDER BY
  FSI""",
    },
    {
        "input": """Summarize [sap recon amount] for [PL13] company code, fiscal period(s) [2025011, 2025012 and 2026001] for [GL Account]. Have [document reference] in first column, [text] in second column, then values for respective fiscal period. Give total in the last row. Show numbers rounded off to zero decimals in accounting format. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
SAP Recon Amount  -  The query assumes 'SAP recon amount' refers to the SAP_Recon_EURAOP field in the pps_sap table, which represents amounts in EUR AOP currency. Alternative interpretations could be other currency fields or different amount columns in the SAP reconciliation data.
Found relevant data
pps_sap
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for company code PL13 and fiscal periods 2025011, 2025012, and 2026001.
Group data by document reference and text.
Sum SAP reconciliation amounts for each fiscal period separately.
Format the summed amounts with zero decimals in accounting format.
Include a total row summing all amounts across document references for each fiscal period.
Apply row-level security by filtering on the specified email address.""",
        "output": """WITH sap_summary AS (
  SELECT
    pps_sap.SAP_Recon_Documentreference AS Document_Reference,
    pps_sap.SAP_Recon_Text AS Text,
    SUM(
      CASE
        WHEN pps_sap.SAP_Recon_FiscalPeriodID = '2025011' THEN COALESCE(pps_sap.SAP_Recon_EURAOP, 0)
        ELSE 0
      END
    ) AS Period_2025011,
    SUM(
      CASE
        WHEN pps_sap.SAP_Recon_FiscalPeriodID = '2025012' THEN COALESCE(pps_sap.SAP_Recon_EURAOP, 0)
        ELSE 0
      END
    ) AS Period_2025012,
    SUM(
      CASE
        WHEN pps_sap.SAP_Recon_FiscalPeriodID = '2026001' THEN COALESCE(pps_sap.SAP_Recon_EURAOP, 0)
        ELSE 0
      END
    ) AS Period_2026001
  FROM
    qa_wb.financebi.pps_sap pps_sap
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON pps_sap.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON pps_sap.CoCodePK = sec.CoCodePK_Security
  WHERE
    market.CoCode ILIKE '%PL13%'
    AND pps_sap.SAP_Recon_FiscalPeriodID IN ('2025011', '2025012', '2026001')
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND pps_sap.SAP_Recon_Documentreference IS NOT NULL
    AND pps_sap.SAP_Recon_Text IS NOT NULL
  GROUP BY
    pps_sap.SAP_Recon_Documentreference,
    pps_sap.SAP_Recon_Text
)
SELECT
  Document_Reference,
  Text,
  FORMAT_NUMBER(ROUND(Period_2025011, 0), '#,##0;(#,##0)') AS Period_2025011,
  FORMAT_NUMBER(ROUND(Period_2025012, 0), '#,##0;(#,##0)') AS Period_2025012,
  FORMAT_NUMBER(ROUND(Period_2026001, 0), '#,##0;(#,##0)') AS Period_2026001
FROM
  sap_summary
UNION ALL
SELECT
  'Total',
  '',
  FORMAT_NUMBER(ROUND(SUM(Period_2025011), 0), '#,##0;(#,##0)'),
  FORMAT_NUMBER(ROUND(SUM(Period_2025012), 0), '#,##0;(#,##0)'),
  FORMAT_NUMBER(ROUND(SUM(Period_2026001), 0), '#,##0;(#,##0)')
FROM
  sap_summary""",
    },
    {
        "input": """Top 10 MRU L7 with the biggest change in S&W and the variance of the FTE between AOP 2026 and LY in EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Definition of 'biggest change' in Salaries & Wages  -  The query interprets 'biggest change' as the absolute difference between the 2026 AOP and last year Salaries & Wages in EURAOP, but it could alternatively mean the largest increase or largest decrease specifically.
Time period for LY (Last Year)  -  The query uses fiscal period 2025 as last year, assuming it corresponds to the full previous year relative to 2026 AOP, but 'LY' could be interpreted differently depending on fiscal calendar definitions.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_security_oru
cat_blueprint_prevspostalloc
Referenced trusted example
Top 10 MRU L7 with the biggest change in S&W and the variance of the FTE between AOP and LY for 2026 year in EURAOP
Calculated an answer based on these steps
Calculate total Salaries & Wages in thousand EURAOP for each MRU L7 group for the 2026 AOP period.
Calculate total Salaries & Wages in thousand EURAOP for each MRU L7 group for the last year (LY) period.
Calculate total FTE for each MRU L7 group for the 2026 AOP period.
Calculate total FTE for each MRU L7 group for the last year (LY) period.
Combine these results to show the top 10 MRU L7 groups ranked by the absolute change in Salaries & Wages between 2026 AOP and LY, including the FTE variance, applying row-level security by filtering on the provided email.""",
        "output": """WITH sw_aop AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_S_W_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID LIKE '2026%'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
),
sw_ly AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActualsLY_EURAOP, 0)), 1000)) AS LY_S_W_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID LIKE '2026%'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
),
fte_aop AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(SUM(COALESCE(bp.PostAOP_Alloc_FTE, 0))) AS AOP_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID LIKE '2026%'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
),
fte_ly AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS LY_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON bp.CoCodePK = sec.CoCodePK_Security
  WHERE
    bp.FiscalPeriodID LIKE '2025%'
    AND mru.MRU_L7 IS NOT NULL
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.MRU_L7
)
SELECT
  sw_aop.MRU_L7,
  sw_aop.AOP_S_W_kEUR,
  sw_ly.LY_S_W_kEUR,
  (sw_aop.AOP_S_W_kEUR - sw_ly.LY_S_W_kEUR) AS S_W_Change_kEUR,
  fte_aop.AOP_FTE,
  fte_ly.LY_FTE,
  (fte_aop.AOP_FTE - fte_ly.LY_FTE) AS FTE_Variance
FROM
  sw_aop
    LEFT JOIN sw_ly
      ON sw_aop.MRU_L7 = sw_ly.MRU_L7
    LEFT JOIN fte_aop
      ON sw_aop.MRU_L7 = fte_aop.MRU_L7
    LEFT JOIN fte_ly
      ON sw_aop.MRU_L7 = fte_ly.MRU_L7
ORDER BY
  ABS(sw_aop.AOP_S_W_kEUR - sw_ly.LY_S_W_kEUR) DESC
LIMIT 10""",
    },
    {
        "input": """Summarize & Provide [Sales to Thirds] variance between [CY & AOP] for [2026001 YTD] in [EURAOP] by [MRU L5] for [ORU BMC L5 North America Region]. Include totals at bottom of each column. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Variance calculation direction  -  The variance is calculated as AOP minus actuals, but it could also be interpreted as actuals minus AOP, which would change the sign of the variance values.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for fiscal period 2026001 and sales to thirds accounts.
Filter data for North America Region at the ORU_BMC_L5 market level.
Filter data for the user with email Ravishankar.Ramakrishnan@philips.com for row-level security.
Aggregate sales actuals and AOP in EURAOP by MRU Level 5.
Calculate variance as AOP minus actuals and format results with thousand separators.
Include a total row summing all MRU Level 5 values.""",
        "output": """WITH sales AS (
  SELECT
    mru.MRU_L5 AS MRU_L5,
    FORMAT_NUMBER(
      ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)),
      '#,###'
    ) AS CY_kEUR,
    FORMAT_NUMBER(
      ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)),
      '#,###'
    ) AS AOP_kEUR,
    FORMAT_NUMBER(
      ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000))
      - ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)),
      '#,###'
    ) AS Variance_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON fpl.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND acct.CostAgility_L3 ILIKE '%Sales to thirds%'
    AND market.ORU_BMC_L5 ILIKE '%North America Region%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND mru.MRU_L5 IS NOT NULL
  GROUP BY
    mru.MRU_L5
)
SELECT
  MRU_L5,
  CY_kEUR,
  AOP_kEUR,
  Variance_kEUR
FROM
  sales
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(SUM(CAST(CY_kEUR AS int)), '#,###'),
  FORMAT_NUMBER(SUM(CAST(AOP_kEUR AS int)), '#,###'),
  FORMAT_NUMBER(SUM(CAST(Variance_kEUR AS int)), '#,###')
FROM
  sales""",
    },
    {
        "input": """Summarize & Provide [sales rel costs] variance between [CY & AOP] for [2026001 ITM] in [EUR AOP] by [Cost Center] for [ORU BMC L5 North America Region] for [Top 10 highest variance]. Include totals at bottom of each column.. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_costcenter
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for the first fiscal period of 2026 and sales related costs accounts.
Limit data to cost centers in the North America Region and accessible by the specified email for row-level security.
Calculate total actual sales related costs and plan amounts in thousands of EUR AOP for each cost center.
Calculate the variance as actuals minus plan for each cost center.
Select the top 10 cost centers with the highest absolute variance and include a total row summing these values.""",
        "output": """WITH sales AS (
  SELECT
    cc.CostCenter AS CostCenter,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS CY_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_kEUR,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000))
    - ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS Variance_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON fpl.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_cat_market market
        ON fpl.CoCodePK = market.CocodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND acct.CostAgility_L4 ILIKE '%sales rel costs%'
    AND market.ORU_BMC_L5 ILIKE '%North America Region%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND cc.CostCenter IS NOT NULL
  GROUP BY
    cc.CostCenter
)
SELECT
  CostCenter,
  FORMAT_NUMBER(CY_kEUR, '#,###') AS CY_kEUR,
  FORMAT_NUMBER(AOP_kEUR, '#,###') AS AOP_kEUR,
  FORMAT_NUMBER(Variance_kEUR, '#,###') AS Variance_kEUR
FROM
  (
    SELECT
      *
    FROM
      sales
    ORDER BY
      ABS(Variance_kEUR) DESC
    LIMIT 10
  ) top10
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(SUM(CY_kEUR), '#,###'),
  FORMAT_NUMBER(SUM(AOP_kEUR), '#,###'),
  FORMAT_NUMBER(SUM(Variance_kEUR), '#,###')
FROM
  (
    SELECT
      *
    FROM
      sales
    ORDER BY
      ABS(Variance_kEUR) DESC
    LIMIT 10
  ) top10""",
    },
    {
        "input": """Summarize & Provide [Travel] variance between [CY & AOP] for [2026001 YTD] in [EURAOP] by [MRU L5] for [ORU BMC L5 North America Region]. Include totals at bottom of each column. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
cat_fpl_prevspostalloc
dim_cat_mru
dim_cat_market
dim_cat_account_fpl
dim_cat_date_fiscalperiod
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for fiscal period 2026001 and year 2026.
Filter accounts related to travel expenses using CostAgility Level 4.
Filter market data to include only the North America region at ORU_BMC_L5 level.
Filter data for the user with email Ravishankar.Ramakrishnan@philips.com for row-level security.
Aggregate the total travel expenses for current year actuals (CY) and annual operating plan (AOP) by MRU Level 5.
Calculate the variance as the difference between CY and AOP for each MRU Level 5.
Format the results with thousand separators and no decimals.
Include a total row summing all MRU Level 5 values for CY, AOP, and variance.""",
        "output": """WITH travel_data AS (
  SELECT
    mru.MRU_L5,
    ROUND(SUM(try_divide(COALESCE(fpl.PostActuals_EURAOP, 0), 1000))) AS CY,
    ROUND(SUM(try_divide(COALESCE(fpl.PostAOP_EURAOP, 0), 1000))) AS AOP
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
      JOIN qa_wb.financebi.dim_cat_market mkt
        ON fpl.CoCodePK = mkt.CoCodePK
      JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      JOIN qa_wb.financebi.dim_cat_date_fiscalperiod fp
        ON fpl.FiscalPeriodID = fp.FiscalPeriodID
      JOIN qa_wb.financebi.dim_cat_security_oru sec
        ON fpl.CoCodePK = sec.CoCodePK_Security
  WHERE
    fpl.FiscalPeriodID = '2026001'
    AND fp.Year = '2026'
    AND acct.CostAgility_L4 ILIKE '%Travel%'
    AND mkt.ORU_BMC_L5 ILIKE '%North America Region%'
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND mru.MRU_L5 IS NOT NULL
  GROUP BY
    mru.MRU_L5
),
travel_total AS (
  SELECT
    'Total' AS MRU_L5,
    SUM(CY) AS CY,
    SUM(AOP) AS AOP,
    SUM(CY - AOP) AS Variance
  FROM
    travel_data
)
SELECT
  MRU_L5,
  FORMAT_NUMBER(CY, '#,###') AS CY,
  FORMAT_NUMBER(AOP, '#,###') AS AOP,
  FORMAT_NUMBER(CY - AOP, '#,###') AS Variance
FROM
  travel_data
UNION ALL
SELECT
  MRU_L5,
  FORMAT_NUMBER(CY, '#,###'),
  FORMAT_NUMBER(AOP, '#,###'),
  FORMAT_NUMBER(Variance, '#,###')
FROM
  travel_total""",
    },
    {
        "input": """summarize sap recon amount for company code US18, for PH MRU L5 2026 for GL account 6101000. Have payroll category in first column, then values for 2025010, 2025011, and 2025012. Show totals in the last row.. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
pps_sap
dim_cat_mru
dim_cat_account_fpl
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for company code US18, PH MRU L5, GL account 6101000, and fiscal periods 2025010, 2025011, 2025012 in 2026.
Apply row-level security by filtering records based on the user's email in the security table.
Group the data by payroll category and fiscal period, summing the SAP reconciliation amounts in EURAOP and converting to thousands.
Pivot the data to have fiscal periods 2025010, 2025011, and 2025012 as separate columns with their respective amounts.
Calculate a total amount across the three fiscal periods for each payroll category and add a total row summing all payroll categories.""",
        "output": """WITH filtered AS (
  SELECT
    pps_sap.SAP_Recon_PayrollCategory AS Payroll_Category,
    pps_sap.SAP_Recon_FiscalPeriodID AS FiscalPeriodID,
    COALESCE(ROUND(try_divide(SUM(pps_sap.SAP_Recon_EURAOP), 1000)), 0) AS Amount_k
  FROM
    qa_wb.financebi.pps_sap AS pps_sap
      INNER JOIN qa_wb.financebi.dim_cat_mru AS mru
        ON pps_sap.MAG_PK = mru.MAG_PK
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl AS acct
        ON pps_sap.Acct_PK = acct.Acct_PK
      INNER JOIN qa_wb.financebi.dim_cat_market AS market
        ON pps_sap.CoCodePK = market.CoCodePK
      INNER JOIN qa_wb.financebi.dim_cat_security_oru AS sec
        ON pps_sap.CoCodePK = sec.CoCodePK_Security
  WHERE
    market.CoCode ILIKE '%US18%'
    AND mru.MRU_L5 ILIKE '%PH%'
    AND acct.AccountID ILIKE '%6101000%'
    AND pps_sap.SAP_Recon_FiscalPeriodID IN ('2025010', '2025011', '2025012')
    AND sec.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    pps_sap.SAP_Recon_PayrollCategory,
    pps_sap.SAP_Recon_FiscalPeriodID
)
SELECT
  Payroll_Category,
  COALESCE(
    MAX(
      CASE
        WHEN FiscalPeriodID = '2025010' THEN Amount_k
      END
    ),
    0
  ) AS `2025010`,
  COALESCE(
    MAX(
      CASE
        WHEN FiscalPeriodID = '2025011' THEN Amount_k
      END
    ),
    0
  ) AS `2025011`,
  COALESCE(
    MAX(
      CASE
        WHEN FiscalPeriodID = '2025012' THEN Amount_k
      END
    ),
    0
  ) AS `2025012`,
  (
    COALESCE(
      MAX(
        CASE
          WHEN FiscalPeriodID = '2025010' THEN Amount_k
        END
      ),
      0
    )
    + COALESCE(
      MAX(
        CASE
          WHEN FiscalPeriodID = '2025011' THEN Amount_k
        END
      ),
      0
    )
    + COALESCE(
      MAX(
        CASE
          WHEN FiscalPeriodID = '2025012' THEN Amount_k
        END
      ),
      0
    )
  ) AS Total
FROM
  filtered
GROUP BY
  Payroll_Category
UNION ALL
SELECT
  'Total' AS Payroll_Category,
  COALESCE(
    SUM(
      CASE
        WHEN FiscalPeriodID = '2025010' THEN Amount_k
      END
    ),
    0
  ) AS `2025010`,
  COALESCE(
    SUM(
      CASE
        WHEN FiscalPeriodID = '2025011' THEN Amount_k
      END
    ),
    0
  ) AS `2025011`,
  COALESCE(
    SUM(
      CASE
        WHEN FiscalPeriodID = '2025012' THEN Amount_k
      END
    ),
    0
  ) AS `2025012`,
  COALESCE(SUM(Amount_k), 0) AS Total
FROM
  filtered""",
    },
    {
        "input": """Summarize & Provide [Sales to Thirds] variance between [CY & AOP] for [2025011 YTD] in [EURAOP] by [MRU L5] for [ORU BMC L5 North America Region]. Include totals at bottom of each column. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Fiscal period 2025011 interpretation  -  The fiscal period '2025011' is interpreted as a year-to-date period ending at this fiscal period, but it could alternatively be interpreted as a single fiscal period or a different range of periods.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_market
dim_cat_date_fiscalperiod
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for sales to thirds accounts and North America region in ORU BMC L5.
Limit data to fiscal periods up to 2025011 in the year 2026.
Aggregate the current year actuals and AOP values in EURAOP by MRU level 5.
Calculate the variance as the difference between current year actuals and AOP, rounding all values and scaling to thousands.
Include a total row summing all MRU level 5 groups for each metric.
Apply row-level security by filtering data for the specified email in the security table.""",
        "output": """WITH base AS (
  SELECT
    mru.`MRU_L5` AS `MRU L5`,
    try_divide(
      COALESCE(
        SUM(
          CASE
            WHEN fpl.`PostActuals_EURAOP` IS NULL THEN 0
            ELSE fpl.`PostActuals_EURAOP`
          END
        ),
        0
      ),
      1000
    ) AS `CY (k)`,
    try_divide(
      COALESCE(
        SUM(
          CASE
            WHEN fpl.`PostAOP_EURAOP` IS NULL THEN 0
            ELSE fpl.`PostAOP_EURAOP`
          END
        ),
        0
      ),
      1000
    ) AS `AOP (k)`
  FROM
    `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` fpl
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` acct
        ON fpl.`Acct_PK` = acct.`Acct_pk`
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
        ON fpl.`MAG_PK` = mru.`MAG_PK`
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_market` market
        ON fpl.`CoCodePK` = market.`CoCodePK`
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_date_fiscalperiod` datef
        ON fpl.`FiscalPeriodID` = datef.`FiscalPeriodID`
      INNER JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` sec
        ON fpl.`CoCodePK` = sec.`CoCodePK_Security`
  WHERE
    acct.`CostAgility_L4` ILIKE '%Sales to Thirds%'
    AND market.`ORU_BMC_L5` ILIKE '%North America Region%'
    AND sec.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
    AND datef.`Year` = '2026'
    AND fpl.`FiscalPeriodID` <= '2025011'
    AND mru.`MRU_L5` IS NOT NULL
  GROUP BY
    mru.`MRU_L5`
),
final AS (
  SELECT
    `MRU L5`,
    ROUND(`CY (k)`) AS `CY (k)`,
    ROUND(`AOP (k)`) AS `AOP (k)`,
    ROUND(`CY (k)` - `AOP (k)`) AS `Variance (k)`
  FROM
    base
)
SELECT
  *
FROM
  final
UNION ALL
SELECT
  'Total',
  ROUND(SUM(`CY (k)`)),
  ROUND(SUM(`AOP (k)`)),
  ROUND(SUM(`Variance (k)`))
FROM
  final""",
    },
    {
        "input": """Summarize  PPS Amount for Company code PL90 and GL Account 6100100 for period 2025.007 to 2025.012. Show period in first column and Description in second column. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
pps
dim_cat_account_fpl
dim_cat_market
dim_cat_security_oru
Calculated an answer based on these steps
Filter PPS data for company code PL90 and GL account 6100100.
Limit data to fiscal periods between 2025.007 and 2025.012.
Apply row-level security by filtering on the specified email in the security table.
Summarize the PPS amounts in euros at AOP rate by fiscal period and description.
Include a total row summing all amounts across the selected periods and descriptions.""",
        "output": """SELECT
  pps.`PPS_Recon_FiscalPeriodID` AS Period,
  pps.`PPS_Recon_Description` AS Description,
  FORMAT_NUMBER(
    COALESCE(ROUND(try_divide(SUM(pps.`PPS_Recon_EURAOP`), 1000), 0), 0),
    '#,##0'
  ) AS AmountEUR_k
FROM
  `qa_wb`.`financebi`.`pps` AS pps
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` AS account
      ON pps.`Acct_PK` = CAST(account.`AccountID` AS INT)
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_market` AS market
      ON pps.`CoCodePK` = CAST(market.`CoCode` AS INT)
WHERE
  market.`CoCode` ILIKE '%PL90%'
  AND account.`AccountID` = '6100100'
  AND pps.`PPS_Recon_FiscalPeriodID` BETWEEN '2025007' AND '2025012'
  AND EXISTS (
    SELECT
      1
    FROM
      `qa_wb`.`financebi`.`dim_cat_security_oru` AS security
    WHERE
      security.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  )
GROUP BY
  pps.`PPS_Recon_FiscalPeriodID`,
  pps.`PPS_Recon_Description`
UNION ALL
SELECT
  'Total' AS Period,
  '' AS Description,
  FORMAT_NUMBER(
    COALESCE(ROUND(try_divide(SUM(pps.`PPS_Recon_EURAOP`), 1000), 0), 0),
    '#,##0'
  ) AS AmountEUR_k
FROM
  `qa_wb`.`financebi`.`pps` AS pps
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` AS account
      ON pps.`Acct_PK` = CAST(account.`AccountID` AS INT)
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_market` AS market
      ON pps.`CoCodePK` = CAST(market.`CoCode` AS INT)
WHERE
  market.`CoCode` ILIKE '%PL90%'
  AND account.`AccountID` = '6100100'
  AND pps.`PPS_Recon_FiscalPeriodID` BETWEEN '2025007' AND '2025012'
  AND EXISTS (
    SELECT
      1
    FROM
      `qa_wb`.`financebi`.`dim_cat_security_oru` AS security
    WHERE
      security.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  )""",
    },
    {
        "input": """what is the FA for CC IN5BFPA004 as per master data. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Found relevant data
dim_cat_costcenter
dim_cat_security_oru
Calculated an answer based on these steps
Filter the cost center data to only include the cost center IN5BFPA004.
Apply a filter to the security data to only include rows where the email matches Ravishankar.Ramakrishnan@philips.com.
Combine the cost center data with the security data based on the company code to enforce row-level security.
Retrieve the distinct functional area (FA_CC) for the specified cost center from the filtered and combined data.
Exclude any records where the functional area is null to ensure meaningful results.""",
        "output": """SELECT DISTINCT
  `cc`.`FA_CC` AS `Functional_Area`
FROM
  `qa_wb`.`financebi`.`dim_cat_costcenter` cc
    INNER JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` sec
      ON `cc`.`CoCode` = `sec`.`Code1ID`
WHERE
  `cc`.`CostCenter` ILIKE '%IN5BFPA004%'
  AND `sec`.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  AND `cc`.`FA_CC` IS NOT NULL""",
    },
    {
        "input": """Please provide AOP data for  FTE for this cost center IN5BFPA004 by period for the year 2026. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
AOP for FTE  -  The query assumes AOP refers to the planned Full Time Equivalent (FTE) values from the cat_blueprint_prevspostalloc table, but AOP could also be interpreted as other plan cycles or different data sources for FTE.
Found relevant data
cat_blueprint_prevspostalloc
dim_cat_costcenter
dim_cat_date_fiscalperiod
dim_cat_security_oru
Calculated an answer based on these steps
Filter data for the cost center IN5BFPA004 using a case-insensitive match.
Limit the data to the calendar year 2026.
Apply row-level security by filtering the data to only include records accessible by the specified email.
Aggregate the planned FTE values by fiscal period.
Round the aggregated FTE values and label the metric as 'FTE_AOP'.""",
        "output": """SELECT
  dcf.FiscalPeriodID AS Period,
  'FTE_AOP' AS Metric,
  ROUND(COALESCE(SUM(cbpp.PostAOP_Alloc_FTE), 0), 0) AS Value
FROM
  `qa_wb`.`financebi`.`cat_blueprint_prevspostalloc` cbpp
    JOIN `qa_wb`.`financebi`.`dim_cat_costcenter` dcc
      ON cbpp.CC_PK_IPL = dcc.CC_PK_IPL
    JOIN `qa_wb`.`financebi`.`dim_cat_date_fiscalperiod` dcf
      ON cbpp.FiscalPeriodID = dcf.FiscalPeriodID
    JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` dso
      ON cbpp.CoCodePK = dso.CoCodePK
WHERE
  dcc.CostCenter ILIKE '%IN5BFPA004%'
  AND dcf.Year = '2026'
  AND dso.Email ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
GROUP BY
  dcf.FiscalPeriodID
ORDER BY
  Period""",
    },
    {
        "input": """Summarize & Provide [FTE] and [Salaries and Wages] variance between [CY & FC] for [2025011 ITM] by [MAG] for [BUGroup Finance]. Format numbers with thousand separator and no decimals. Add total at the bottom of each column. Amounts in K EURAOP. Apply Row Level Security by Filtering Email column in CAT Security Table with this EmailID Ravishankar.Ramakrishnan@philips.com""",
        "analysis": """Understanding the question
Variance calculation direction  -  The variance is calculated as current year minus forecast, which assumes this direction is what the user wants. Alternatively, it could be forecast minus current year.
Definition of Finance business group  -  The filter uses a case-insensitive partial match on BUGroup with 'Finance'. This assumes the user wants all MAGs related to any Finance group, but the exact scope of 'Finance' could vary.
Found relevant data
cat_fpl_prevspostalloc
dim_cat_account_fpl
dim_cat_mru
dim_cat_security_oru
cat_blueprint_prevspostalloc
Calculated an answer based on these steps
Aggregate Salaries & Wages for current year and forecast for fiscal period 2025011 by MAG within the Finance business group.
Aggregate Full Time Equivalents (FTE) for current year and forecast for the same period and business group by MAG.
Calculate the variance between current year and forecast for both Salaries & Wages and FTE.
Format the results with thousand separators and no decimals, and include a total row summing all MAGs.
Apply row-level security by filtering data based on the user's email.""",
        "output": """WITH sw AS (
  SELECT
    mru.`MAG` AS MAG,
    ROUND(try_divide(COALESCE(SUM(fpl.`PostActuals_EURAOP`), 0), 1000)) AS S_W_CY_k,
    ROUND(try_divide(COALESCE(SUM(fpl.`PostJunFC_EURAOP`), 0), 1000)) AS S_W_FC_k
  FROM
    `qa_wb`.`financebi`.`cat_fpl_prevspostalloc` fpl
      JOIN `qa_wb`.`financebi`.`dim_cat_account_fpl` acct
        ON fpl.`Acct_PK` = acct.`Acct_PK`
      JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
        ON fpl.`MAG_PK` = mru.`MAG_PK`
      JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` sec
        ON fpl.`CoCodePK` = sec.`CoCodePK`
  WHERE
    acct.`CostAgility_L4` ILIKE '%Salaries & Wages%'
    AND fpl.`FiscalPeriodID` = '2025011'
    AND mru.`BUGroup` ILIKE '%Finance%'
    AND sec.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.`MAG`
),
fte AS (
  SELECT
    mru.`MAG` AS MAG,
    ROUND(COALESCE(SUM(bp.`PostActuals_Alloc_FTE`), 0)) AS FTE_CY,
    ROUND(COALESCE(SUM(bp.`PostJunFC_Alloc_FTE`), 0)) AS FTE_FC
  FROM
    `qa_wb`.`financebi`.`cat_blueprint_prevspostalloc` bp
      JOIN `qa_wb`.`financebi`.`dim_cat_mru` mru
        ON bp.`MAG_PK` = mru.`MAG_PK`
      JOIN `qa_wb`.`financebi`.`dim_cat_security_oru` sec
        ON bp.`CoCodePK` = sec.`CoCodePK`
  WHERE
    bp.`FiscalPeriodID` = '2025011'
    AND mru.`BUGroup` ILIKE '%Finance%'
    AND sec.`Email` ILIKE '%Ravishankar.Ramakrishnan@philips.com%'
  GROUP BY
    mru.`MAG`
),
combined AS (
  SELECT
    COALESCE(sw.MAG, fte.MAG) AS MAG,
    COALESCE(sw.S_W_CY_k, 0) AS S_W_CY_k,
    COALESCE(sw.S_W_FC_k, 0) AS S_W_FC_k,
    COALESCE(sw.S_W_CY_k, 0) - COALESCE(sw.S_W_FC_k, 0) AS S_W_Variance_k,
    COALESCE(fte.FTE_CY, 0) AS FTE_CY,
    COALESCE(fte.FTE_FC, 0) AS FTE_FC,
    COALESCE(fte.FTE_CY, 0) - COALESCE(fte.FTE_FC, 0) AS FTE_Variance
  FROM
    sw
      FULL OUTER JOIN fte
        ON sw.MAG = fte.MAG
)
SELECT
  MAG,
  FORMAT_NUMBER(S_W_CY_k, '#,###') AS S_W_CY_k,
  FORMAT_NUMBER(S_W_FC_k, '#,###') AS S_W_FC_k,
  FORMAT_NUMBER(S_W_Variance_k, '#,###') AS S_W_Variance_k,
  FORMAT_NUMBER(FTE_CY, '#,###') AS FTE_CY,
  FORMAT_NUMBER(FTE_FC, '#,###') AS FTE_FC,
  FORMAT_NUMBER(FTE_Variance, '#,###') AS FTE_Variance
FROM
  combined
UNION ALL
SELECT
  'Total',
  FORMAT_NUMBER(SUM(S_W_CY_k), '#,###'),
  FORMAT_NUMBER(SUM(S_W_FC_k), '#,###'),
  FORMAT_NUMBER(SUM(S_W_Variance_k), '#,###'),
  FORMAT_NUMBER(SUM(FTE_CY), '#,###'),
  FORMAT_NUMBER(SUM(FTE_FC), '#,###'),
  FORMAT_NUMBER(SUM(FTE_Variance), '#,###')
FROM
  combined
ORDER BY
  CASE
    WHEN MAG = 'Total' THEN 1
    ELSE 0
  END,
  MAG""",
    },
    {
        "input": """Top 10 MRU L7 with the biggest change in S&W and the variance of the FTE between AOP and LY for 2026 year in EURAOP""",
        "analysis": """""",
        "output": """WITH sw_aop AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(try_divide(SUM(COALESCE(fpl.PostAOP_EURAOP, 0)), 1000)) AS AOP_S_W_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
  WHERE
    acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID LIKE '2026%'
    AND mru.MRU_L7 IS NOT NULL
  GROUP BY
    mru.MRU_L7
),
sw_ly AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActualsLY_EURAOP, 0)), 1000)) AS LY_S_W_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_pk
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON fpl.MAG_PK = mru.MAG_PK
  WHERE
    acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID LIKE '2026%'
    AND mru.MRU_L7 IS NOT NULL
  GROUP BY
    mru.MRU_L7
),
fte_aop AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(SUM(COALESCE(bp.PostAOP_Alloc_FTE, 0))) AS AOP_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
  WHERE
    bp.FiscalPeriodID LIKE '2026%'
    AND mru.MRU_L7 IS NOT NULL
  GROUP BY
    mru.MRU_L7
),
fte_ly AS (
  SELECT
    mru.MRU_L7 AS MRU_L7,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS LY_FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_mru mru
        ON bp.MAG_PK = mru.MAG_PK
  WHERE
    bp.FiscalPeriodID LIKE '2025%'
    AND mru.MRU_L7 IS NOT NULL
  GROUP BY
    mru.MRU_L7
)
SELECT
  sw_aop.MRU_L7,
  sw_aop.AOP_S_W_kEUR,
  sw_ly.LY_S_W_kEUR,
  (sw_aop.AOP_S_W_kEUR - sw_ly.LY_S_W_kEUR) AS S_W_Change_kEUR,
  fte_aop.AOP_FTE,
  fte_ly.LY_FTE,
  (fte_aop.AOP_FTE - fte_ly.LY_FTE) AS FTE_Variance
FROM
  sw_aop
    LEFT JOIN sw_ly
      ON sw_aop.MRU_L7 = sw_ly.MRU_L7
    LEFT JOIN fte_aop
      ON sw_aop.MRU_L7 = fte_aop.MRU_L7
    LEFT JOIN fte_ly
      ON sw_aop.MRU_L7 = fte_ly.MRU_L7
ORDER BY
  ABS(sw_aop.AOP_S_W_kEUR - sw_ly.LY_S_W_kEUR) DESC
LIMIT 10""",
    },
    {
        "input": """Summarize Actuals & FTE for S&W for Current Year by Cost Center for my Costcenter""",
        "analysis": """""",
        "output": """WITH sw_actuals AS (
  SELECT
    cc.CostCenter AS Cost_Center,
    ROUND(try_divide(SUM(COALESCE(fpl.PostActuals_EURAOP, 0)), 1000)) AS S_W_Actuals_kEUR
  FROM
    qa_wb.financebi.cat_fpl_prevspostalloc fpl
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON fpl.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_pflt_cc_mapping map
        ON cc.CostCenter = map.PFLT_CostCenter
      INNER JOIN qa_wb.financebi.dim_cat_account_fpl acct
        ON fpl.Acct_PK = acct.Acct_PK
  WHERE
    map.PFLT_Email ILIKE '%user mail%'
    AND acct.CostAgility_L4 ILIKE '%Salaries & Wages%'
    AND fpl.FiscalPeriodID LIKE '2026%'
  GROUP BY
    cc.CostCenter
),
fte_actuals AS (
  SELECT
    cc.CostCenter AS Cost_Center,
    ROUND(SUM(COALESCE(bp.PostActuals_Alloc_FTE, 0))) AS FTE
  FROM
    qa_wb.financebi.cat_blueprint_prevspostalloc bp
      INNER JOIN qa_wb.financebi.dim_cat_costcenter cc
        ON bp.CC_PK_IPL = cc.CC_PK_IPL
      INNER JOIN qa_wb.financebi.dim_pflt_cc_mapping map
        ON cc.CostCenter = map.PFLT_CostCenter
  WHERE
    map.PFLT_Email ILIKE '%user mail%'
    AND bp.FiscalPeriodID LIKE '2026%'
  GROUP BY
    cc.CostCenter
)
SELECT
  a.Cost_Center,
  a.S_W_Actuals_kEUR,
  f.FTE
FROM
  sw_actuals a
    LEFT JOIN fte_actuals f
      ON a.Cost_Center = f.Cost_Center""",
    },
]


def _generate_tags(input_text, output_text):
    """Auto-generate tags for a few-shot example based on content."""
    tags = set()
    combined = (input_text + " " + output_text).lower()
    tag_patterns = {
        "variance": ["variance", "vs", "versus"],
        "totals": ["total", "totals", "include total", "add total"],
        "top_n": ["top 10", "top 5", "top 20", "highest", "biggest"],
        "format_number": ["format", "thousand separator", "formatted"],
        "rls": ["email", "security", "row level"],
        "ytd": ["ytd", "year to date"],
        "itm": ["itm", "in the month"],
        "mru": ["mru_l", "mru l"],
        "cost_center": ["cost center", "costcenter"],
        "pps": ["pps_recon", "pps recon", "pps amount"],
        "sap": ["sap_recon", "sap recon", "sap amount"],
        "fte": ["fte", "full time"],
        "sw": ["salaries", "s&w", "wages"],
        "nmc": ["nmc", "non-manufacturing"],
        "blueprint": ["blueprint", "cat_blueprint"],
        "travel": ["travel"],
        "sales": ["sales to thirds", "sales rel"],
        "drill_down": ["drill", "from the result", "highest.*show"],
        "multi_measure": ["fte and", "and salaries", "and s&w"],
        "functional_area": ["functional area", "fa_cc", "funcarea"],
        "cost_agility": ["cost agility", "costagility"],
        "oru": ["oru", "region", "north america"],
        "market": ["market", "company code", "cocode"],
        "account": ["gl account", "accountid", "fsi", "fsitem"],
        "adap": ["adap"],
    }
    for tag, keywords in tag_patterns.items():
        if any(kw in combined for kw in keywords):
            tags.add(tag)
    return list(tags)

for ex in FEW_SHOT_EXAMPLES:
    ex["tags"] = _generate_tags(ex["input"], ex["output"])




