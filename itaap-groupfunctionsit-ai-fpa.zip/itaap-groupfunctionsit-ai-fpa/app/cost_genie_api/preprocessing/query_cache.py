import threading
import re

class QueryCache:
    """
    Simple in-memory LRU cache for SQL generation results.
    Exact match on normalized query text -> returns cached SQL + insights.
    """
    def __init__(self, max_size: int = 50):
        self.cache = {}
        self.max_size = max_size
        self.hits = 0
        self.misses = 0
    
    def _normalize(self, query: str) -> str:
        return re.sub(r'\s+', ' ', query.lower().strip())
    
    def get(self, query: str) -> dict:
        key = self._normalize(query)
        if key in self.cache:
            self.hits += 1
            return self.cache[key]
        self.misses += 1
        return None
    
    def put(self, query: str, result: dict):
        key = self._normalize(query)
        if len(self.cache) >= self.max_size:
            oldest_key = next(iter(self.cache))
            del self.cache[oldest_key]
        self.cache[key] = result
    
    def stats(self) -> str:
        total = self.hits + self.misses
        rate = f"{self.hits/total*100:.0f}%" if total > 0 else "N/A"
        return f"Cache: {len(self.cache)} entries, {self.hits} hits, {self.misses} misses ({rate} hit rate)"

query_cache = QueryCache(max_size=50)
print("  [OK] Query pre-processor defined (extracts inline translate/format instructions)")
print("  [OK] Intent classifier (scope guard + inline detection)")
print("  [OK] Out-of-scope handler defined")
print("  [OK] Query response cache initialized (max 50 entries)")
