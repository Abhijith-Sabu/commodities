import pandas as pd
import time as _time
from app.cost_genie_api.preprocessing.instruction_extractor import extract_inline_instructions
from app.cost_genie_api.preprocessing.intent_classifier import classify_intent
from app.cost_genie_api.state.trace import _trace,tc
from app.cost_genie_api.state.supervisor_state import SupervisorState,QueryIntent
from app.cost_genie_api.config.agent_registry import AgentRole
from app.cost_genie_api.preprocessing.query_cache import query_cache
from app.cost_genie_api.postprocessing.general import handle_general_query
from app.cost_genie_api.preprocessing.intent_classifier import handle_out_of_scope
from app.cost_genie_api.postprocessing.translate import translate_dataframe
from app.cost_genie_api.postprocessing.explain import handle_explain_term
from app.cost_genie_api.agents.planner import planner_agent
from app.cost_genie_api.agents.sql_generator import sql_agent
from app.cost_genie_api.agents.validator import validation_agent
from app.cost_genie_api.graph.nodes import sql_retry_node,MAX_SQL_RETRIES
from app.cost_genie_api.graph.supervisor import genie_supervisor
from langgraph.graph import END







def ask_cost_genie(user_query: str, execute: bool = True, verbose: bool = True,
                   previous_df: pd.DataFrame = None) -> dict:
    """
    Cost Genie -  Enhanced Multi-Agent Supervisor with Inline Translation.

    Enhancements:
      - Query pre-processor: Extracts inline translation instructions before SQL generation
      - Inline translation: Applies column translation AFTER SQL execution, BEFORE insights
      - Scope guard: Non-finance queries get appropriate response
      - Clean query: SQL Agent receives query without translation noise

    Architecture:
      Pre-Processor -> Intent Router -> [SQL Pipeline | Translator | Explainer | General | Scope Guard]
      SQL Pipeline: Planner -> SQL -> Validation -> Executor -> Inline Translate -> Insight
      Self-correction: SQL retry (<=2) + Exec retry (<=2) + Empty recovery (<=2)

    Args:
        user_query: Natural language question about Philips finance data
        execute: If True, runs SQL on Spark. If False, generates SQL only (dry run).
        verbose: Print progress updates
        previous_df: Optional DataFrame from a previous query (for standalone translation)

    Returns: {data: DataFrame, summary: str, sql: str, trace: list, confidence: dict, intent: str}
    """
    print("=" * 70)
    print(f"  COST GENIE | Multi-Agent Supervisor")
    print(f"  Query: {user_query[:120]}{'...' if len(user_query) > 120 else ''}")
    print("=" * 70)

    start_time = _time.time()

    # === Step 0: Pre-process  -  Extract inline instructions ===
    clean_query, inline_instructions = extract_inline_instructions(user_query)
    
    if verbose and inline_instructions:
        print(f"\n  > Inline instructions extracted ({len(inline_instructions)}):")
        for instr in inline_instructions:
            print(f"    - {instr.instruction_type}: {instr.params}")
        print(f"  > Clean query: {clean_query[:100]}{'...' if len(clean_query) > 100 else ''}")

    # === Step 1: Intent Classification ===
    intent = classify_intent(user_query)
    if verbose:
        print(f"\n  > Intent: {intent}")

    # === Handle Non-SQL Intents ===

    if intent == QueryIntent.OUT_OF_SCOPE.value:
        if verbose:
            print("  > Routing to Scope Guard")
        response_text = handle_out_of_scope(user_query)
        duration = _time.time() - start_time
        print(f"\n{response_text}")
        print(f"\n  [time] {duration:.1f}s")
        return {
            "data": pd.DataFrame(),
            "summary": response_text,
            "sql": "",
            "trace": [_trace("OUT_OF_SCOPE", "Scope guard response", "supervisor")],
            "confidence": {"confidence": 10, "concerns": []},
            "intent": intent,
        }

    if intent == QueryIntent.TRANSLATE_RESULTS.value:
        if verbose:
            print("  > Routing to PostProcessor (Standalone Translation)")
        df_to_translate = previous_df if previous_df is not None else pd.DataFrame()
        if df_to_translate.empty:
            translation = ("No previous results to translate. Please run a data query first, "
                         "then ask me to translate the results.\n\n"
                         "Tip: You can also include translation directly in your data query:\n"
                         '  "Summarize cost for XXX... Translate the text column from Italian to English"')
        else:
            translation = translate_dataframe(df_to_translate, user_query)
        
        duration = _time.time() - start_time
        print(f"\n{'=' * 40}")
        print("  TRANSLATION RESULTS")
        print(f"{'=' * 40}")
        print(translation)
        print(f"\n  [time] {duration:.1f}s")
        
        return {
            "data": df_to_translate,
            "summary": translation,
            "sql": "",
            "trace": [_trace("TRANSLATE", f"Translated {len(df_to_translate)} rows", "postprocessor")],
            "confidence": {"confidence": 10, "concerns": []},
            "intent": intent,
        }

    if intent == QueryIntent.EXPLAIN_TERM.value:
        if verbose:
            print("  > Routing to PostProcessor (Term Explanation)")
        explanation = handle_explain_term(user_query)
        
        duration = _time.time() - start_time
        print(f"\n{'=' * 40}")
        print("  EXPLANATION")
        print(f"{'=' * 40}")
        print(explanation)
        print(f"\n  [time] {duration:.1f}s")
        
        return {
            "data": pd.DataFrame(),
            "summary": explanation,
            "sql": "",
            "trace": [_trace("EXPLAIN", "Term explanation", "postprocessor")],
            "confidence": {"confidence": 10, "concerns": []},
            "intent": intent,
        }

    if intent == QueryIntent.GENERAL_CHAT.value:
        if verbose:
            print("  > Routing to General Handler")
        response_text = handle_general_query(user_query)
        
        duration = _time.time() - start_time
        print(f"\n{response_text}")
        print(f"\n  [time] {duration:.1f}s")
        
        return {
            "data": pd.DataFrame(),
            "summary": response_text,
            "sql": "",
            "trace": [_trace("GENERAL", "General query handled", "postprocessor")],
            "confidence": {"confidence": 10, "concerns": []},
            "intent": intent,
        }

    # === SQL Query Path: Check Cache First ===
    cached = query_cache.get(user_query)
    if cached and execute:
        if verbose:
            print(f"  > Cache HIT  -  returning cached result")
            print(f"  {query_cache.stats()}")
        duration = _time.time() - start_time
        _print_output(user_query, cached["sql"], cached["summary"], 
                     cached["data"], cached["confidence"], cached.get("trace", []), executed=True)
        return cached

    # === SQL Query Path: Full Pipeline with Inline Instructions ===
    # Convert InlineInstructions to dicts for state serialization
    instructions_as_dicts = [
        {"instruction_type": i.instruction_type, "raw_text": i.raw_text, "params": i.params}
        for i in inline_instructions
    ]
    
    initial_state: SupervisorState = {
        "user_query": user_query,
        "clean_query": clean_query,           # Clean query for SQL generation
        "verbose": verbose,
        "intent": intent,
        "inline_instructions": instructions_as_dicts,  # For inline_translate node
        "analysis": {},
        "execution_plan": [],
        "is_multi_step": False,
        "generated_sql": "",
        "analysis_text": "",
        "few_shot_context": "",
        "sql_retry_count": 0,
        "validation_result": {},
        "confidence_score": {},
        "sql_approved": False,
        "execution_result": {},
        "final_sql": "",
        "insights": "",
        "current_step_idx": 0,
        "step_results": {},
        "all_steps_complete": False,
        "trace": [],
        "messages": [],
        "error_history": [],
        "recovery_mode": "normal",
        "translated_df": "",
        "general_response": "",
    }

    if not execute:
        from langgraph.graph import StateGraph as SG
        dry_run = SG(SupervisorState)
        dry_run.add_node("planner", planner_agent)
        dry_run.add_node("sql", sql_agent)
        dry_run.add_node("validation", validation_agent)
        dry_run.add_node("sql_retry", sql_retry_node)
        def dry_finalize(s):
            trace = list(s.get("trace", []))
            trace.append(_trace("DRY_RUN_END", "Execution skipped (dry run)", AgentRole.SUPERVISOR.value))
            return {"final_sql": s.get("generated_sql", ""), "trace": trace}
        dry_run.add_node("finalize", dry_finalize)
        dry_run.set_entry_point("planner")
        dry_run.add_edge("planner", "sql")
        dry_run.add_edge("sql", "validation")
        def dry_route_after_validation(state):
            if state.get("sql_approved", False):
                return "finalize"
            if state.get("sql_retry_count", 0) >= MAX_SQL_RETRIES:
                return "finalize"
            return "sql_retry"
        dry_run.add_conditional_edges(
            "validation",
            dry_route_after_validation,
            {"finalize": "finalize", "sql_retry": "sql_retry"},
        )
        dry_run.add_edge("sql_retry", "sql")
        dry_run.add_edge("finalize", END)
        result = dry_run.compile(checkpointer=None).invoke(initial_state)

        sql_query = result.get("final_sql", result.get("generated_sql", ""))
        trace = result.get("trace", [])
        confidence = result.get("confidence_score", {})

        duration = _time.time() - start_time
        _print_output(user_query, sql_query, "", pd.DataFrame(), confidence, trace, executed=False)

        return {
            "data": sql_query,
            "summary": "Execution skipped.",
            "sql": sql_query,
            "trace": trace,
            "confidence": confidence,
            "intent": intent,
        }

    result = genie_supervisor.invoke(initial_state)

    sql_query = result.get("final_sql", result.get("generated_sql", ""))
    trace = result.get("trace", [])
    confidence = result.get("confidence_score", {})
    insights = result.get("insights", "")
    exec_result = result.get("execution_result", {})
    result_df = exec_result.get("df", pd.DataFrame())
    if result_df is None:
        result_df = pd.DataFrame()

    duration = _time.time() - start_time
    _print_output(user_query, sql_query, insights, result_df, confidence, trace, executed=True)

    # Cache successful results
    output = {
        "data": result_df,
        "summary": insights,
        "sql": sql_query,
        "trace": trace,
        "confidence": confidence,
        "intent": intent,
    }
    
    if isinstance(result_df, pd.DataFrame) and not result_df.empty:
        query_cache.put(user_query, output)
        if verbose:
            print(f"  {query_cache.stats()}")

    return output

def _print_output(user_query, sql, insights, df, confidence, trace, executed=True):
    """Pretty-print the pipeline output."""
    print(f"\n{'=' * 40}")
    print("  GENERATED SQL")
    print(f"{'=' * 40}")
    print(sql)
    print()

    if confidence:
        conf_val = confidence.get("confidence", "?")
        print(f"  Confidence: {conf_val}/10")
        if confidence.get("concerns"):
            print(f"  Concerns: {', '.join(confidence['concerns'][:3])}")
        print()

    if executed:
        if isinstance(df, pd.DataFrame) and not df.empty:
            print(f"{'=' * 40}")
            print(f"  RESULTS ({len(df)} rows)")
            print(f"{'=' * 40}")
            try:
                print(df)
            except NameError:
                print(df.to_string(index=False, max_rows=30))

        if insights:
            print(f"\n{'=' * 40}")
            print("  BUSINESS INSIGHTS")
            print(f"{'=' * 40}")
            print(insights)
    else:
        print("  (Execution skipped  -  set execute=True to run)")

    print(f"\n{'=' * 40}")
    print(f"  AGENT TRACE ({len(trace)} steps)")
    print(f"{'=' * 40}")
    print(tc.format_trace(trace))

print("=" * 60)
print("  Cost Genie  -  Enhanced Multi-Agent Pipeline Ready!")
print("=" * 60)
print()
print("    [OK] Inline translation (translate columns within SQL queries)")
print("    [OK] Query pre-processor (strips non-SQL instructions)")
print("    [OK] Scope guard (non-finance queries handled gracefully)")
print("    [OK] Fuzzy column matching for translation targets")
print("    [OK] Intent routing (SQL / Translate / Explain / General / Out-of-Scope)")
print("    [OK] Query response cache")
print("    [OK] MSAL token caching")
print()
print("  Usage:")
print("    # SQL query with inline translation:")
print('    result = ask_cost_genie("Summarize SAP recon for XXX... Translate the text column from Italian to English")')
print()
print("    # Standalone translation of previous results:")
print("    result = ask_cost_genie('translate the results', previous_df=result['data'])")
print()
print("    # Term explanation / General / Out-of-scope:")
print("    ask_cost_genie('what is AOP?')")
print("    ask_cost_genie('hello')")
print("    ask_cost_genie('what is the weather today?')  # scope guard")



if __name__=="__main__":
    print(ask_cost_genie(user_query="how are you"))