from enum import Enum
import re
from app.cost_genie_api.schema.domain_knowledge import DOMAIN_KNOWLEDGE
from app.cost_genie_api.state.supervisor_state import QueryIntent

def detect_query_pattern(query: str) -> str:
    """Detect query pattern: A=simple, B=totals, C=top-N+totals, D=drill-down, E=multi-measure."""
    q = query.lower()
    if any(kw in q for kw in ["from the result", "drill", "causing", "driving"]):
        return "D"
    if re.search(r"top\s+\d+", q) and any(kw in q for kw in ["total", "summarize"]):
        return "C"
    if any(k in q for k in ["fte and", "and salaries", "and s&w", "and fte"]):
        return "E"
    if any(kw in q for kw in ["total", "totals", "summarize", "summary", "overall"]):
        return "B"
    return "A"


def extract_email_from_query(query: str) -> str:
    """Extract email address from user query for RLS filtering."""
    match = re.search(r'[\w.+-]+@[\w.-]+\.\w+', query)
    return match.group(0) if match else ""


def expand_abbreviations(query: str) -> str:
    """Expand known abbreviations to full Philips terminology."""
    expanded = query
    for abbrev, full in DOMAIN_KNOWLEDGE["abbreviation_expansions"].items():
        pattern = re.compile(re.escape(abbrev), re.IGNORECASE)
        expanded = pattern.sub(full, expanded)
    return expanded


def identify_fact_table(query: str) -> str:
    """Identify the primary fact table from query content."""
    q = query.lower()
    if any(kw in q for kw in ["fte", "head count", "hc", "headcount"]):
        return "cat_blueprint_prevspostalloc"
    if any(kw in q for kw in ["pps recon", "pps_recon", "pps amount"]):
        return "pps"
    if any(kw in q for kw in ["sap recon", "sap_recon", "sap amount"]):
        return "pps_sap"
    if any(kw in q for kw in ["adap", "adaptable"]):
        return "adap_act"
    return "cat_fpl_prevspostalloc"



# ======================================================================
# ENHANCED INTENT CLASSIFIER  -  Scope Guard + Inline Detection
# ======================================================================

# Finance-domain signal words  -  if query contains these, it's likely a SQL query
_FINANCE_SIGNALS = {
    "cost", "variance", "budget", "aop", "forecast", "fc", "fte", "head count",
    "headcount", "s&w", "salaries", "wages", "travel", "fiscal", "period",
    "oru", "mru", "mag", "bug", "bugroup", "company code", "cocode",
    "cost center", "costcenter", "cost agility", "functional area",
    "summarize", "total", "top ", "drill", "recon", "sap recon", "pps",
    "adap", "igm", "ism", "ebita", "euraop", "postactuals", "posttarget",
    "calendar_year", "fiscalperiodid", "rls", "security", "email",
    "account", "gl account", "document reference", "amount",
}

def _has_finance_signals(query_lower: str) -> bool:
    """Check if query contains Philips finance domain signals."""
    return any(sig in query_lower for sig in _FINANCE_SIGNALS)

def _has_inline_translation(query_lower: str) -> bool:
    """Check if query has embedded translation instructions (not standalone)."""
    translate_patterns = [
        r'translate\s+(?:the\s+)?\w+\s+(?:column\s+)?from\s+\w+\s+to\s+\w+',
        r'translate\s+(?:all\s+)?(?:the\s+)?(?:text|results?|data|columns?)\s+(?:to|into)\s+\w+',
        r'convert\s+(?:the\s+)?\w+\s+(?:column\s+)?(?:to|into)\s+english',
    ]
    return any(re.search(p, query_lower) for p in translate_patterns)


def classify_intent(query: str) -> str:
    """
    Enhanced intent classifier with scope guard and inline detection.
    
    When "translate" appears inside a larger data query
    (with finance signals), we classify as SQL_QUERY and let the pre-processor
    extract the translation as an inline instruction. Only standalone translation
    requests (no finance signals) route to TRANSLATE_RESULTS.
    
    New: OUT_OF_SCOPE intent for generic non-finance questions.
    """
    q = query.lower().strip()
    
    # -- General chat (greetings, capabilities, help) --
    general_patterns = [
        "hello", "hi ", "hey ", "good morning", "good afternoon", "how are you",
        "what can you do", "help me", "who are you", "thank", "thanks",
        "capabilities", "what queries", "how to use",
    ]
    if any(q.startswith(pat) or q == pat.strip() for pat in general_patterns):
        return QueryIntent.GENERAL_CHAT.value
    
    # -- Check for finance domain signals --
    has_finance = _has_finance_signals(q)
    has_translate = _has_inline_translation(q)
    
    # -- Translation inside a SQL query -> stays SQL_QUERY --
    # The pre-processor will extract the translation instruction
    if has_translate and has_finance:
        return QueryIntent.SQL_QUERY.value
    
    # -- Standalone translation request (no finance signals) --
    standalone_translate = [
        "translate the result", "translate the data", "translate results",
        "translate df", "translate dataframe", "convert to english",
        "english translation", "translate the output",
    ]
    if any(pat in q for pat in standalone_translate):
        return QueryIntent.TRANSLATE_RESULTS.value
    
    # -- Term explanation (short question about a term, not a data query) --
    explain_patterns = [
        "what is ", "what are ", "what does ", "define ", "explain ",
        "meaning of ", "what do you mean by ",
    ]
    if any(q.startswith(pat) for pat in explain_patterns):
        data_indicators = [
            "total", "variance", "cost for", "period", "fiscal", "by ",
            "summarize", "provide", "top ", "between", "for ",
        ]
        if not any(di in q for di in data_indicators):
            return QueryIntent.EXPLAIN_TERM.value
    
    # -- Finance query (has domain signals) -> SQL pipeline --
    if has_finance:
        return QueryIntent.SQL_QUERY.value
    
    # -- Scope guard: Non-finance, non-greeting, non-explanation --
    # If query doesn't match any known pattern, check if it's just a vague
    # question that might still be about data
    vague_data_hints = [
        "show", "list", "give me", "find", "get", "pull", "what is the",
        "how much", "how many", "compare", "breakdown", "split",
    ]
    if any(q.startswith(hint) or hint in q for hint in vague_data_hints):
        return QueryIntent.SQL_QUERY.value
    
    # -- OUT_OF_SCOPE: Genuinely non-finance questions --
    return QueryIntent.OUT_OF_SCOPE.value



def handle_out_of_scope(query: str) -> str:
    """Handle non-finance questions with a polite scope-limited response."""
    return (
        "I appreciate the question, but I'm currently focused on Philips FinanceBI cost data analysis. "
        "I can help you with:\n\n"
        "  - **Cost & Variance Analysis**  -  CY vs AOP, Forecast, Last Year comparisons\n"
        "  - **FTE & Headcount**  -  Full-time equivalent data across business units\n"
        "  - **Drill-Down Analysis**  -  Find root causes of variances by MRU, ORU, Cost Center\n"
        "  - **SAP/PPS Reconciliation**  -  Query payroll and SAP recon data\n"
        "  - **Multi-Period Comparisons**  -  YTD, QTD, month-over-month analysis\n"
        "  - **Finance Terminology**  -  Explain abbreviations like AOP, EURAOP, S&W, etc.\n\n"
        "Try asking something like:\n"
        '  "Summarize Travel variance between CY & AOP for 2025011 YTD by MRU L5"\n'
        '  "What is the total FTE for BUGroup IGT for 2026001?"\n'
        '  "What is AOP?"'
    )
