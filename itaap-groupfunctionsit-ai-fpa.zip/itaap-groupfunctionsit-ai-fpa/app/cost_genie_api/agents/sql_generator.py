from app.cost_genie_api.state.supervisor_state import SupervisorState
from app.cost_genie_api.config.agent_registry import get_agent_config,get_agent_system_prompt,get_agent_llm
from app.cost_genie_api.state.trace import tc
from app.cost_genie_api.prompts.sql_prompt import _build_sql_prompt
from app.cost_genie_api.state.handoff import Handoff
from langchain_core.messages import HumanMessage,SystemMessage
import json
import re


def _extract_sql_from_response(text: str) -> tuple:
    """Extract SQL and analysis text from LLM response."""
    analysis_text = ""
    sql = text.strip()

    analysis_match = re.search(r'Analysis:\s*(.*?)(?=SQL:|```)', text, re.DOTALL | re.IGNORECASE)
    if analysis_match:
        analysis_text = analysis_match.group(1).strip()

    sql_match = re.search(r'```(?:sql)?\s*(.*?)```', text, re.DOTALL)
    if sql_match:
        sql = sql_match.group(1).strip()
    else:
        sql_match = re.search(r'SQL:\s*(.*)', text, re.DOTALL | re.IGNORECASE)
        if sql_match:
            sql = sql_match.group(1).strip()

    sql = sql.rstrip(';').strip()
    return analysis_text, sql


print("SQL prompt builder and response parser defined (uses clean_query).")

def sql_agent(state: SupervisorState) -> dict:
    """SQL Agent: pattern-aligned SQL generation with semantic retrieval and self-repair."""
    cfg = get_agent_config("sql")
    trace = list(state.get("trace", []))
    v = state.get("verbose", True)
    agent = cfg["role"].value

    retry_count = state.get("sql_retry_count", 0)
    retry_errors = state.get("validation_result", {}).get("issues", []) if retry_count > 0 else []
    exec_result = state.get("execution_result", {})
    exec_error = exec_result.get("error", "") if retry_count > 0 or exec_result.get("error") else ""
    recovery_mode = state.get("recovery_mode", "normal")

    if v:
        print(f"\n{'-' * 50}")
        mode_label = f" [{recovery_mode.upper()}]" if recovery_mode != "normal" else ""
        print(f"  SQL AGENT  -  Generating SQL (attempt {retry_count + 1}){mode_label}")
        print(f"{'-' * 50}")

    trace = tc.event(trace, "SQL_START", f"SQL attempt {retry_count + 1}, mode={recovery_mode}", agent)

    step_desc = ""
    plan = state.get("execution_plan", [])
    step_idx = state.get("current_step_idx", 0)
    if plan and step_idx < len(plan):
        step_desc = plan[step_idx].get("description", "")

    prompt, few_shot_text = _build_sql_prompt(
        state, retry_errors=retry_errors, exec_error=exec_error, step_desc=step_desc,
    )

    trace = tc.event(trace, "SQL_LLM_CALL", f"Invoking LLM ({len(prompt)} chars)", agent)

    sql_system = get_agent_system_prompt("sql")
    messages = [SystemMessage(content=sql_system), HumanMessage(content=prompt)]
    response = get_agent_llm("sql").invoke(messages)
    analysis_text, sql = _extract_sql_from_response(response.content)

    trace = tc.event(trace, "SQL_GENERATED", f"SQL produced ({len(sql)} chars)", agent)

    if v:
        print(f"  Generated {len(sql)} chars of SQL")

    handoff = Handoff.sql_to_validation(sql, analysis_text, few_shot_text)
    trace = tc.handoff(trace, "sql", "validation", list(handoff.keys()))

    return {**handoff, "trace": trace}


print("SQL Agent defined (pattern-aligned prompts, abbreviation expansion, enhanced reminders).")


