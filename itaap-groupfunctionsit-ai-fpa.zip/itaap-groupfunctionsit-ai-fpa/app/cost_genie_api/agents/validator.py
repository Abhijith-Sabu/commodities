from app.cost_genie_api.state.supervisor_state import SupervisorState
from app.cost_genie_api.config.agent_registry import get_agent_config,get_agent_llm,get_agent_system_prompt,AGENT_CONFIG
from app.cost_genie_api.state.trace import tc
from langchain_core.messages import HumanMessage,SystemMessage
from app.cost_genie_api.state.handoff import Handoff
import json
import re
import pandas as pd



def score_confidence(user_query: str, sql: str, analysis_text: str = "") -> dict:
    """LLM-based confidence scoring of generated SQL with robust error handling."""
    prompt = f"""Score this SQL query's correctness 1-10 for the given question.

Question: {user_query}

SQL:
{sql}

{f'Analysis: {analysis_text}' if analysis_text else ''}

IMPORTANT: Return ONLY valid JSON, no other text:
{{"confidence": N, "concerns": ["issue1", "issue2"], "suggestion": "fix description"}}"""

    try:
        val_sys = get_agent_system_prompt("validation")
        response = get_agent_llm("validation").invoke([
            SystemMessage(content=val_sys),
            HumanMessage(content=prompt),
        ])
        text = response.content

        json_match = re.search(r'\{[\s\S]*\}', text)
        if json_match:
            parsed = json.loads(json_match.group())
            conf = parsed.get("confidence", 7)
            if not isinstance(conf, (int, float)) or conf < 1 or conf > 10:
                conf = 7
            return {
                "confidence": conf,
                "concerns": parsed.get("concerns", []),
                "suggestion": parsed.get("suggestion", ""),
            }
        else:
            return {"confidence": 7, "concerns": ["Could not parse LLM confidence response"], "suggestion": ""}

    except json.JSONDecodeError:
        return {"confidence": 6, "concerns": ["JSON parse error in confidence scoring"], "suggestion": "Review SQL manually"}
    except Exception as e:
        return {"confidence": 5, "concerns": [f"Confidence scoring error: {str(e)[:100]}"], "suggestion": "Review SQL manually"}


def validate_sql(sql: str, user_query: str) -> dict:
    """Static validation of generated SQL against known schema rules."""
    issues = []
    sql_upper = sql.upper()
    sql_lower = sql.lower()

    if not sql.strip():
        return {"is_valid": False, "issues": ["Empty SQL query"]}

    if "cat_fpl_prevspostalloc_hackathon" in sql_lower:
        issues.append("WRONG TABLE: Use cat_fpl_prevspostalloc (not cat_fpl_prevspostalloc_hackathon)")

    if "calendar_year" in sql_lower and "dim_cat_date_fiscalperiod" in sql_lower:
        issues.append("NOTE: Use Year (not Calendar_Year) on dim_cat_date_fiscalperiod; Calendar_Year is for year filtering on fact table")

    if re.search(r'cost_agility_l\d', sql_lower):
        issues.append("WRONG COLUMN: Use CostAgility_L* (not Cost_Agility_L*)")

    if "bugroup_2025" in sql_lower:
        issues.append("WRONG COLUMN: Use BUGroup (not BUGroup_2025) on dim_cat_mru")

    if "mru_l5_2025" in sql_lower:
        issues.append("WRONG COLUMN: Use MRU_L5 (not MRU_L5_2025)")

    if "qa_wb.financebi." not in sql_lower and "financebi." not in sql_lower:
        issues.append("MISSING: Tables must be fully qualified with qa_wb.financebi. prefix")

    rls_needed = "email" in user_query.lower() or "security" in user_query.lower()
    if rls_needed and "dim_cat_security_oru" not in sql_lower:
        issues.append("MISSING RLS: Query mentions email/security but dim_cat_security_oru not joined")
    if rls_needed and "cocodepk_security" not in sql_lower:
        issues.append("WRONG RLS JOIN: Must use CoCodePK_Security (not CoCodePK) for security join")

    if re.search(r"\bLIKE\b", sql_upper) and "ILIKE" not in sql_upper:
        issues.append("USE ILIKE: String comparisons should use ILIKE with % wildcards")

    my_cc = "my cost center" in user_query.lower() or "my costcenter" in user_query.lower()
    if my_cc and "dim_pflt_cc_mapping" not in sql_lower:
        issues.append("MISSING: 'my Cost Center' requires joining dim_pflt_cc_mapping to filter by user email (PFLT_Email)")
    if not my_cc and "dim_pflt_cc_mapping" in sql_lower:
        issues.append("UNNECESSARY: dim_pflt_cc_mapping should only be joined when 'my Cost Center' is mentioned")

    if any(kw in user_query.lower() for kw in ["igm"]) and "functionalarea" not in sql_lower:
        issues.append("MISSING IGM FILTER: IGM requires FunctionalArea IN (0, 1000)")
    if any(kw in user_query.lower() for kw in ["ism"]) and "functionalarea" not in sql_lower:
        issues.append("MISSING ISM FILTER: ISM requires FunctionalArea IN (0, 1000, 2000)")

    fte_keywords = any(kw in user_query.lower() for kw in ["fte", "head count", "headcount"])
    if fte_keywords and "cat_blueprint_prevspostalloc" not in sql_lower:
        if "cat_fpl_prevspostalloc" in sql_lower and "alloc_fte" not in sql_lower:
            issues.append("WRONG TABLE: FTE/HC data is in cat_blueprint_prevspostalloc, not cat_fpl_prevspostalloc")

    return {"is_valid": len(issues) == 0, "issues": issues}

def validation_agent(state: SupervisorState) -> dict:
    """Validation Agent: Phase 1 static checks + Phase 2 LLM confidence scoring."""
    cfg = get_agent_config("validation")
    trace = list(state.get("trace", []))
    v = state.get("verbose", True)
    agent = cfg["role"].value
    sql = state.get("generated_sql", "")
    threshold = cfg.get("confidence_threshold", 6)

    if v:
        print(f"\n{'-' * 60}")
        print(f"  {cfg['name']}  -  Quality gate (threshold: {threshold}/10)")
        print(f"{'-' * 60}")

    trace = tc.event(trace, "VALIDATE_START", "Phase 1: Static checks", agent)

    # Phase 1: Static validation
    val_result = validate_sql(sql, state["user_query"])

    if not val_result["is_valid"]:
        trace = tc.event(trace, "VALIDATE_STATIC_FAIL",
            f"{len(val_result['issues'])} static issues", agent, extra={"issues": val_result["issues"]})
        if v:
            print(f"  [FAIL] Static FAILED ({len(val_result['issues'])} issues)")
            for iss in val_result["issues"]:
                print(f"    - {iss[:120]}")
        handoff = Handoff.validation_to_supervisor(
            val_result, {"confidence": 0, "concerns": val_result["issues"], "suggestion": None}, False)
        trace = tc.handoff(trace, "validation", "supervisor", ["sql_approved=False"])
        return {**handoff, "trace": trace}

    trace = tc.event(trace, "VALIDATE_STATIC_PASS", "Static checks passed", agent)
    if v:
        print(f"  [OK] Static PASSED")

    # Phase 2: LLM confidence scoring
    trace = tc.event(trace, "VALIDATE_CONFIDENCE_START", "Phase 2: LLM confidence", agent)
    if v:
        print(f"  Running confidence check...")

    confidence = score_confidence(state["user_query"], sql, state.get("analysis_text", ""))
    conf_val = confidence.get("confidence", 7)

    trace = tc.event(trace, "VALIDATE_CONFIDENCE_RESULT", f"Confidence: {conf_val}/10", agent,
        extra={"confidence": conf_val, "concerns": confidence.get("concerns", [])})

    if v:
        print(f"  Confidence: {conf_val}/10")
        for c in confidence.get("concerns", []):
            print(f"    [!] {c}")

    approved = conf_val >= threshold
    if not approved:
        val_result["is_valid"] = False
        suggestion = confidence.get("suggestion") or "; ".join(confidence.get("concerns", []))
        val_result["issues"] = [f"LOW CONFIDENCE ({conf_val}/10): {suggestion}"]
        trace = tc.event(trace, "VALIDATE_REJECT", f"Rejected: {conf_val} < {threshold}", agent)
        if v:
            print(f"  [FAIL] REJECTED ({conf_val} < {threshold})")
    else:
        trace = tc.event(trace, "VALIDATE_APPROVED", f"APPROVED ({conf_val}/10)", agent)
        if v:
            print(f"  [OK] APPROVED")

    handoff = Handoff.validation_to_supervisor(val_result, confidence, approved)
    trace = tc.handoff(trace, "validation", "supervisor", [f"sql_approved={approved}"])
    return {**handoff, "trace": trace}


print(f"Validation Agent defined (threshold: {AGENT_CONFIG['validation']['confidence_threshold']}).")
