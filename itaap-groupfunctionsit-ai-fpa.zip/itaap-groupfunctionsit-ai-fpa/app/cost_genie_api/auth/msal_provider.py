import threading
from typing import Optional
from msal import ConfidentialClientApplication
from app.cost_genie_api.config.settings import settings

_msal_app: Optional[ConfidentialClientApplication] = None
_msal_lock = threading.Lock()

def _get_msal_app() -> ConfidentialClientApplication:
    """
    Lazily initializes and returns a singleton MSAL ConfidentialClientApplication instance.
    Thread-safe.
    """
    global _msal_app
    with _msal_lock:
        if _msal_app is None:
            _msal_app = ConfidentialClientApplication(
                client_id=settings.FPA_PROD_SPN_CLIENTID,
                client_credential=settings.FPA_PROD_SPN_SECRET,
                authority=f"https://login.microsoftonline.com/{settings.FPA_PROD_SPN_TENANT_ID}"
            )
        return _msal_app

def get_token() -> str:
    """
    Acquires an Azure AD access token using MSAL.
    Attempts silent acquisition first, then falls back to client credentials.
    Returns:
        str: Access token string.
    Raises:
        RuntimeError: If token acquisition fails.
    """
    app = _get_msal_app()
    scopes = [settings.FPA_AZURE_OPENAI_SCOPE]
    result = app.acquire_token_silent(scopes, account=None)
    if not result:
        result = app.acquire_token_for_client(scopes=scopes)
    access_token = result.get("access_token")
    if access_token:
        return access_token
    error_desc = result.get("error_description") or str(result)
    raise RuntimeError(f"MSAL token acquisition failed: {error_desc}")
