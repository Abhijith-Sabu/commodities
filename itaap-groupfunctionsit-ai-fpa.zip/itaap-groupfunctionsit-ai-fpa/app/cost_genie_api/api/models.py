from typing import Optional, List, Dict
from pydantic import BaseModel

class QueryRequest(BaseModel):
    query: str
    execute: bool = True
    verbose: bool = False
    previous_df :Optional[list[Dict]] =None

class TraceStep(BaseModel):
    ts: str
    event: str
    agent: str
    detail: str
    extra: Optional[dict] = None

class ConfidenceInfo(BaseModel):
    score: int
    concerns: List[str]

class QueryResponse(BaseModel):
    intent: str
    sql: Optional[str] = None
    data: Optional[List[Dict]] = None
    summary: str
    confidence: Optional[dict]
    trace: List[TraceStep] = []


class HealthResponse(BaseModel):
    status: str
    token_available: bool


class SchemaTableInfo(BaseModel):
    table_name: str
    description: str
    column_count: int
    aliases: List[str]

class SchemaResponse(BaseModel):
    tables: List[SchemaTableInfo]
    total_tables: int
