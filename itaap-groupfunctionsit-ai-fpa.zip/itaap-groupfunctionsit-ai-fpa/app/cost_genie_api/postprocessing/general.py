from app.cost_genie_api.config.agent_registry import get_agent_system_prompt

def handle_general_query(query: str) -> str:
    """Handle general/chat queries about system capabilities."""
    capabilities = """Cost Genie can help you with:

**Data Queries**  -  Ask about costs, variances, FTE, S&W, travel expenses, etc.
  Example: "Summarize Travel variance between CY & AOP for 2025011 YTD by MRU L5"

**Multi-Measure Analysis**  -  Compare FTE and costs side by side
  Example: "Provide FTE and Salaries and Wages variance between CY & AOP for 2026001"

**Drill-Down Analysis**  -  Find root causes of variances
  Example: "Find the MRU L5 with highest variance and show cost centers causing it"

**PPS/SAP Reconciliation**  -  Query payroll and SAP data
  Example: "Summarize SAP recon amount for IT90 company code for GL Account 6101000"

**Inline Translation**  -  Translate specific columns directly in your query
  Example: "...Translate the text column from Italian to English"

**Terminology**  -  Explain finance abbreviations and terms
  Example: "What is AOP?" or "Define EURAOP"

Tip: Include specifics like fiscal period, MRU/ORU level, and email for best results."""
    
    q_lower = query.lower()
    if any(g in q_lower for g in ["hello", "hi ", "hey ", "good morning", "good afternoon"]):
        return f"Hello! I'm Cost Genie, your Philips FinanceBI assistant.\n\n{capabilities}"
    if "thank" in q_lower:
        return "You're welcome! Let me know if you need anything else."
    
    return capabilities


print(f"Insight Agent defined (system prompt: {len(get_agent_system_prompt('insight')):,} chars).")
print("  [OK] Inline Translation Agent defined (translate_column, translate_all)")
print("  [OK] Column matcher (_match_column_hint) for fuzzy column name matching")
print("  [OK] PostProcessor handlers (translate, explain, general, out-of-scope)")