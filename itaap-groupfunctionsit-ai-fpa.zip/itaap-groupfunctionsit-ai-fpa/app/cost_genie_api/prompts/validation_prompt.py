# Validation/confidence scoring system prompt string and functions migrated verbatim from notebook
import re
import json
from app.cost_genie_api.prompts.sql_prompt import SCHEMA_BLOCK,_col_rules
from langchain_core.messages import SystemMessage, HumanMessage


VALIDATION_SYSTEM_PROMPT = f"""You are the Validation Agent for Cost Genie v5. Your job is to score SQL correctness on a scale of 1-10.

SCHEMA:
{SCHEMA_BLOCK}

COLUMN RULES:
{_col_rules}

VALIDATION CHECKLIST (check each item):
1. Table names: All fully qualified with qa_wb.financebi. prefix
2. Column names: CostAgility_L* (not Cost_Agility_L*), Year (not Calendar_Year), BUGroup (not BUGroup_2025), MRU_L5 (not MRU_L5_2025)
3. Join keys: Acct_PK = Acct_pk for dim_cat_account_fpl, CoCodePK_Security for security joins
4. String filters: ILIKE with % wildcards (never = for dimension values)
5. Aggregations: COALESCE before SUM  -  SUM(COALESCE(col, 0))
6. Division: try_divide() used for all division operations
7. RLS: If email in query, security join and filter present
8. Variance: For Sales CostAgility: AOP - CY; For other CostAgilities: CY - AOP
9. FORMAT_NUMBER: Only in final SELECT, only if user requested
10. GROUP BY: All non-aggregated columns included
11. Fact table: Correct table for data type (FTE -> blueprint, PPS -> pps, SAP -> pps_sap, ADAP -> adap_act)
12. FiscalPeriodID: Treated as STRING type
13. LEFT JOIN: Used for dimension tables to prevent data loss
14. FTE: Must come from cat_blueprint_prevspostalloc, not cat_fpl_prevspostalloc
15. FTE: No S&W filter or CostAgility filter applied when aggregating FTE
16. IGM: FunctionalArea IN (0, 1000); ISM: FunctionalArea IN (0, 1000, 2000)
17. MAG_Description used in SELECT for MAG data; ORU_Description for ORU data
18. dim_pflt_cc_mapping: Only joined when "my Cost Center" is mentioned
19. Scale to k for amounts (not FTE); ROUND and remove decimals

SCORING GUIDE:
- 10: Perfect SQL, all checks pass
- 8-9: Minor style issues but functionally correct
- 6-7: Works but has potential issues (missing COALESCE, suboptimal joins)
- 4-5: Likely produces wrong results (wrong table, wrong measure)
- 1-3: Will fail to execute (syntax errors, wrong column names)

You MUST output valid JSON only (no markdown, no explanation outside JSON):
{{{{"confidence": 8, "concerns": ["Minor: missing COALESCE on one column"], "suggestion": "Add COALESCE wrapper"}}}}"""

INSIGHT_SYSTEM_PROMPT = """You are the Insight Agent for Cost Genie -  a senior Philips finance analyst.

Your role: Generate executive-level business analysis from SQL query results for Philips FinanceBI.

ANALYSIS STRUCTURE:
1. KEY FINDINGS: Top 3-5 data points that directly answer the user's question
2. VARIANCES & OUTLIERS: Notable deviations from plan (AOP) or forecast (FC), highlight anything > 5%
3. TRENDS: Patterns across time periods, cost centers, or business units
4. BUSINESS IMPLICATIONS: What these numbers mean for Philips leadership decisions
5. RECOMMENDATIONS: Actionable next steps or areas requiring attention

FORMATTING RULES:
- Use bullet points for clarity
- Format currency: "12.3M EUR" or "1,234 kEUR"
- Format percentages: "+5.2% vs AOP" or "-3.1% YoY"
- Format FTE: "245.3 FTE"
- Reference specific dimension values (cost center names, BU groups) from the data
- Keep total response under 300 words
- Use Philips financial terminology: CY (Current Year), AOP (Annual Operating Plan), FC (Forecast), S&W (Salaries & Wages), O&S (Other Services)

IMPORTANT: Base your analysis ONLY on the data provided. Do not fabricate numbers or trends not visible in the results.
If any columns were translated from another language, reference the translated values in your analysis."""

INSIGHTS_PROMPT = """User Question: {user_query}

Query Results:
{results_text}

Based on the data above, provide executive-level business analysis following this structure:
1. KEY FINDINGS: What does the data show? (3-5 bullet points)
2. NOTABLE VARIANCES: Any significant deviations from plan or expected values?
3. ACTIONABLE INSIGHTS: What should leadership pay attention to?

Keep your analysis concise, data-driven, and focused on answering the user's original question."""

def validate_sql(sql: str, user_query: str) -> dict:
    """Static validation of generated SQL against known schema rules."""
    issues = []
    sql_upper = sql.upper()
    sql_lower = sql.lower()

    if not sql.strip():
        return {"is_valid": False, "issues": ["Empty SQL query"]}

    if "cat_fpl_prevspostalloc_hackathon" in sql_lower:
        issues.append("WRONG TABLE: Use cat_fpl_prevspostalloc (not cat_fpl_prevspostalloc_hackathon)")

    if "calendar_year" in sql_lower and "dim_cat_date_fiscalperiod" in sql_lower:
        issues.append("NOTE: Use Year (not Calendar_Year) on dim_cat_date_fiscalperiod; Calendar_Year is for year filtering on fact table")

    if re.search(r'cost_agility_l\d', sql_lower):
        issues.append("WRONG COLUMN: Use CostAgility_L* (not Cost_Agility_L*)")

    if "bugroup_2025" in sql_lower:
        issues.append("WRONG COLUMN: Use BUGroup (not BUGroup_2025) on dim_cat_mru")

    if "mru_l5_2025" in sql_lower:
        issues.append("WRONG COLUMN: Use MRU_L5 (not MRU_L5_2025)")

    if "qa_wb.financebi." not in sql_lower and "financebi." not in sql_lower:
        issues.append("MISSING: Tables must be fully qualified with qa_wb.financebi. prefix")

    rls_needed = "email" in user_query.lower() or "security" in user_query.lower()
    if rls_needed and "dim_cat_security_oru" not in sql_lower:
        issues.append("MISSING RLS: Query mentions email/security but dim_cat_security_oru not joined")
    if rls_needed and "cocodepk_security" not in sql_lower:
        issues.append("WRONG RLS JOIN: Must use CoCodePK_Security (not CoCodePK) for security join")

    if re.search(r"\bLIKE\b", sql_upper) and "ILIKE" not in sql_upper:
        issues.append("USE ILIKE: String comparisons should use ILIKE with % wildcards")

    my_cc = "my cost center" in user_query.lower() or "my costcenter" in user_query.lower()
    if my_cc and "dim_pflt_cc_mapping" not in sql_lower:
        issues.append("MISSING: 'my Cost Center' requires joining dim_pflt_cc_mapping to filter by user email (PFLT_Email)")
    if not my_cc and "dim_pflt_cc_mapping" in sql_lower:
        issues.append("UNNECESSARY: dim_pflt_cc_mapping should only be joined when 'my Cost Center' is mentioned")

    if any(kw in user_query.lower() for kw in ["igm"]) and "functionalarea" not in sql_lower:
        issues.append("MISSING IGM FILTER: IGM requires FunctionalArea IN (0, 1000)")
    if any(kw in user_query.lower() for kw in ["ism"]) and "functionalarea" not in sql_lower:
        issues.append("MISSING ISM FILTER: ISM requires FunctionalArea IN (0, 1000, 2000)")

    fte_keywords = any(kw in user_query.lower() for kw in ["fte", "head count", "headcount"])
    if fte_keywords and "cat_blueprint_prevspostalloc" not in sql_lower:
        if "cat_fpl_prevspostalloc" in sql_lower and "alloc_fte" not in sql_lower:
            issues.append("WRONG TABLE: FTE/HC data is in cat_blueprint_prevspostalloc, not cat_fpl_prevspostalloc")

    return {"is_valid": len(issues) == 0, "issues": issues}
def score_confidence(user_query: str, sql: str, analysis_text: str = "") -> dict:
    """LLM-based confidence scoring of generated SQL with robust error handling."""
    from app.cost_genie_api.config.agent_registry import get_agent_system_prompt, get_agent_llm
    
    prompt = f"""Score this SQL query's correctness 1-10 for the given question.

    Question: {user_query}

    SQL:
    {sql}

    {f'Analysis: {analysis_text}' if analysis_text else ''}

    IMPORTANT: Return ONLY valid JSON, no other text:
    {{"confidence": N, "concerns": ["issue1", "issue2"], "suggestion": "fix description"}}"""

    try:
        val_sys = get_agent_system_prompt("validation")
        response = get_agent_llm("validation").invoke([
            SystemMessage(content=val_sys),
            HumanMessage(content=prompt),
        ])
        text = response.content

        json_match = re.search(r'\{[\s\S]*\}', text)
        if json_match:
            parsed = json.loads(json_match.group())
            conf = parsed.get("confidence", 7)
            if not isinstance(conf, (int, float)) or conf < 1 or conf > 10:
                conf = 7
            return {
                "confidence": conf,
                "concerns": parsed.get("concerns", []),
                "suggestion": parsed.get("suggestion", ""),
            }
        else:
            return {"confidence": 7, "concerns": ["Could not parse LLM confidence response"], "suggestion": ""}

    except json.JSONDecodeError:
        return {"confidence": 6, "concerns": ["JSON parse error in confidence scoring"], "suggestion": "Review SQL manually"}
    except Exception as e:
        return {"confidence": 5, "concerns": [f"Confidence scoring error: {str(e)[:100]}"], "suggestion": "Review SQL manually"}
