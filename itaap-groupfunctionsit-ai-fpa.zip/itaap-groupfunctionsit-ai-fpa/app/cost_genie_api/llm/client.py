from langchain_openai import AzureChatOpenAI
from app.cost_genie_api.config.settings import AZURE_ENDPOINT, AZURE_ENDPOINT_MINI, settings
from app.cost_genie_api.auth.msal_provider import get_token

try:
    from langchain_core.tracers import langchain as _lc_tracers
    _lc_tracers.log = lambda *a, **kw: None
except Exception:
    pass

llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_version=settings.AZURE_OPENAI_API_VERSION,
    azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
    temperature=0,
    azure_ad_token_provider=get_token,
)

llm_creative = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_version=settings.AZURE_OPENAI_API_VERSION,
    azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
    temperature=0.3,
    azure_ad_token_provider=get_token,
)

llm_mini = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT_MINI,
    api_version=settings.AZURE_OPENAI_API_VERSION,
    azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT_MINI,
    temperature=0,
    azure_ad_token_provider=get_token,
)
