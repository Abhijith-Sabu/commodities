from app.cost_genie_api.state.supervisor_state import SupervisorState,ErrorCategory
from app.cost_genie_api.config.agent_registry import MAX_SQL_RETRIES,MAX_EXEC_RETRIES,MAX_EMPTY_RETRIES
import pandas as pd


def route_after_validation(state: SupervisorState) -> str:
    """Supervisor: after validation, execute or retry SQL."""
    if state.get("sql_approved", False):
        return "executor"
    if state.get("sql_retry_count", 0) >= MAX_SQL_RETRIES:
        return "executor"  # best-effort
    return "sql_retry"


def route_after_execution(state: SupervisorState) -> str:
    """Supervisor: after execution, decide next action (enhanced with empty recovery)."""
    exec_result = state.get("execution_result", {})
    error = exec_result.get("error", "")
    error_cat = exec_result.get("error_category", ErrorCategory.NONE)
    retries = exec_result.get("retries", 0)
    error_history = state.get("error_history", [])

    if error and retries < MAX_EXEC_RETRIES:
        return "exec_retry"

    if error_cat in (ErrorCategory.EMPTY_RESULT, ErrorCategory.SUSPICIOUS_DATA):
        empty_attempts = sum(1 for eh in error_history
                           if eh.get("error_category") in (
                               ErrorCategory.EMPTY_RESULT.value,
                               ErrorCategory.SUSPICIOUS_DATA.value,
                           ))
        if empty_attempts < MAX_EMPTY_RETRIES:
            return "empty_recovery"

    plan = state.get("execution_plan", [])
    step_idx = state.get("current_step_idx", 0)
    if plan and step_idx < len(plan) - 1:
        df = exec_result.get("df", pd.DataFrame())
        if df is not None and not df.empty:
            return "next_step"

    # Route to inline_translate instead of directly to insight
    return "inline_translate"
