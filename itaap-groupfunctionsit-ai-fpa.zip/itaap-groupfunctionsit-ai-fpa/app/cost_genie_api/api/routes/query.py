from fastapi import APIRouter, HTTPException
from app.cost_genie_api.api.models import QueryRequest, QueryResponse,HealthResponse
from app.cost_genie_api.cost_agent import ask_cost_genie
from app.cost_genie_api.auth.msal_provider import get_token
import logging

logger = logging.getLogger('cost_subagent.api')

router = APIRouter(prefix="/api/v1")

@router.post("/query", response_model=QueryResponse)
def query_endpoint(request: QueryRequest):

    try:

            result = ask_cost_genie(
                user_query=request.query,
                execute=request.execute,
                verbose=request.verbose,
                previous_df=request.previous_df
            )

            data = result['data'].to_dict(orient='records') if hasattr(result["data"], 'to_dict') else []
            return QueryResponse(
                sql=result['sql'],
                summary=result["summary"],
                trace=result['trace'],
                data=data,
                confidence=result['confidence'],
                intent=result['intent']
            )
    except Exception as e:
            logger.error(f"Error in /ask endpoint: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail="Internal server error. See logs.")



def token_health()->bool:
      try:
            token = get_token()
            return token is not None
      except Exception:
            return False
@router.post("/health", response_model=HealthResponse)
async def health():
    token_ok = token_health()

    return HealthResponse(
          status= "healthy" if token_ok else "degraded",
          token_available=token_ok
    )
          
