
from app.cost_genie_api.config.agent_registry import get_agent_config
from app.cost_genie_api.state.supervisor_state import SupervisorState,ErrorCategory
from app.cost_genie_api.config.settings import settings
from app.cost_genie_api.state.trace import tc
from app.cost_genie_api.auth.msal_provider import _get_msal_app
from typing import Optional,Dict,Any
import re
import pandas as pd
import requests
import numpy as np
import time
_session = requests.Session()


def get_token() -> str:
    """Acquire Databricks access token using client credentials."""
    app = _get_msal_app()

    # Use Databricks scope consistently.
    result = app.acquire_token_silent(scopes=[settings.DATABRICKS_SCOPE],account=None)
    if not result:
        result = app.acquire_token_for_client(scopes=[settings.DATABRICKS_SCOPE])

    token = result.get("access_token")
    if token:
        return token

    raise RuntimeError(f"Token acquisition failed: {result.get('error_description', 'Unknown')}")


def _dbx_base_url() -> str:
    # Prefer config if available; fallback preserves current behavior.
    host = getattr(settings, "DATABRICKS_SERVER_HOSTNAME", "adb-4503250765537851.11.azuredatabricks.net")
    return f"https://{host}"


def _headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {get_token()}",
        "Content-Type": "application/json",
    }


def _poll_statement(statement_id: str, timeout_seconds: int = 120, poll_interval: float = 1.0) -> Dict[str, Any]:
    """Poll statement until terminal state."""
    url = f"{_dbx_base_url()}/api/2.0/sql/statements/{statement_id}"
    deadline = time.time() + timeout_seconds

    while time.time() < deadline:
        resp = _session.get(url, headers=_headers(), timeout=30)
        resp.raise_for_status()
        body = resp.json()

        state = body.get("status", {}).get("state", "").upper()
        if state in {"SUCCEEDED", "FAILED", "CANCELED", "CLOSED"}:
            return body

        time.sleep(poll_interval)

    raise TimeoutError(f"Statement {statement_id} did not finish within {timeout_seconds}s")


def execute_query(sql_query: str) ->tuple:
    """Execute SQL query on Databricks SQL warehouse and return DataFrame."""
    url = f"{_dbx_base_url()}/api/2.0/sql/statements"
    payload = {
        "statement": sql_query,
        "warehouse_id": settings.DATABRICKS_WAREHOUSEID,
    }

    try:
        # Databricks SQL Statements API uses POST.
        resp = _session.post(
            url,
            headers=_headers(),
            json=payload,
            params={"wait_timeout": "30s", "on_wait_timeout": "CONTINUE"},
            timeout=60,
        )
        resp.raise_for_status()
        body = resp.json()

        # If async response, poll by statement_id.
        state = body.get("status", {}).get("state", "").upper()
        if state not in {"SUCCEEDED", "FAILED", "CANCELED", "CLOSED"}:
            statement_id = body.get("statement_id")
            if not statement_id:
                raise RuntimeError("No statement_id returned for async statement execution.")
            body = _poll_statement(statement_id)

        final_state = body.get("status", {}).get("state", "").upper()
        if final_state != "SUCCEEDED":
            message = body.get("status", {}).get("error", {}).get("message", "Unknown Databricks error")
            raise RuntimeError(f"Databricks query failed with state={final_state}: {message}")

        result = body.get("result", {})
        rows = result.get("data_array", [])
        columns_meta = body.get("manifest", {}).get("schema", {}).get("columns", [])
        columns = [c.get("name", f"col_{i}") for i, c in enumerate(columns_meta)]

        return pd.DataFrame(rows, columns=columns),""

    except Exception as e:

        return pd.DataFrame() ,e

def executor_agent(state: SupervisorState) -> dict:
    """Executor Agent: Runs SQL on Spark with error classification and result quality analysis."""
    cfg = get_agent_config("executor")
    trace = list(state.get("trace", []))
    v = state.get("verbose", True)
    agent = cfg["role"].value
    sql = state.get("generated_sql", state.get("final_sql", ""))

    if v:
        print(f"\n{'-' * 50}")
        print(f"  {cfg['name']}  -  Running SQL + quality analysis")
        print(f"{'-' * 50}")

    trace = tc.event(trace, "EXEC_START", f"Executing SQL ({len(sql)} chars)", agent)

    result_df, error = execute_query(sql)

    if error:
        error_cat, error_strategy = classify_spark_error(error)
        trace = tc.event(trace, "EXEC_ERROR_CLASSIFIED",
            f"Spark error [{error_cat.value}]: {error[:100]}", agent, {
            "error_category": error_cat.value, "error_strategy": error_strategy[:200]})
        if v:
            print(f"  [FAIL] SPARK ERROR [{error_cat.value}]")
            print(f"    {error[:200]}")
            print(f"    Strategy: {error_strategy[:120]}")
        return {
            "execution_result": {
                "error": error, "retries": state.get("execution_result", {}).get("retries", 0),
                "error_category": error_cat, "error_strategy": error_strategy, "quality_check": {},
            },
            "final_sql": sql, "trace": trace,
        }

    quality = check_result_quality(result_df, state["user_query"])
    row_count = len(result_df)

    if not quality["is_healthy"]:
        cat_label = quality["category"].value
        trace = tc.event(trace, "EXEC_QUALITY_ISSUE",
            f"Data quality issue [{cat_label}]: {quality['issues'][0][:100]}", agent, {
            "category": cat_label, "issues": quality["issues"], "row_count": row_count})
        if v:
            print(f"  [!] DATA QUALITY ISSUE [{cat_label}]")
            for iss in quality["issues"]:
                print(f"    - {iss[:120]}")
            for hint in quality.get("recovery_hints", []):
                print(f"    -> {hint}")
        return {
            "execution_result": {
                "error": "", "df": result_df,
                "data_summary": result_df.head(3).to_string(index=False) if not result_df.empty else "",
                "retries": state.get("execution_result", {}).get("retries", 0),
                "error_category": quality["category"], "error_strategy": "", "quality_check": quality,
            },
            "final_sql": sql, "trace": trace,
        }

    trace = tc.event(trace, "EXEC_SUCCESS", f"Returned {row_count} rows  -  quality checks passed", agent, {
        "row_count": row_count})
    data_summary = result_df.head(5).to_string(index=False) if not result_df.empty else ""
    if v:
        print(f"  [OK] {row_count} rows returned  -  all quality checks passed")

    return {
        "execution_result": {
            "error": "", "df": result_df, "data_summary": data_summary, "retries": 0,
            "error_category": ErrorCategory.NONE, "error_strategy": "", "quality_check": quality,
        },
        "final_sql": sql, "trace": trace,
    }


print("Executor Agent defined (error classification, quality checks, empty detection).")



def classify_spark_error(error: str) -> tuple:
    """Classify Spark execution errors into categories with fix strategies."""
    e = error.lower()
    patterns = [
        (ErrorCategory.TABLE_NOT_FOUND, ["table or view not found", "table not found"],
         "Check table name spelling and fully-qualified prefix qa_wb.financebi."),
        (ErrorCategory.COLUMN_NOT_FOUND, ["cannot resolve", "no such column", "column.*not found"],
         "Verify column exists in DATABASE_SCHEMA. Common: CostAgility not Cost_Agility, Year not Calendar_Year"),
        (ErrorCategory.AMBIGUOUS_COLUMN, ["ambiguous"],
         "Use table alias prefix (e.g., fpl.column_name)"),
        (ErrorCategory.JOIN_ERROR, ["join", "key.*not found"],
         "Verify join keys in JOIN_RELATIONSHIPS"),
        (ErrorCategory.SYNTAX_ERROR, ["syntax error", "parse", "mismatched input"],
         "Check SQL syntax: missing commas, unclosed quotes, wrong keywords"),
        (ErrorCategory.TYPE_MISMATCH, ["type mismatch", "cannot cast", "data type"],
         "Check data types: FiscalPeriodID is STRING, PK columns may be INT"),
        (ErrorCategory.PERMISSION_ERROR, ["permission", "access denied"],
         "Check table permissions and RLS configuration"),
        (ErrorCategory.TIMEOUT, ["timeout", "timed out"],
         "Simplify query: reduce joins, add more specific filters"),
    ]
    for cat, keywords, strategy in patterns:
        for kw in keywords:
            if re.search(kw, e):
                return cat, strategy
    return ErrorCategory.SYNTAX_ERROR, "General Spark error  -  review SQL syntax and schema"

def check_result_quality(df: pd.DataFrame, user_query: str) -> dict:
    """Check quality of query results."""
    if df is None or df.empty:
        return {
            "is_healthy": False,
            "category": ErrorCategory.EMPTY_RESULT,
            "issues": ["Query returned 0 rows  -  filters may be too restrictive"],
            "recovery_hints": [
                "Broaden ILIKE filters (remove extra % or simplify values)",
                "Check FiscalPeriodID format (should be string like '2025001')",
                "Verify dimension values exist in the data",
            ],
        }

    issues = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 0:
        numeric_data = df[numeric_cols]
        if (numeric_data == 0).all().all():
            issues.append("All numeric values are zero")
        if numeric_data.isnull().all().all():
            issues.append("All numeric values are NULL")

    if len(df) == 1 and "total" not in user_query.lower():
        issues.append(f"Only 1 row returned  -  expected multiple for GROUP BY query")

    if issues:
        return {
            "is_healthy": False,
            "category": ErrorCategory.SUSPICIOUS_DATA,
            "issues": issues,
            "recovery_hints": [
                "Check if COALESCE is applied before SUM",
                "Verify join conditions produce matching rows",
                "Check filter values match actual data",
            ],
        }

    return {"is_healthy": True, "category": ErrorCategory.NONE, "issues": [], "recovery_hints": []}


