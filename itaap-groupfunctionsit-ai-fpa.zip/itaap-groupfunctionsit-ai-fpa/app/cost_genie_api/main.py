from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.cost_genie_api.api.routes import query
# from app.cost_genie_api.api.middleware import setup_middleware
# from app.cost_genie_api.utils.logging_setup import configure_logging

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: warm up MSAL token and LLM clients
    # configure_logging()
    from app.cost_genie_api.auth.msal_provider import get_token
    from app.cost_genie_api.llm.client import llm, llm_mini, llm_creative
    from app.cost_genie_api.retrieval.hybrid_retriever import few_shot_retriever
    # Pre-warm token
    try:
        get_token()
        print("[startup] MSAL token acquired OK")
    except Exception as e:
        print(f"[startup] MSAL warning: {e}")
    # Pre-warm few-shot retriever (already built at import)
    print(f"[startup] Retriever ready: {len(few_shot_retriever.examples)} examples")
    yield
    # Shutdown: nothing to clean up

app = FastAPI(
    title="Cost Genie API",
    description="Multi-agent LLM pipeline for Philips FinanceBI cost analysis",
    version="1.0.0",
    lifespan=lifespan,
)

# setup_middleware(app)
app.include_router(query.router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.cost_genie_api.main:app", host="0.0.0.0", port=8000, reload=True)
