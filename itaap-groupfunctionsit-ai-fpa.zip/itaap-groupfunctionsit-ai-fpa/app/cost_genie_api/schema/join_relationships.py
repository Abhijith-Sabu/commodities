JOIN_RELATIONSHIPS = {
    "cat_fpl_prevspostalloc": {
        "dim_cat_costcenter":       {"fact_key": "CC_PK_IPL",      "dim_key": "CC_PK_IPL"},
        "dim_cat_account_fpl":      {"fact_key": "Acct_PK",        "dim_key": "Acct_PK"},
        "dim_cat_mru":              {"fact_key": "MAG_PK",         "dim_key": "MAG_PK"},
        "dim_cat_market":           {"fact_key": "CoCodePK",       "dim_key": "CoCodePK"},
        "dim_cat_functional_area":  {"fact_key": "FuncAreaPK",     "dim_key": "FuncAreaPK"},
        "dim_cat_date_fiscalperiod":{"fact_key": "FiscalPeriodID", "dim_key": "FiscalPeriodID"},
        "dim_cat_security_oru":     {"fact_key": "CoCodePK",       "dim_key": "CoCodePK_Security"},
        "dim_cat_efr_hierarchy":    {"fact_key": "FSI_Func_ID",    "dim_key": "EFR_FSItemID_FuncAreaID"},
    },
    "cat_blueprint_prevspostalloc": {
        "dim_cat_costcenter":       {"fact_key": "CC_PK_IPL",       "dim_key": "CC_PK_IPL"},
        "dim_cat_account_fpl":      {"fact_key": "Acct_PK",         "dim_key": "Acct_PK"},
        "dim_cat_mru":              {"fact_key": "MAG_PK",          "dim_key": "MAG_PK"},
        "dim_cat_market":           {"fact_key": "CoCodePK",        "dim_key": "CoCodePK"},
        "dim_cat_functional_area":  {"fact_key": "FuncAreaPK",      "dim_key": "FuncAreaPK"},
        "dim_cat_date_fiscalperiod":{"fact_key": "FiscalPeriodID",  "dim_key": "FiscalPeriodID"},
        "dim_cat_employee_master":  {"fact_key": "EmployeeMaskPK",  "dim_key": "EmployeeMaskPK"},
        "dim_cat_supervisory_org":  {"fact_key": "SO_ID",           "dim_key": "SO_ID"},
        "dim_cat_security_oru":     {"fact_key": "CoCodePK",        "dim_key": "CoCodePK_Security"},
    },
    "pps": {
        "dim_cat_costcenter":       {"fact_key": "CC_PK_IPL",              "dim_key": "CC_PK_IPL"},
        "dim_cat_account_fpl":      {"fact_key": "Acct_PK",               "dim_key": "Acct_PK"},
        "dim_cat_market":           {"fact_key": "CoCodePK",               "dim_key": "CoCodePK"},
        "dim_cat_security_oru":     {"fact_key": "CoCodePK",               "dim_key": "CoCodePK_Security"},
        "dim_cat_date_fiscalperiod":{"fact_key": "PPS_Recon_FiscalPeriodID","dim_key": "FiscalPeriodID"},
    },
    "pps_sap": {
        "dim_cat_costcenter":       {"fact_key": "CC_PK_IPL",              "dim_key": "CC_PK_IPL"},
        "dim_cat_account_fpl":      {"fact_key": "Acct_PK",               "dim_key": "Acct_PK"},
        "dim_cat_mru":              {"fact_key": "MAG_PK",                "dim_key": "MAG_PK"},
        "dim_cat_market":           {"fact_key": "CoCodePK",               "dim_key": "CoCodePK"},
        "dim_cat_date_fiscalperiod":{"fact_key": "SAP_Recon_FiscalPeriodID","dim_key": "FiscalPeriodID"},
        "dim_cat_security_oru":     {"fact_key": "CoCodePK",               "dim_key": "CoCodePK_Security"},
    },
    "adap_act": {
        "dim_cat_costcenter":       {"fact_key": "CC_PK_IPL",           "dim_key": "CC_PK_IPL"},
        "dim_cat_account_fpl":      {"fact_key": "Acct_PK",            "dim_key": "Acct_PK"},
        "dim_cat_mru":              {"fact_key": "MAG_PK",             "dim_key": "MAG_PK"},
        "dim_cat_market":           {"fact_key": "CoCodePK",            "dim_key": "CoCodePK"},
        "dim_cat_functional_area":  {"fact_key": "FuncAreaPK",         "dim_key": "FuncAreaPK"},
        "dim_cat_date_fiscalperiod":{"fact_key": "ADAP_FiscalPeriodID","dim_key": "FiscalPeriodID"},
        "dim_cat_security_oru":     {"fact_key": "CoCodePK",           "dim_key": "CoCodePK_Security"},
    },
}

DIM_PFLT_JOIN = {
    "dim_cat_costcenter -> dim_pflt_cc_mapping": {"left_key": "CC_PK_IPL", "right_key": "cc_pk_ipl"},
}

print(f"Join relationships defined for {len(JOIN_RELATIONSHIPS)} fact tables.")
for tbl, joins in JOIN_RELATIONSHIPS.items():
    print(f"  {tbl}: {len(joins)} dimension joins")
