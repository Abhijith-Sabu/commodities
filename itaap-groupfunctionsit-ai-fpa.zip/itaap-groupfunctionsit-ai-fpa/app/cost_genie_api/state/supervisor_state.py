from typing import TypedDict, List, Dict, Any
from enum import Enum

class ValidationResult(TypedDict, total=False):
    is_valid: bool
    error: str
    category: str
    confidence: int
    concerns: List[str]

class ExecutionResult(TypedDict, total=False):
    data: Any
    error: str
    row_count: int
    summary: str

class ExecutionStep(TypedDict, total=False):
    step: str
    result: Any
    error: str

class SupervisorState(TypedDict, total=False):
    user_query: str
    clean_query: str                  # Query with inline instructions stripped
    verbose: bool
    intent: str                       # QueryIntent value
    inline_instructions: list         #  List of InlineInstruction dicts
    analysis: dict
    execution_plan: list
    is_multi_step: bool
    generated_sql: str
    analysis_text: str
    few_shot_context: str
    sql_retry_count: int
    validation_result: dict
    confidence_score: dict
    sql_approved: bool
    execution_result: dict
    final_sql: str
    insights: str
    current_step_idx: int
    step_results: dict
    all_steps_complete: bool
    trace: list
    messages: list
    error_history: list
    recovery_mode: str
    translated_df: str                # Translated DataFrame text
    general_response: str             # For non-SQL responses


class ErrorCategory(Enum):
    NONE = "none"
    TABLE_NOT_FOUND = "table_not_found"
    COLUMN_NOT_FOUND = "column_not_found"
    AMBIGUOUS_COLUMN = "ambiguous_column"
    JOIN_ERROR = "join_error"
    SYNTAX_ERROR = "syntax_error"
    TYPE_MISMATCH = "type_mismatch"
    PERMISSION_ERROR = "permission_error"
    EMPTY_RESULT = "empty_result"
    SUSPICIOUS_DATA = "suspicious_data"
    TIMEOUT = "timeout"


class QueryIntent(Enum):
    """Classifies user intent to route queries appropriately."""
    SQL_QUERY = "sql_query"           # Needs SQL generation (default path)
    TRANSLATE_RESULTS = "translate"   # Translate DataFrame content to English (standalone)
    EXPLAIN_TERM = "explain_term"     # Explain a finance term / abbreviation
    GENERAL_CHAT = "general_chat"     # Greetings, small talk, non-finance
    OUT_OF_SCOPE = "out_of_scope"     # Non-finance questions outside Cost Genie's domain
    FOLLOW_UP = "follow_up"          # Follow-up on previous results
    DATA_EXPORT = "data_export"       # Export/format existing results
