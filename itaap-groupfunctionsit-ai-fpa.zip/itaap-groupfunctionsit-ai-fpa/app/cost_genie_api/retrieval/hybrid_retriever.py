from app.cost_genie_api.retrieval.few_shot_bank import FEW_SHOT_EXAMPLES
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

def _generate_tags(input_text, output_text):
    """Auto-generate tags for a few-shot example based on content."""
    tags = set()
    combined = (input_text + " " + output_text).lower()
    tag_patterns = {
        "variance": ["variance", "vs", "versus"],
        "totals": ["total", "totals", "include total", "add total"],
        "top_n": ["top 10", "top 5", "top 20", "highest", "biggest"],
        "format_number": ["format", "thousand separator", "formatted"],
        "rls": ["email", "security", "row level"],
        "ytd": ["ytd", "year to date"],
        "itm": ["itm", "in the month"],
        "mru": ["mru_l", "mru l"],
        "cost_center": ["cost center", "costcenter"],
        "pps": ["pps_recon", "pps recon", "pps amount"],
        "sap": ["sap_recon", "sap recon", "sap amount"],
        "fte": ["fte", "full time"],
        "sw": ["salaries", "s&w", "wages"],
        "nmc": ["nmc", "non-manufacturing"],
        "blueprint": ["blueprint", "cat_blueprint"],
        "travel": ["travel"],
        "sales": ["sales to thirds", "sales rel"],
        "drill_down": ["drill", "from the result", "highest.*show"],
        "multi_measure": ["fte and", "and salaries", "and s&w"],
        "functional_area": ["functional area", "fa_cc", "funcarea"],
        "cost_agility": ["cost agility", "costagility"],
        "oru": ["oru", "region", "north america"],
        "market": ["market", "company code", "cocode"],
        "account": ["gl account", "accountid", "fsi", "fsitem"],
        "adap": ["adap"],
    }
    for tag, keywords in tag_patterns.items():
        if any(kw in combined for kw in keywords):
            tags.add(tag)
    return list(tags)

for ex in FEW_SHOT_EXAMPLES:
    ex["tags"] = _generate_tags(ex["input"], ex["output"])

class HybridFewShotRetriever:
    """Hybrid retrieval: TF-IDF semantic similarity (70%) + keyword tag boost (30%)."""

    def __init__(self, examples: list, semantic_weight: float = 0.7, tag_weight: float = 0.3):
        self.examples = examples
        self.semantic_weight = semantic_weight
        self.tag_weight = tag_weight
        self.corpus = [ex["input"] for ex in examples]
        self.vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
        self.tfidf_matrix = self.vectorizer.fit_transform(self.corpus)
        print(f"  HybridRetriever initialized: {len(examples)} examples, {self.tfidf_matrix.shape[1]} features")

    def retrieve(self, query: str, top_k: int = 3) -> list:
        query_vec = self.vectorizer.transform([query])
        semantic_scores = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        query_tags = set(_generate_tags(query, ""))
        tag_scores = []
        for ex in self.examples:
            ex_tags = set(ex.get("tags", []))
            overlap = len(query_tags & ex_tags)
            total = max(len(query_tags | ex_tags), 1)
            tag_scores.append(overlap / total)
        tag_scores = np.array(tag_scores)
        combined = self.semantic_weight * semantic_scores + self.tag_weight * tag_scores
        top_indices = combined.argsort()[::-1][:top_k]
        return [self.examples[i] for i in top_indices if combined[i] > 0.05]


few_shot_retriever = HybridFewShotRetriever(FEW_SHOT_EXAMPLES)

def select_relevant_examples(query: str, top_k: int = 3) -> list:
    """Select most relevant few-shot examples for a query."""
    return few_shot_retriever.retrieve(query, top_k=top_k)

print(f"\nFew-shot bank: {len(FEW_SHOT_EXAMPLES)} examples loaded")
print(f"Hybrid retriever ready (semantic={few_shot_retriever.semantic_weight}, tags={few_shot_retriever.tag_weight})")
