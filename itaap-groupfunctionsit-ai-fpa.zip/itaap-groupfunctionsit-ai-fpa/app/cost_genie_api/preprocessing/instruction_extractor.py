from dataclasses import dataclass,field
from typing import List, Tuple
import re


@dataclass
class InlineInstruction:
    """Represents a non-SQL instruction extracted from a user query."""
    instruction_type: str          # "translate", "format", "sort", etc.
    raw_text: str                  # Original instruction text as found in query
    params: dict = field(default_factory=dict)  # Parsed parameters
    
    def __repr__(self):
        return f"InlineInstruction({self.instruction_type}, params={self.params})"

def extract_inline_instructions(query: str) -> tuple:
    """
    Extract non-SQL inline instructions from user query and return clean query.
    
    Handles patterns like:
      - "Translate the text column from Italian to English"
      - "Translate the [column_name] column from [source_lang] to [target_lang]"
      - "Convert the description to English"
      - "Translate all text to English"
    
    Returns:
        (clean_query: str, instructions: list[InlineInstruction])
    """
    instructions = []
    clean = query
    
    # Pattern 1: "Translate the <column> column from <lang> to <lang>"
    pat1 = re.compile(
        r'[.,;]?\s*[Tt]ranslate\s+(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:column\s+)?from\s+(\w+)\s+to\s+(\w+)\s*[.,;]?',
        re.IGNORECASE
    )
    for m in pat1.finditer(query):
        col_hint = m.group(1).strip()
        src_lang = m.group(2).strip()
        tgt_lang = m.group(3).strip()
        instructions.append(InlineInstruction(
            instruction_type="translate_column",
            raw_text=m.group(0).strip(' .,;'),
            params={"column_hint": col_hint, "source_lang": src_lang, "target_lang": tgt_lang}
        ))
        clean = clean.replace(m.group(0), ' ')
    
    # Pattern 2: "Translate all text to English" / "Translate results to English"
    pat2 = re.compile(
        r'[.,;]?\s*[Tt]ranslate\s+(?:all\s+)?(?:the\s+)?(?:text|results?|data|columns?)\s+(?:to|into)\s+(\w+)\s*[.,;]?',
        re.IGNORECASE
    )
    for m in pat2.finditer(query):
        # Don't double-count if already caught by pat1
        if m.group(0).strip(' .,;') not in [i.raw_text for i in instructions]:
            tgt_lang = m.group(1).strip()
            instructions.append(InlineInstruction(
                instruction_type="translate_all",
                raw_text=m.group(0).strip(' .,;'),
                params={"target_lang": tgt_lang}
            ))
            clean = clean.replace(m.group(0), ' ')
    
    # Pattern 3: "Convert <column> to English"
    pat3 = re.compile(
        r'[.,;]?\s*[Cc]onvert\s+(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:column\s+)?(?:to|into)\s+[Ee]nglish\s*[.,;]?',
        re.IGNORECASE
    )
    for m in pat3.finditer(query):
        col_hint = m.group(1).strip()
        if col_hint.lower() not in ('all', 'the', 'results', 'data'):
            instructions.append(InlineInstruction(
                instruction_type="translate_column",
                raw_text=m.group(0).strip(' .,;'),
                params={"column_hint": col_hint, "source_lang": "auto", "target_lang": "English"}
            ))
            clean = clean.replace(m.group(0), ' ')
    
    # Collapse multiple spaces
    clean = re.sub(r'\s{2,}', ' ', clean).strip()
    # Remove trailing punctuation artifacts
    clean = re.sub(r'\s*[.,;]\s*$', '', clean).strip()
    
    return clean, instructions
