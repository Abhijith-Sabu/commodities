import threading
import time as _time



def _trace(event_type: str, detail: str, agent: str, extra: dict = None) -> dict:
    return {
        "ts": _time.strftime("%H:%M:%S"),
        "event": event_type,
        "agent": agent,
        "detail": detail,
        **({"extra": extra} if extra else {}),
    }
class TraceCollector:
    def __init__(self):
        self.lock = threading.Lock()

    @staticmethod
    def event(trace, event_type, detail, agent, extra=None):
        trace.append(_trace(event_type, detail, agent, extra))
        return trace

    @staticmethod
    def handoff(trace, from_agent, to_agent, payload_keys):
        trace.append(_trace(
            "HANDOFF", f"{from_agent} -> {to_agent} [{', '.join(payload_keys[:5])}]", from_agent))
        return trace

    @staticmethod
    def format_trace(trace):
        lines = []
        for i, t in enumerate(trace, 1):
            lines.append(f"  {i:>3}. [{t['ts']}] {t['agent']:>12} | {t['event']:<30} | {t['detail'][:80]}")
        return "\n".join(lines)

tc = TraceCollector()


