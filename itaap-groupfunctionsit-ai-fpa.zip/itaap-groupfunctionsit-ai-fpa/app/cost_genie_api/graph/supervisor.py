from langgraph.graph import StateGraph,END
from app.cost_genie_api.state.supervisor_state import SupervisorState
from app.cost_genie_api.graph.router import route_after_execution,route_after_validation
from app.cost_genie_api.graph.nodes import sql_retry_node,exec_retry_node,empty_recovery_node,next_step_node
from app.cost_genie_api.agents.planner import planner_agent
from app.cost_genie_api.agents.validator import validation_agent
from app.cost_genie_api.agents.executor import executor_agent
from app.cost_genie_api.agents.translator import inline_translate_agent
from app.cost_genie_api.agents.insight import insight_agent
from app.cost_genie_api.agents.sql_generator import sql_agent



# === Build the Enhanced Supervisor Graph ===
supervisor_graph = StateGraph(SupervisorState)

supervisor_graph.add_node("planner",            planner_agent)
supervisor_graph.add_node("sql",                sql_agent)
supervisor_graph.add_node("validation",         validation_agent)
supervisor_graph.add_node("executor",           executor_agent)
supervisor_graph.add_node("inline_translate",   inline_translate_agent)   # NODE FOR TRANSLATE
supervisor_graph.add_node("insight",            insight_agent)
supervisor_graph.add_node("sql_retry",          sql_retry_node)
supervisor_graph.add_node("exec_retry",         exec_retry_node)
supervisor_graph.add_node("empty_recovery",     empty_recovery_node)
supervisor_graph.add_node("next_step",          next_step_node)

supervisor_graph.set_entry_point("planner")
supervisor_graph.add_edge("planner", "sql")
supervisor_graph.add_edge("sql", "validation")

supervisor_graph.add_conditional_edges(
    "validation",
    route_after_validation,
    {"executor": "executor", "sql_retry": "sql_retry"},
)
supervisor_graph.add_edge("sql_retry", "sql")

supervisor_graph.add_conditional_edges(
    "executor",
    route_after_execution,
    {
        "inline_translate": "inline_translate",   # reprioritized from "insight"
        "exec_retry": "exec_retry",
        "empty_recovery": "empty_recovery",
        "next_step": "next_step",
    },
)

supervisor_graph.add_edge("exec_retry", "sql")
supervisor_graph.add_edge("empty_recovery", "sql")
supervisor_graph.add_edge("next_step", "sql")
supervisor_graph.add_edge("inline_translate", "insight")   # translate -> insight
supervisor_graph.add_edge("insight", END)

# Compile with no checkpointer to avoid trace-fetch errors
genie_supervisor = supervisor_graph.compile(checkpointer=None)

print("=" * 60)
print("  ENHANCED MULTI-AGENT SUPERVISOR compiled")
print("=" * 60)
print()
print("  Flow:")
print("    PLANNER -> SQL -> VALIDATION --+-> EXECUTOR --+-> INLINE_TRANSLATE -> INSIGHT -> END")
print("                                    +-> SQL retry  |-> exec_retry -> SQL")
print("                                                   |-> empty_recovery -> SQL")
print("                                                   +-> next_step -> SQL")
print()
print("  NEW: inline_translate node between executor and insight")
print("  Error classification (10 catorieges)")
print("  Progressive fallback: normal -> broadened -> simplified")