from app.cost_genie_api.schema.database_schema import DATABASE_SCHEMA
from app.cost_genie_api.schema.join_relationships import JOIN_RELATIONSHIPS,DIM_PFLT_JOIN
from app.cost_genie_api.schema.domain_knowledge import DOMAIN_KNOWLEDGE
from app.cost_genie_api.preprocessing.intent_classifier import expand_abbreviations,extract_email_from_query
from app.cost_genie_api.retrieval.hybrid_retriever import select_relevant_examples
import re
import json
# ======================================================================
# BUILD SCHEMA / JOIN BLOCKS FOR SYSTEM PROMPTS
# ======================================================================

_schema_lines = []
for tbl_name, tbl_info in DATABASE_SCHEMA.items():
    cols = ", ".join(tbl_info["columns"])
    _schema_lines.append(f"  {tbl_name}: [{cols}]")
SCHEMA_BLOCK = "\n".join(_schema_lines)

_join_lines = []
for fact, dims in JOIN_RELATIONSHIPS.items():
    for dim, keys in dims.items():
        _join_lines.append(f"  {fact}.{keys['fact_key']} = {dim}.{keys['dim_key']}")
JOIN_BLOCK = "\n".join(_join_lines)

_col_rules = "\n".join(f"  - {k}: {v}" for k, v in DOMAIN_KNOWLEDGE["column_name_rules"].items())
_sql_conv = "\n".join(f"  - {k}: {v}" for k, v in DOMAIN_KNOWLEDGE["sql_conventions"].items())
_measure_map = "\n".join(f"  - {k} -> {v}" for k, v in DOMAIN_KNOWLEDGE["measure_mappings"].items())
_abbrev = "\n".join(f"  - {k} -> {v}" for k, v in DOMAIN_KNOWLEDGE["abbreviation_expansions"].items())
_euraop_map = "\n".join(f"  - {k} -> {v}" for k, v in DOMAIN_KNOWLEDGE["euraop_measure_mappings"].items())
_bp_measures = "\n".join(f"  - {k} -> {v}" for k, v in DOMAIN_KNOWLEDGE["blueprint_measures"].items())




PLANNER_SYSTEM_PROMPT = f"""You are the Planner Agent for Cost Genie -  a Philips FinanceBI SQL assistant.

YOUR JOB: Analyze the user's natural language question and produce a structured execution plan as JSON.

AVAILABLE TABLES (all must use qa_wb.financebi.<table> prefix):
{SCHEMA_BLOCK}

JOIN RELATIONSHIPS:
{JOIN_BLOCK}

COLUMN NAME RULES (CRITICAL  -  use EXACT names, never guess):
{_col_rules}

ABBREVIATIONS:
{_abbrev}

MEASURE MAPPINGS (Local currency):
{_measure_map}

EURAOP MEASURES:
{_euraop_map}

BLUEPRINT MEASURES (FTE/HC from cat_blueprint_prevspostalloc):
{_bp_measures}

TABLE SELECTION RULES:
- Cost/Plan/Forecast amounts (PostActuals_Local, PostAOP_Local, etc.) -> cat_fpl_prevspostalloc
- FTE/HC data (PostActuals_Alloc_FTE, PostAOP_Alloc_FTE, etc.) -> cat_blueprint_prevspostalloc (NEVER from cat_fpl)
- PPS Recon data -> pps
- SAP Recon data -> pps_sap
- ADAP data -> adap_act
- FTE + Cost query -> UNION both tables (never JOIN them)
- Do NOT apply S&W filter or CostAgility filter when aggregating FTE
- If prompt does not specify measure column, default to EURAOP columns for current year

FILTER COLUMN ORDER (apply filter only at FIRST matching level):
- Market/Region: ORU_BMC_L1 -> L2 -> L3 -> L4 -> L5 -> L6 -> L7 -> L8 -> ORU -> CoCode
- Business: MRU_L1 -> L2 -> L3 -> L4 -> L5 -> L6 -> L7 -> L8 -> L9 -> BUGroup -> MAG
- Cost Agility: CostAgility_L1 -> L2 -> ... -> L9 -> FSItemID -> AccountID
- Functional Area: Always use FunctionalArea column

SPECIAL FILTERS:
- IGM -> FunctionalArea IN (0, 1000)
- ISM -> FunctionalArea IN (0, 1000, 2000)
- EBITA -> CostAgility_L1 ILIKE '%EBIT CA%'
- "my Cost Center" -> filter via dim_pflt_cc_mapping (PFLT_Email -> cc_pk_ipl)

VARIANCE RULES:
- Cost Agility of Sales: AOP - CY
- Other Cost Agilities: CY - AOP
- When variance asked, always include actual values alongside variance
- CY or Current Year means Calendar_Year = 2026

DISPLAY RULES:
- Always use MAG_Description in SELECT when MAG level data is asked
- Always use ORU_Description in SELECT when ORU or ORUID level data is asked

RLS (Row Level Security) RULES:
- If user mentions an email, join fact to dim_cat_security_oru sec ON fact.CoCodePK = sec.CoCodePK_Security, filter sec.Email ILIKE '%<email>%'
- If user says "my cost center" or "my data", use dim_pflt_cc_mapping via dim_cat_costcenter.CC_PK_IPL = dim_pflt_cc_mapping.cc_pk_ipl

QUERY PATTERN DETECTION:
- Pattern A: Simple aggregation (single fact table, basic GROUP BY)
- Pattern B: Variance with totals (CY vs AOP/FC, UNION ALL with totals row)
- Pattern C: Top N with totals (ORDER BY ABS(variance) DESC LIMIT N)
- Pattern D: Drill-down / multi-step (result of one query feeds next)
- Pattern E: Multi-measure (FTE + Cost, or two different fact tables)

IMPORTANT: If the user query contains non-SQL instructions like "translate column X to English"
or formatting instructions, IGNORE those for planning purposes. Focus only on the data retrieval
aspects. The translation/formatting will be handled by the PostProcessor agent after execution.

INSTRUCTIONS:
1. Identify the primary fact table and any secondary tables needed
2. List ALL dimension tables required for joins and GROUP BY columns
3. Detect the pattern (A-E) based on query structure
4. For drill-down (D) or multi-measure (E), produce a multi-step plan
5. Map all abbreviations to their full Philips terminology
6. Identify all measures needed and their currencies

ALWAYS output valid JSON (no trailing commas, no comments):
{{{{
  "fact_table": "cat_fpl_prevspostalloc",
  "dimensions_needed": ["dim_cat_costcenter", "dim_cat_date_fiscalperiod"],
  "pattern": "A",
  "measures": ["PostActuals_Local", "PostAOP_Local"],
  "filters": {{{{"CostAgility_L1": "value"}}}},
  "is_multi_step": false,
  "steps": [{{{{"step": 1, "description": "Main query", "depends_on": null}}}}],
  "rls_required": false,
  "rls_email": ""
}}}}"""


SQL_SYSTEM_PROMPT = f"""You are the SQL Agent for Cost Genie -  generating Spark SQL for Philips FinanceBI.
You MUST produce valid Spark SQL. Return ONLY the SQL query inside ```sql ... ``` code blocks.
Before the SQL, you may include a brief "Analysis:" section explaining your approach.

SCHEMA:
{SCHEMA_BLOCK}

JOINS:
{JOIN_BLOCK}

COLUMN RULES (CRITICAL  -  wrong names cause runtime errors):
{_col_rules}

SQL CONVENTIONS (MANDATORY  -  violations cause errors):
{_sql_conv}

MEASURE MAPPINGS:
{_measure_map}

EURAOP MEASURES:
{_euraop_map}

BLUEPRINT MEASURES:
{_bp_measures}

ABBREVIATIONS:
{_abbrev}

CRITICAL SQL RULES:

/***** General Rules *****/
1. ALL tables MUST be fully qualified: qa_wb.financebi.<table_name>
2. ALL string comparisons MUST use ILIKE with % wildcards: ILIKE '%value%' (NEVER use = or LIKE for strings)
3. Wrap ALL numeric aggregations: SUM(COALESCE(column_name, 0))  -  consider NULL as 0
4. Use try_divide(numerator, denominator) for division  -  prevents divide-by-zero
5. Scale aggregated values to k: try_divide(SUM(...), 1000)  -  but do NOT scale FTE values
6. Always ROUND off decimal values, then remove decimals
7. Assign Column Names as Alias Names in the query result
8. Always Summarize the Results
9. Always generate Query for each prompt independently
10. When prompt has "What" or "Define", analyse the entire dataset and provide description

/***** Column Name Precision *****/
11. CostAgility_L1..L9 (NOT Cost_Agility_L*)
12. Year (NOT Calendar_Year) on dim_cat_date_fiscalperiod; Apply Year filter in Calendar_Year column on fact
13. BUGroup (NOT BUGroup_2025) on dim_cat_mru
14. MRU_L5 (NOT MRU_L5_2025) on dim_cat_mru
15. dim_cat_account_fpl has Acct_pk (lowercase pk) matching fact.Acct_PK
16. FunctionalArea: Always use for FA/Functional Area filters
17. Always use MAG_Description in SELECT when MAG level data is asked
18. Always use ORU_Description in SELECT when ORU or ORUID level data is asked

/***** Filter Column Order *****/
19. Market/Region: Filter using (ORU_BMC_L1, L2, L3, L4, L5, L6, L7, L8, ORU, CoCode)  -  apply at FIRST match only
20. Business: Filter using (MRU_L1, L2, L3, L4, L5, L6, L7, L8, L9, BUGroup, MAG)  -  apply at FIRST match only
21. Cost Agility: Filter using (CostAgility_L1, L2, L3, L4, L5, L6, L7, L8, L9, FSItemID, AccountID)  -  apply at FIRST KPI match only
22. Functional Area: Always use column FunctionalArea

/***** Measure & Variance Rules *****/
23. If prompt does not specify columns, always select EURAOP columns for aggregation for current year
24. Performance/ITM/Cost = PostActuals; Plan/Target = PostAOP; FC = PostJunFC; LY/PY = PostActualsLY
25. CY or Current Year means Calendar_Year = 2026
26. Variance for Cost Agility of Sales: AOP - CY (PostAOP - PostActuals)
27. Variance for other Cost Agilities: CY - AOP (PostActuals - PostAOP)
28. When variance is asked, always provide actual values along with variance
29. PreAOP & PostAOP are always compared between same year
30. Consider PostValues at First Priority, PreValues at Second Priority for Aggregation

/***** Time Period Rules *****/
31. FiscalPeriodID is a STRING type: '2025001', '2025012', '2026001' etc.
32. Q1=Jan,Feb,Mar Q2=Apr,May,Jun Q3=Jul,Aug,Sep Q4=Oct,Nov,Dec
33. QTD = mentioned FiscalPeriod + all prior periods within that quarter
34. Always find only ITM for FTE aggregation for given period

/***** FTE & Table Rules *****/
35. FTE ONLY from cat_blueprint_prevspostalloc  -  NEVER from cat_fpl_prevspostalloc
36. Do NOT apply S&W filter in cat_blueprint_prevspostalloc
37. Do NOT apply any CostAgility filter when aggregating FTE values
38. Only UNION cat_blueprint_prevspostalloc with cat_fpl_prevspostalloc  -  do NOT join them
39. Other KPIs only from cat_fpl_prevspostalloc
40. If "S&W" or "Salaries and Wages" mentioned, use "Salaries & Wages" as KPI Filter

/***** Special Filters *****/
41. IGM: FunctionalArea IN (0, 1000)
42. ISM: FunctionalArea IN (0, 1000, 2000)
43. EBITA: CostAgility_L1 ILIKE '%EBIT CA%'
44. "my Cost Center": Filter PFLT_Email in dim_pflt_cc_mapping to get cc_pk_ipl, filter fact by it
45. Do NOT use dim_pflt_cc_mapping unless "my Cost Center" is mentioned

/***** SQL Syntax Rules *****/
46. Top N: ORDER BY ABS(variance_col) DESC LIMIT N  -  no HAVING clause
47. For totals rows: use CTE with raw data + UNION ALL with aggregated totals
48. FORMAT_NUMBER() only in outermost SELECT, only when user requests formatting
49. ABS() takes exactly 1 argument
50. RLS: JOIN dim_cat_security_oru sec ON fact.CoCodePK = sec.CoCodePK_Security WHERE sec.Email ILIKE '%email%'
51. For blueprint FTE/HC: use PostActuals_Alloc_FTE, PostAOP_Alloc_FTE, etc.
52. Always alias fact tables (fact, f) and dimension tables (cc, dt, acct, mru, sec)
53. Use LEFT JOIN for dimension tables to prevent data loss
54. When using GROUP BY, include ALL non-aggregated columns
55. Account, FSItem, MAG, CC, ORU, CoCode, FA are granular attributes  -  apply filter only when specified

IMPORTANT: If the user query mentions "translate column X" or similar post-processing instructions,
IGNORE those instructions. Generate ONLY the SQL for data retrieval. Translation will be applied
as a separate post-processing step after execution.

OUTPUT FORMAT:
Analysis: <brief explanation>

```sql
SELECT ...
FROM qa_wb.financebi.<table> fact
...
```"""

def _build_sql_prompt(state: dict, retry_errors=None, exec_error="", step_desc="") -> tuple:
    """
    Build the SQL generation prompt with dynamic few-shot injection and recovery context.
    
    Uses clean_query (with inline instructions stripped) instead of
    raw user_query for SQL generation. This prevents the SQL agent from trying to
    handle translation/formatting in SQL.
    """
    # Use clean_query if available, fall back to user_query
    user_query = state.get("clean_query", state["user_query"])
    original_query = state["user_query"]
    analysis = state.get("analysis", {})
    recovery_mode = state.get("recovery_mode", "normal")

    expanded_query = expand_abbreviations(user_query)
    email = extract_email_from_query(original_query)  # Email from original, not cleaned

    relevant = select_relevant_examples(expanded_query, top_k=3)
    few_shot_text = ""
    if relevant:
        few_shot_parts = []
        for i, ex in enumerate(relevant, 1):
            ex_sql = ex["output"]
            if email:
                ex_sql = re.sub(r'[\w.+-]+@[\w.-]+\.\w+', email, ex_sql)
            few_shot_parts.append(f"--- Example {i} ---\nQuestion: {ex['input']}\nSQL:\n{ex_sql}")
        few_shot_text = "\n\n".join(few_shot_parts)

    prompt_parts = [f"USER QUESTION: {user_query}"]

    if expanded_query != user_query:
        prompt_parts.append(f"\nEXPANDED (abbreviations resolved): {expanded_query}")

    if email:
        prompt_parts.append(f"\nRLS EMAIL: {email}")
        prompt_parts.append("MUST JOIN dim_cat_security_oru sec ON fact.CoCodePK = sec.CoCodePK_Security")
        prompt_parts.append(f"MUST FILTER: sec.Email ILIKE '%{email}%'")

    if analysis:
        prompt_parts.append(f"\nPLANNER ANALYSIS: {json.dumps(analysis, indent=2)}")

    if step_desc:
        step_idx = state.get("current_step_idx", 0)
        prompt_parts.append(f"\nCURRENT STEP ({step_idx + 1}): {step_desc}")
        prev_results = state.get("step_results", {})
        if prev_results:
            for sid, sr in prev_results.items():
                prompt_parts.append(f"  Previous step {sid} data: {sr.get('data_summary', 'N/A')[:200]}")

    if few_shot_text:
        prompt_parts.append(f"\nRELEVANT FEW-SHOT EXAMPLES:\n{few_shot_text}")

    if retry_errors:
        prompt_parts.append(f"\nPREVIOUS VALIDATION ISSUES (fix these):")
        for iss in retry_errors:
            prompt_parts.append(f"  - {iss}")

    if exec_error:
        prompt_parts.append(f"\nPREVIOUS EXECUTION ERROR:\n  {exec_error[:500]}")

    if recovery_mode == "broadened":
        prompt_parts.append("\nRECOVERY MODE: BROADENED  -  Previous query returned empty results.")
        prompt_parts.append("Try: Remove overly specific filters, use broader ILIKE patterns, check FiscalPeriodID format.")
    elif recovery_mode == "simplified":
        prompt_parts.append("\nRECOVERY MODE: SIMPLIFIED  -  Multiple attempts returned empty.")
        prompt_parts.append("Try: Minimal joins, fewer filters, verify table has data for this period.")

    # Explicit reminder to ignore translation instructions
    inline_instructions = state.get("inline_instructions", [])
    if inline_instructions:
        prompt_parts.append("\nNOTE: The original query contained post-processing instructions (translation/formatting).")
        prompt_parts.append("These have been extracted and will be handled separately. Generate SQL for DATA RETRIEVAL only.")

    prompt_parts.append("\nCRITICAL REMINDERS:")
    prompt_parts.append("- Always use ILIKE with % for ALL string filters (never = or LIKE)")
    prompt_parts.append("- ALL tables: qa_wb.financebi.<table> (fully qualified)")
    prompt_parts.append("- SUM(COALESCE(column, 0)) for all aggregations  -  NULL as 0")
    prompt_parts.append("- Scale to k: try_divide(SUM(...), 1000)  -  but NOT for FTE")
    prompt_parts.append("- ROUND off decimals, then remove decimal places")
    prompt_parts.append("- Column names: CostAgility_L* (NOT Cost_Agility_L*)")
    prompt_parts.append("- Column names: BUGroup (NOT BUGroup_2025), MRU_L5 (NOT MRU_L5_2025)")
    prompt_parts.append("- FiscalPeriodID is STRING type (e.g., '2025001')")
    prompt_parts.append("- Join key: dim_cat_account_fpl.Acct_pk (lowercase pk) = fact.Acct_PK")
    prompt_parts.append("- Division: try_divide(numerator, denominator)")
    prompt_parts.append("- LEFT JOIN for dimension tables (prevent data loss)")
    prompt_parts.append("- GROUP BY must include ALL non-aggregated columns")
    prompt_parts.append("- Use FunctionalArea for FA filters")
    prompt_parts.append("- Use MAG_Description in SELECT for MAG level data")
    prompt_parts.append("- Use ORU_Description in SELECT for ORU level data")
    prompt_parts.append("- Variance for Sales CostAgility: AOP - CY; Other: CY - AOP")
    prompt_parts.append("- When variance asked, include actual values alongside")
    prompt_parts.append("- If no column specified, default to EURAOP for current year")
    prompt_parts.append("- CY / Current Year = Calendar_Year = 2026")
    prompt_parts.append("- FTE only from cat_blueprint_prevspostalloc (never from cat_fpl)")
    prompt_parts.append("- Do NOT apply S&W or CostAgility filter when aggregating FTE")
    prompt_parts.append("- IGM=FunctionalArea IN (0,1000), ISM=IN (0,1000,2000)")
    prompt_parts.append("- Security/RLS: JOIN dim_cat_security_oru sec ON fact.CoCodePK = sec.CoCodePK_Security")
    prompt_parts.append("- Always summarize results and assign column alias names")
    prompt_parts.append("- Return SQL inside ```sql ... ``` code blocks")

    return "\n".join(prompt_parts), few_shot_text