# import pandas as pd

# def print_output(sql, df, insights, trace):
#     # ... logic from notebook ...
#     pass

# def dataframe_to_response(df):
#     if df is None:
#         return None
#     df = df.where(pd.notnull(df), None)
#     return df.to_dict(orient="records")
